package pe.utp.scmplab.modulo;

/** Secciones de la navegación principal (Inicio es aparte). */
public enum Grupo {
    INVENTARIO("Inventario"),
    MANTENIMIENTO("Mantenimiento"),
    INCIDENCIAS("Incidencias"),
    ADMINISTRACION("Administración");

    private final String titulo;

    Grupo(String titulo) { this.titulo = titulo; }

    public String getTitulo() { return titulo; }
}
