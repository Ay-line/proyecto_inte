package pe.utp.scmplab.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import pe.utp.scmplab.dao.UsuarioDAO;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.service.ResultadoSesion;
import pe.utp.scmplab.service.SesionService;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Protege todas las rutas: valida la sesión (inactividad) y vuelve a leer al usuario en la base en cada petición,
 * de modo que una cuenta desactivada o un cambio de rol se apliquen de inmediato. El usuario vigente queda en el
 * atributo de petición "usuarioActual", sin el hash de la clave.
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    public static final String ATRIBUTO_USUARIO = "usuarioActual";

    private final SesionService sesionService;
    private final UsuarioDAO usuarioDAO;

    public AuthInterceptor(SesionService sesionService, UsuarioDAO usuarioDAO) {
        this.sesionService = sesionService;
        this.usuarioDAO = usuarioDAO;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        LocalDateTime ahora = LocalDateTime.now();
        HttpSession httpSession = request.getSession(false);
        String token = httpSession == null ? null : (String) httpSession.getAttribute("token");
        ResultadoSesion resultado = sesionService.validar(token, ahora);
        if (resultado.esValida()) {
            Integer idUsuario = (Integer) httpSession.getAttribute("uid");
            Optional<Usuario> vigente = idUsuario == null ? Optional.empty() : usuarioDAO.buscarPorId(idUsuario);
            if (vigente.isPresent() && vigente.get().estaActivo()) {
                vigente.get().setClaveHash(null);
                request.setAttribute(ATRIBUTO_USUARIO, vigente.get());
                return true;
            }
            sesionService.cerrar(token, false, true, ahora);
        }
        if (httpSession != null) httpSession.invalidate();
        boolean expirada = resultado.getEstado() == ResultadoSesion.Estado.EXPIRADA;
        response.sendRedirect(request.getContextPath() + "/login" + (expirada ? "?expirada=1" : ""));
        return false;
    }
}
