package pe.utp.scmplab.dao;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Acceso a datos de los catálogos básicos y del inventario. */
public interface CatalogoDAO {
    long contar(String tabla);
    List<Map<String, Object>> listarLaboratorios();
    List<Map<String, Object>> listarTiposEquipo();
    List<Map<String, Object>> listarEquipos();
    void crearLaboratorio(String codigo, String nombre, String sede, String piso, Integer responsable);
    void crearTipoEquipo(String nombre, String descripcion);
    void crearEquipo(String codigo, String serie, String marca, String modelo,
                     String fechaAdquisicion, String estado, int idTipoEquipo, int idLaboratorio);
    List<Map<String, Object>> listarResponsablesPosibles(String nombreRol);
    Optional<Map<String, Object>> buscarEquipo(int id);
    List<Map<String, Object>> componentesDeEquipo(int id);
    List<Map<String, Object>> mantenimientosDeEquipo(int id);
    List<Map<String, Object>> reportesDeEquipo(int id);
    List<Map<String, Object>> ordenesDeEquipo(int id);
}
