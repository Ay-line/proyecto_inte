package pe.utp.scmplab.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CsrfTokenTest {

    @Test
    @DisplayName("Los tokens generados son distintos y no vacíos")
    void generar() {
        String a = CsrfToken.generar(), b = CsrfToken.generar();
        assertFalse(a.isEmpty());
        assertNotEquals(a, b);
    }

    @Test
    @DisplayName("Solo coincide el mismo token; ausente, vacío o distinto se rechaza")
    void comparar() {
        String t = CsrfToken.generar();
        assertTrue(CsrfToken.coinciden(t, t));
        assertFalse(CsrfToken.coinciden(t, CsrfToken.generar()));
        assertFalse(CsrfToken.coinciden(t, null));
        assertFalse(CsrfToken.coinciden(t, ""));
        assertFalse(CsrfToken.coinciden(null, null));
        assertFalse(CsrfToken.coinciden("", ""));
    }
}
