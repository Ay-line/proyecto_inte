package pe.utp.scmplab.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Consultas de solo lectura para los indicadores y listas del panel de inicio. */
public interface PanelDAO {
    /** Cantidad de equipos por estado (clave = estado). */
    Map<String, Long> equiposPorEstado();
    long reportesSinOrden();
    long reportesAbiertos();
    long reportesDeUsuario(int idUsuario, boolean soloAbiertos);
    long ordenesAbiertas();
    long ordenesUrgentes();
    long alertasGeneradas();
    long programacionesVencidas(LocalDate hoy);
    long programacionesEntre(LocalDate desde, LocalDate hasta);
    List<Map<String, Object>> reportesSinOrdenRecientes(int limite);
    List<Map<String, Object>> reportesRecientes(int limite, Integer idUsuario);
    List<Map<String, Object>> ordenesAbiertasPrioritarias(int limite);
    List<Map<String, Object>> programacionesPendientes(LocalDate hoy, int limite);
}
