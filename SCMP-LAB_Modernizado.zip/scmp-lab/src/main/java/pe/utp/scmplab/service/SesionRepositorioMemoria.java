package pe.utp.scmplab.service;

import org.springframework.stereotype.Component;
import pe.utp.scmplab.model.Sesion;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** Sesiones activas en memoria del servidor. */
@Component
public class SesionRepositorioMemoria implements SesionRepositorio {

    private final Map<String, Sesion> sesiones = new ConcurrentHashMap<>();

    @Override
    public void guardar(Sesion sesion) { sesiones.put(sesion.getToken(), sesion); }

    @Override
    public Optional<Sesion> buscar(String token) {
        return token == null ? Optional.empty() : Optional.ofNullable(sesiones.get(token));
    }

    @Override
    public void eliminar(String token) {
        if (token != null) sesiones.remove(token);
    }
}
