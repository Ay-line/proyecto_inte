package pe.utp.scmplab.controller;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import pe.utp.scmplab.config.AuthInterceptor;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.modulo.CatalogoModulos;
import pe.utp.scmplab.modulo.Campo;
import pe.utp.scmplab.modulo.Modulo;
import pe.utp.scmplab.security.Accion;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.service.OperacionesService;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Pantallas de los módulos (listado + alta) y de detalle de reportes y órdenes. Cada operación comprueba el permiso
 * del rol en el servidor con {@link PoliticaAcceso}; ocultar un botón en la vista no es una medida de seguridad.
 */
@Controller
public class OperacionesController {

    private static final String SIN_PERMISO = "redirect:/inicio?sinPermiso=1";

    private final OperacionesService service;
    private final PoliticaAcceso acceso;

    public OperacionesController(OperacionesService service, PoliticaAcceso acceso) {
        this.service = service;
        this.acceso = acceso;
    }

    // ------------------------------------------------------------------ Listados y altas

    @GetMapping("/gestion/{modulo}")
    public String ver(@PathVariable String modulo, @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        Modulo m = CatalogoModulos.obtener(modulo).orElse(null);
        if (m == null) return "redirect:/inicio";
        if (!m.isGenerico()) return "redirect:" + m.getRuta();
        if (!acceso.permite(u, modulo, Accion.VER)) return SIN_PERMISO;

        boolean puedeCrear = !m.getCampos().isEmpty() && acceso.permite(u, modulo, Accion.CREAR);
        List<Campo> campos = camposVisibles(m, u);
        model.addAttribute("modulo", m);
        model.addAttribute("filas", service.listar(modulo, u));
        model.addAttribute("puedeCrear", puedeCrear);
        model.addAttribute("campos", campos);
        model.addAttribute("opciones", puedeCrear ? opcionesPara(campos) : Map.of());
        return "operaciones/modulo";
    }

    @PostMapping("/gestion/{modulo}/crear")
    public String crear(@PathVariable String modulo, @RequestParam Map<String, String> campos,
                        @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        Modulo m = CatalogoModulos.obtener(modulo).orElse(null);
        if (m == null || !m.isGenerico() || m.getCampos().isEmpty() || !acceso.permite(u, modulo, Accion.CREAR)) return SIN_PERMISO;
        try {
            service.crear(modulo, campos, u);
            redirect.addFlashAttribute("exito", "El registro se guardó correctamente.");
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            redirect.addFlashAttribute("error", ex instanceof IllegalArgumentException ? mensaje(ex) : mensajeIntegridad(modulo));
            redirect.addFlashAttribute("valores", campos);
        }
        return "redirect:/gestion/" + modulo;
    }

    // ------------------------------------------------------------------ Órdenes de trabajo

    @GetMapping("/gestion/ordenes/{id}")
    public String detalleOrden(@PathVariable int id, @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "ordenes", Accion.VER)) return SIN_PERMISO;
        var detalle = service.detalleOrden(id);
        if (detalle.isEmpty()) return "redirect:/gestion/ordenes";
        model.addAllAttributes(detalle.get());
        model.addAttribute("puedeGestionar", acceso.permite(u, "ordenes", Accion.GESTIONAR));
        model.addAttribute("estados", OperacionesService.ESTADOS_ORDEN);
        model.addAttribute("tecnicos", service.opciones("tecnicos"));
        model.addAttribute("repuestos", service.opciones("repuestos"));
        return "operaciones/orden-detalle";
    }

    @PostMapping("/gestion/ordenes/{id}/estado")
    public String cambiarEstadoOrden(@PathVariable int id, @RequestParam String estado,
                                     @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "ordenes", Accion.GESTIONAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/ordenes/" + id, "El estado de la orden se actualizó.",
                () -> service.actualizarEstadoOrden(id, estado, u));
    }

    @PostMapping("/gestion/ordenes/{id}/tecnico")
    public String asignarTecnico(@PathVariable int id, @RequestParam("id_tecnico") int idTecnico,
                                 @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "ordenes", Accion.GESTIONAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/ordenes/" + id, "Se asignó el técnico a la orden.",
                () -> service.asignarTecnicoOrden(id, idTecnico, u));
    }

    @PostMapping("/gestion/ordenes/{id}/repuestos")
    public String agregarRepuesto(@PathVariable int id, @RequestParam("id_repuesto") String idRepuesto,
                                  @RequestParam String cantidad,
                                  @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "detalle-orden", Accion.CREAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/ordenes/" + id, "Se agregó el repuesto a la orden.",
                () -> service.agregarRepuestoAOrden(id, idRepuesto, cantidad, u));
    }

    @PostMapping("/gestion/ordenes/{id}/evidencias")
    public String agregarEvidencia(@PathVariable int id, @RequestParam("ruta_archivo") String ruta,
                                   @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "evidencias", Accion.CREAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/ordenes/" + id, "Se registró la evidencia.",
                () -> service.agregarEvidenciaAOrden(id, ruta, u));
    }

    // ------------------------------------------------------------------ Reportes de falla

    @GetMapping("/gestion/reportes/{id}")
    public String detalleReporte(@PathVariable int id, @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "reportes", Accion.VER)) return SIN_PERMISO;
        var detalle = service.detalleReporte(id, u);
        if (detalle.isEmpty()) return "redirect:/gestion/reportes";
        model.addAllAttributes(detalle.get());
        boolean gestiona = acceso.permite(u, "reportes", Accion.GESTIONAR);
        model.addAttribute("puedeGestionar", gestiona);
        model.addAttribute("puedeCrearOrden", gestiona && acceso.permite(u, "ordenes", Accion.CREAR));
        model.addAttribute("prioridades", OperacionesService.PRIORIDADES);
        model.addAttribute("tiposFalla", gestiona ? service.opciones("tipos-falla") : List.of());
        model.addAttribute("tecnicos", gestiona ? service.opciones("tecnicos") : List.of());
        return "operaciones/reporte-detalle";
    }

    @PostMapping("/gestion/reportes/{id}/clasificar")
    public String clasificar(@PathVariable int id, @RequestParam(required = false) String prioridad,
                             @RequestParam(name = "id_tipo_falla", required = false) String idTipoFalla,
                             @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "reportes", Accion.GESTIONAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/reportes/" + id, "El reporte se actualizó.",
                () -> service.clasificarReporte(id, prioridad, entero(idTipoFalla), u));
    }

    @PostMapping("/gestion/reportes/{id}/orden")
    public String crearOrden(@PathVariable int id, @RequestParam String prioridad,
                             @RequestParam(name = "id_tecnico", required = false) String idTecnico,
                             @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, RedirectAttributes redirect) {
        if (!acceso.permite(u, "reportes", Accion.GESTIONAR) || !acceso.permite(u, "ordenes", Accion.CREAR)) return SIN_PERMISO;
        return ejecutar(redirect, "/gestion/reportes/" + id, "Se creó la orden de trabajo para este reporte.",
                () -> service.crearOrdenDesdeReporte(id, prioridad, entero(idTecnico), u));
    }

    // ------------------------------------------------------------------ Utilidades

    private String ejecutar(RedirectAttributes redirect, String destino, String exito, Runnable accion) {
        try {
            accion.run();
            redirect.addFlashAttribute("exito", exito);
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            redirect.addFlashAttribute("error", ex instanceof IllegalArgumentException ? mensaje(ex)
                    : "No se pudo guardar el cambio; revisa los datos e inténtalo de nuevo.");
        }
        return "redirect:" + destino;
    }

    private static String mensaje(Exception ex) {
        String m = ex.getMessage();
        return m == null || m.isBlank() ? "Revisa los datos ingresados." : m;
    }

    private static Integer entero(String valor) {
        if (valor == null || valor.isBlank()) return null;
        try {
            return Integer.valueOf(valor.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Selecciona un valor válido.");
        }
    }

    /** Campos del formulario que el rol puede completar (los de gestión se ocultan a quien solo reporta). */
    private List<Campo> camposVisibles(Modulo m, Usuario u) {
        boolean gestiona = acceso.permite(u, m.getClave(), Accion.GESTIONAR);
        List<Campo> visibles = new ArrayList<>();
        for (Campo c : m.getCampos()) {
            if (!c.isSoloGestion() || gestiona) visibles.add(c);
        }
        return visibles;
    }

    private Map<String, List<Map<String, Object>>> opcionesPara(List<Campo> campos) {
        Map<String, List<Map<String, Object>>> opciones = new LinkedHashMap<>();
        for (Campo c : campos) {
            if (c.getOpciones() != null && !opciones.containsKey(c.getOpciones())) {
                opciones.put(c.getOpciones(), service.opciones(c.getOpciones()));
            }
        }
        return opciones;
    }

    private String mensajeIntegridad(String m) {
        return switch (m) {
            case "instalaciones" -> "Ese componente ya está registrado en el equipo o las referencias no son válidas.";
            case "repuestos" -> "Revisa el costo y el stock del repuesto.";
            case "tipos-falla" -> "Ya existe un tipo de falla con ese nombre.";
            case "mantenimientos" -> "Revisa las fechas, el equipo y el técnico.";
            case "checklist-detalle" -> "Esa tarea ya está registrada en el mantenimiento o alguna referencia no es válida.";
            case "detalle-orden" -> "La orden ya incluye ese repuesto o las referencias no son válidas.";
            case "planes" -> "Ya existe un plan con ese nombre o falta indicar la periodicidad.";
            case "programaciones" -> "Revisa el plan, el equipo, la fecha y el estado.";
            case "configuracion" -> "Ya existe un parámetro con esa clave.";
            default -> "No se pudo guardar el registro; revisa los datos ingresados.";
        };
    }
}
