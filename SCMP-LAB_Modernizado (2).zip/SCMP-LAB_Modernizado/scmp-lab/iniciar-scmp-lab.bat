@echo off
title SCMP-LAB
cd /d "%~dp0"

set "MAVEN=%USERPROFILE%\.m2\wrapper\dists\apache-maven-3.9.15\0226a00282e400185496f3b60ec5a3f029cbdc6893912937d4876d57695224e1\bin\mvn.cmd"

if not exist "%MAVEN%" (
    echo No se encontro Maven en la ruta configurada.
    pause
    exit /b 1
)

call "%MAVEN%" spring-boot:run
pause
