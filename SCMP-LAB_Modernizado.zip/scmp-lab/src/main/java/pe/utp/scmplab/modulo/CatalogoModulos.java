package pe.utp.scmplab.modulo;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import static pe.utp.scmplab.modulo.Campo.*;
import static pe.utp.scmplab.modulo.Grupo.*;

/**
 * Definición única de los módulos: navegación, columnas de cada listado y campos de cada formulario.
 * Los nombres de campo coinciden con los que lee OperacionesDAOJdbc al registrar.
 */
public final class CatalogoModulos {

    private static final Map<String, Modulo> MODULOS = construir();

    private CatalogoModulos() { }

    public static Optional<Modulo> obtener(String clave) { return Optional.ofNullable(MODULOS.get(clave)); }

    public static Collection<Modulo> todos() { return MODULOS.values(); }

    private static Columna c(String key, String label) { return new Columna(key, label); }

    private static Map<String, Modulo> construir() {
        Map<String, Modulo> m = new LinkedHashMap<>();
        // ---------------- Inventario ----------------
        add(m, new Modulo("equipos", INVENTARIO, "Equipos", "Equipos registrados, su estado y ubicación.").ruta("/equipos"));
        add(m, new Modulo("laboratorios", INVENTARIO, "Laboratorios", "Sedes y laboratorios que alojan los equipos.").ruta("/laboratorios"));
        add(m, new Modulo("tipos-equipo", INVENTARIO, "Tipos de equipo", "Clasificación utilizada para ordenar el inventario.").ruta("/tipos-equipo"));
        add(m, new Modulo("componentes", INVENTARIO, "Componentes", "Memorias, discos, fuentes y otras piezas instalables.")
                .alta("Registrar componente")
                .columnas(c("tipo", "Tipo"), c("marca", "Marca"), c("capacidad", "Capacidad"))
                .campos(texto("tipo", "Tipo de componente", 60).req().ph("RAM, SSD, fuente"),
                        texto("marca", "Marca", 60),
                        texto("capacidad", "Capacidad", 60).ph("16 GB, 512 GB")));
        add(m, new Modulo("instalaciones", INVENTARIO, "Componentes instalados", "Qué componente tiene cada equipo y desde cuándo.")
                .alta("Registrar instalación")
                .columnas(c("equipo", "Equipo"), c("componente", "Componente"), c("marca", "Marca"),
                        c("fecha_instalacion", "Instalación"), c("fecha_retiro", "Retiro"))
                .campos(seleccion("id_equipo", "Equipo", "equipos", "Seleccionar equipo").req(),
                        seleccion("id_componente", "Componente", "componentes", "Seleccionar componente").req(),
                        fecha("fecha_instalacion", "Fecha de instalación").req(),
                        fecha("fecha_retiro", "Fecha de retiro")));
        add(m, new Modulo("hoja-vida", INVENTARIO, "Hoja de vida de equipos", "Ficha de cada equipo con su ubicación y sus componentes.")
                .columnas(c("codigo", "Código"), c("serie", "N.º de serie"), c("marca_equipo", "Marca"), c("modelo", "Modelo"),
                        c("adquisicion", "Adquisición"), c("estado", "Estado").etiqueta(), c("tipo_equipo", "Tipo"),
                        c("laboratorio", "Laboratorio"), c("componente", "Componente"), c("marca_componente", "Marca comp."),
                        c("capacidad", "Capacidad"), c("fecha_instalacion", "Instalado"), c("fecha_retiro", "Retirado")));
        add(m, new Modulo("inventario-laboratorios", INVENTARIO, "Inventario por laboratorio", "Equipos de cada laboratorio y su responsable.")
                .columnas(c("codigo_laboratorio", "Cód. lab."), c("laboratorio", "Laboratorio"), c("sede", "Sede"), c("piso", "Piso"),
                        c("responsable", "Responsable"), c("equipo", "Equipo"), c("tipo_equipo", "Tipo"), c("serie", "N.º de serie"),
                        c("marca", "Marca"), c("modelo", "Modelo"), c("estado", "Estado").etiqueta()));

        // ---------------- Mantenimiento ----------------
        add(m, new Modulo("mantenimientos", MANTENIMIENTO, "Mantenimientos", "Mantenimientos preventivos y correctivos realizados a los equipos.")
                .alta("Registrar mantenimiento")
                .columnas(c("id", "N.º"), c("tipo", "Tipo"), c("equipo", "Equipo"), c("tecnico", "Técnico"), c("inicio", "Inicio"),
                        c("fin", "Fin"), c("duracion_min", "Duración (min)"), c("resultado", "Resultado").etiqueta(), c("observacion", "Observación"))
                .campos(lista("tipo", "Tipo", "Preventivo", "Correctivo").req(),
                        seleccion("id_equipo", "Equipo", "equipos", "Seleccionar equipo").req(),
                        seleccion("id_tecnico", "Técnico", "tecnicos", "Seleccionar técnico").req(),
                        fechaHora("fecha_inicio", "Inicio").req(),
                        fechaHora("fecha_fin", "Fin"),
                        lista("resultado", "Resultado", "Conforme", "Observado").req(),
                        texto("observacion", "Observación", 255).ancho()));
        add(m, new Modulo("checklist-detalle", MANTENIMIENTO, "Resultados de checklist", "Resultado de cada tarea revisada en un mantenimiento.")
                .alta("Registrar resultado")
                .columnas(c("mantenimiento", "Mantenimiento"), c("equipo", "Equipo"), c("descripcion", "Tarea"),
                        c("resultado", "Resultado").etiqueta(), c("comentario", "Comentario"))
                .campos(seleccion("id_mantenimiento", "Mantenimiento", "mantenimientos", "Seleccionar mantenimiento").req(),
                        seleccion("id_tarea", "Tarea", "tareas", "Seleccionar tarea").req(),
                        lista("resultado", "Resultado", "Conforme", "Observado", "No aplica").req(),
                        texto("comentario", "Comentario", 255).ancho()));
        add(m, new Modulo("checklist-tareas", MANTENIMIENTO, "Tareas de checklist", "Tareas de revisión definidas para cada tipo de equipo.")
                .alta("Registrar tarea")
                .columnas(c("id", "N.º"), c("descripcion", "Tarea"), c("tipo_equipo", "Tipo de equipo"))
                .campos(texto("descripcion", "Descripción de la tarea", 200).req().ancho(),
                        seleccion("id_tipo_equipo", "Tipo de equipo", "tipos-equipo", "Seleccionar tipo").req()));
        add(m, new Modulo("planes", MANTENIMIENTO, "Planes de mantenimiento", "Cada cuánto debe revisarse un tipo de equipo.")
                .alta("Registrar plan")
                .columnas(c("nombre", "Plan"), c("tipo_equipo", "Tipo de equipo"), c("periodicidad_dias", "Cada (días)"),
                        c("horas_uso", "Horas de uso"), c("activo", "Activo").etiqueta())
                .campos(texto("nombre", "Nombre del plan", 100).req(),
                        seleccion("id_tipo_equipo", "Tipo de equipo", "tipos-equipo", "Seleccionar tipo").req(),
                        numero("periodicidad_dias", "Periodicidad (días)").min("1"),
                        numero("horas_uso", "Horas de uso").min("1")));
        add(m, new Modulo("programaciones", MANTENIMIENTO, "Programación", "Fechas previstas de mantenimiento por equipo.")
                .alta("Programar mantenimiento")
                .columnas(c("fecha", "Fecha"), c("equipo", "Equipo"), c("plan", "Plan"), c("hora_inicio", "Inicio"),
                        c("hora_fin", "Fin"), c("estado", "Estado").etiqueta())
                .campos(seleccion("id_plan", "Plan", "planes", "Seleccionar plan").req(),
                        seleccion("id_equipo", "Equipo", "equipos", "Seleccionar equipo").req(),
                        fecha("fecha_programada", "Fecha programada").req(),
                        lista("estado", "Estado", "Programado", "Reprogramado", "Vencido", "Ejecutado").req(),
                        hora("hora_inicio", "Hora de inicio"),
                        hora("hora_fin", "Hora de fin")));
        add(m, new Modulo("tecnicos", MANTENIMIENTO, "Técnicos", "Personal que ejecuta mantenimientos y atiende órdenes.")
                .alta("Registrar técnico")
                .columnas(c("nombre", "Nombre"), c("correo", "Correo"), c("especialidad", "Especialidad"))
                .campos(texto("nombre", "Nombre", 120).req(),
                        correo("correo", "Correo", 120),
                        texto("especialidad", "Especialidad", 80)));
        add(m, new Modulo("repuestos", MANTENIMIENTO, "Repuestos", "Catálogo de repuestos con su costo vigente.")
                .alta("Registrar repuesto")
                .columnas(c("nombre", "Repuesto"), c("costo", "Costo unitario (S/)"), c("stock", "Stock referencial"))
                .campos(texto("nombre", "Nombre del repuesto", 100).req(),
                        numero("costo_unitario", "Costo unitario (S/)").req().min("0").step("0.01"),
                        numero("stock_referencial", "Stock referencial").min("0")));

        // ---------------- Incidencias ----------------
        add(m, new Modulo("reportes", INCIDENCIAS, "Reportes de falla", "Fallas informadas por los usuarios y su estado de atención.")
                .alta("Reportar una falla").detalle("/gestion/reportes/")
                .columnas(c("id", "N.º").enlace(), c("fecha", "Fecha"), c("equipo", "Equipo"), c("tipo_falla", "Tipo de falla"),
                        c("prioridad", "Prioridad").etiqueta(), c("estado", "Estado").etiqueta(), c("usuario", "Reportado por"), c("descripcion", "Descripción"))
                .campos(seleccion("id_equipo", "Equipo", "equipos", "Seleccionar equipo").req(),
                        lista("canal", "Canal", "Formulario web", "QR").req(),
                        area("descripcion_problema", "¿Qué le pasa al equipo?", 4000).req().ph("Describe el problema observado"),
                        lista("prioridad", "Prioridad", "", "Baja", "Media", "Alta", "Crítica").gestion(),
                        seleccion("id_tipo_falla", "Tipo de falla", "tipos-falla", "Sin clasificar").gestion()));
        add(m, new Modulo("ordenes", INCIDENCIAS, "Órdenes de trabajo", "Reparaciones asignadas a técnicos, con su avance y costo de repuestos.")
                .alta("Crear orden").detalle("/gestion/ordenes/")
                .columnas(c("id", "N.º").enlace(), c("fecha", "Fecha"), c("equipo", "Equipo"), c("prioridad", "Prioridad").etiqueta(),
                        c("estado", "Estado").etiqueta(), c("tecnico", "Técnico"), c("diagnostico", "Diagnóstico"), c("costo_repuestos", "Repuestos (S/)"))
                .campos(seleccion("id_equipo", "Equipo", "equipos", "Seleccionar equipo").req(),
                        lista("prioridad", "Prioridad", "Baja", "Media", "Alta", "Crítica").req(),
                        seleccion("id_reporte", "Reporte de origen", "reportes", "Sin reporte previo"),
                        seleccion("id_tecnico", "Técnico", "tecnicos", "Sin asignar"),
                        area("diagnostico", "Diagnóstico inicial", 2000)));
        add(m, new Modulo("detalle-orden", INCIDENCIAS, "Repuestos por orden", "Repuestos usados en cada orden, con el costo aplicado en su momento.")
                .alta("Agregar repuesto")
                .columnas(c("orden", "Orden"), c("repuesto", "Repuesto"), c("cantidad", "Cantidad"),
                        c("costo_unitario", "Costo aplicado (S/)"), c("subtotal", "Subtotal (S/)"))
                .campos(seleccion("id_orden", "Orden", "ordenes", "Seleccionar orden").req(),
                        seleccion("id_repuesto", "Repuesto", "repuestos", "Seleccionar repuesto").req(),
                        numero("cantidad", "Cantidad").req().min("1").step("1")));
        add(m, new Modulo("evidencias", INCIDENCIAS, "Evidencias", "Referencias de los archivos que respaldan cada orden.")
                .alta("Registrar evidencia")
                .columnas(c("orden", "Orden"), c("ruta_archivo", "Referencia del archivo"), c("fecha_carga", "Registrada"))
                .campos(seleccion("id_orden", "Orden de trabajo", "ordenes", "Seleccionar orden").req(),
                        texto("ruta_archivo", "Ruta o referencia del archivo", 255).req().ancho().ph("evidencias/orden-1/foto.jpg")));
        add(m, new Modulo("alertas", INCIDENCIAS, "Alertas", "Avisos generados por órdenes y programaciones.")
                .alta("Registrar alerta")
                .columnas(c("fecha", "Fecha"), c("tipo", "Tipo"), c("mensaje", "Mensaje"), c("estado", "Estado").etiqueta(),
                        c("orden", "Orden"), c("programacion", "Programación"))
                .campos(texto("tipo", "Tipo", 40).req().ph("Mantenimiento programado"),
                        texto("mensaje", "Mensaje", 255).req().ancho(),
                        seleccion("id_orden", "Orden relacionada", "ordenes", "Ninguna"),
                        seleccion("id_programacion", "Programación relacionada", "programaciones", "Ninguna")));
        add(m, new Modulo("tipos-falla", INCIDENCIAS, "Tipos de falla", "Clasificaciones para ordenar los reportes de falla.")
                .alta("Registrar tipo de falla")
                .columnas(c("nombre", "Tipo de falla"), c("descripcion", "Descripción"))
                .campos(texto("nombre", "Nombre", 80).req(),
                        texto("descripcion", "Descripción", 150).ancho()));

        // ---------------- Administración ----------------
        add(m, new Modulo("config-alertas", ADMINISTRACION, "Configuración de alertas", "A quién y por qué canal se envía cada tipo de alerta.")
                .alta("Registrar configuración")
                .columnas(c("tipo_alerta", "Tipo de alerta"), c("canal", "Canal"), c("destinatario", "Destinatario"), c("activo", "Activa").etiqueta())
                .campos(texto("tipo_alerta", "Tipo de alerta", 40).req(),
                        lista("canal", "Canal", "Correo", "Sistema").req(),
                        texto("destinatario", "Destinatario", 120).req().ph("correo o nombre de perfil")));
        add(m, new Modulo("auditoria", ADMINISTRACION, "Auditoría", "Registro de las acciones realizadas en el sistema.")
                .columnas(c("fecha", "Fecha"), c("usuario", "Usuario"), c("accion", "Acción"), c("tabla", "Módulo"), c("registro", "Registro")));
        add(m, new Modulo("usuarios", ADMINISTRACION, "Usuarios", "Cuentas con acceso al sistema y su rol.")
                .columnas(c("nombre", "Nombre"), c("correo", "Correo"), c("rol", "Rol"), c("estado", "Estado").etiqueta()));
        add(m, new Modulo("roles", ADMINISTRACION, "Roles", "Perfiles de acceso disponibles.")
                .columnas(c("nombre", "Rol"), c("descripcion", "Descripción")));
        add(m, new Modulo("configuracion", ADMINISTRACION, "Configuración general", "Parámetros generales del sistema.")
                .alta("Registrar parámetro")
                .columnas(c("clave", "Parámetro"), c("valor", "Valor"), c("descripcion", "Descripción"))
                .campos(texto("clave", "Parámetro", 80).req(),
                        texto("valor", "Valor", 255),
                        texto("descripcion", "Descripción", 200).ancho()));
        add(m, new Modulo("respaldos", ADMINISTRACION, "Respaldos", "Programación y registro de copias de seguridad.")
                .alta("Programar respaldo")
                .columnas(c("fecha_programada", "Programado para"), c("fecha_ejecucion", "Ejecutado"), c("estado", "Estado").etiqueta(), c("ubicacion", "Ubicación"))
                .campos(fechaHora("fecha_programada", "Fecha y hora programada").req(),
                        texto("ubicacion", "Ubicación prevista", 255).ancho().ph("Ruta o nombre del archivo")));
        return java.util.Collections.unmodifiableMap(m);
    }

    private static void add(Map<String, Modulo> m, Modulo modulo) { m.put(modulo.getClave(), modulo); }
}
