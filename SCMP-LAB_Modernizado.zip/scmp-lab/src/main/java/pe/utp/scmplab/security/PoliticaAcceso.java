package pe.utp.scmplab.security;

import org.springframework.stereotype.Component;
import pe.utp.scmplab.model.Usuario;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static pe.utp.scmplab.security.RolSistema.*;

/**
 * Única fuente de verdad de los permisos por rol y módulo. Los controladores la consultan en el servidor
 * antes de ejecutar cualquier operación; la navegación la usa solo para mostrar lo que corresponde.
 * Si un módulo o rol no figura aquí, el acceso se niega.
 */
@Component
public class PoliticaAcceso {

    private static final RolSistema[] NADIE = {};
    private static final RolSistema[] GESTION = {ADMINISTRADOR, JEFE};
    private static final RolSistema[] INVENTARIO = {ADMINISTRADOR, JEFE, ADMIN_LABORATORIO};

    private final Map<String, Map<Accion, Set<RolSistema>>> reglas = new HashMap<>();

    public PoliticaAcceso() {
        // Inventario
        modulo("equipos", INVENTARIO, INVENTARIO, NADIE);
        modulo("laboratorios", INVENTARIO, INVENTARIO, NADIE);
        modulo("tipos-equipo", INVENTARIO, INVENTARIO, NADIE);
        modulo("hoja-vida", INVENTARIO, NADIE, NADIE);
        modulo("inventario-laboratorios", INVENTARIO, NADIE, NADIE);
        modulo("componentes", INVENTARIO, INVENTARIO, NADIE);
        modulo("instalaciones", INVENTARIO, INVENTARIO, NADIE);
        // Mantenimiento
        modulo("mantenimientos", INVENTARIO, GESTION, NADIE);
        modulo("checklist-detalle", INVENTARIO, GESTION, NADIE);
        modulo("checklist-tareas", INVENTARIO, GESTION, NADIE);
        modulo("planes", GESTION, GESTION, NADIE);
        modulo("programaciones", GESTION, GESTION, NADIE);
        modulo("tecnicos", GESTION, GESTION, NADIE);
        modulo("repuestos", GESTION, GESTION, NADIE);
        // Incidencias
        modulo("reportes", new RolSistema[]{ADMINISTRADOR, JEFE, ADMIN_LABORATORIO, USUARIO_LABORATORIO},
                new RolSistema[]{ADMINISTRADOR, JEFE, ADMIN_LABORATORIO, USUARIO_LABORATORIO}, GESTION);
        modulo("ordenes", GESTION, GESTION, GESTION);
        modulo("detalle-orden", GESTION, GESTION, NADIE);
        modulo("evidencias", GESTION, GESTION, NADIE);
        modulo("alertas", GESTION, GESTION, NADIE);
        modulo("tipos-falla", GESTION, GESTION, NADIE);
        // Administración
        modulo("config-alertas", GESTION, GESTION, NADIE);
        modulo("auditoria", GESTION, NADIE, NADIE);
        modulo("configuracion", new RolSistema[]{ADMINISTRADOR}, new RolSistema[]{ADMINISTRADOR}, NADIE);
        modulo("respaldos", new RolSistema[]{ADMINISTRADOR}, new RolSistema[]{ADMINISTRADOR}, NADIE);
        modulo("usuarios", new RolSistema[]{ADMINISTRADOR}, NADIE, NADIE);
        modulo("roles", new RolSistema[]{ADMINISTRADOR}, NADIE, NADIE);
    }

    private void modulo(String clave, RolSistema[] ver, RolSistema[] crear, RolSistema[] gestionar) {
        Map<Accion, Set<RolSistema>> m = new EnumMap<>(Accion.class);
        m.put(Accion.VER, conjunto(ver));
        m.put(Accion.CREAR, conjunto(crear));
        m.put(Accion.GESTIONAR, conjunto(gestionar));
        reglas.put(clave, m);
    }

    private static Set<RolSistema> conjunto(RolSistema[] roles) {
        Set<RolSistema> s = EnumSet.noneOf(RolSistema.class);
        for (RolSistema r : roles) s.add(r);
        return s;
    }

    public boolean permite(RolSistema rol, String modulo, Accion accion) {
        if (rol == null || modulo == null || accion == null) return false;
        Map<Accion, Set<RolSistema>> m = reglas.get(modulo);
        return m != null && m.get(accion).contains(rol);
    }

    public boolean permite(Usuario usuario, String modulo, Accion accion) {
        return usuario != null && permite(RolSistema.desdeNombre(usuario.getNombreRol()).orElse(null), modulo, accion);
    }

    public RolSistema rolDe(Usuario usuario) {
        return usuario == null ? null : RolSistema.desdeNombre(usuario.getNombreRol()).orElse(null);
    }
}
