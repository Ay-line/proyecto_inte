package pe.utp.scmplab.model;

import java.time.LocalDateTime;

/** Sesión de un usuario autenticado. */
public class Sesion {
    private final String token;
    private final Integer idUsuario;
    private LocalDateTime ultimaActividad;

    public Sesion(String token, Integer idUsuario, LocalDateTime ultimaActividad) {
        this.token = token;
        this.idUsuario = idUsuario;
        this.ultimaActividad = ultimaActividad;
    }
    public String getToken() { return token; }
    public Integer getIdUsuario() { return idUsuario; }
    public LocalDateTime getUltimaActividad() { return ultimaActividad; }
    public void setUltimaActividad(LocalDateTime ultimaActividad) { this.ultimaActividad = ultimaActividad; }
}
