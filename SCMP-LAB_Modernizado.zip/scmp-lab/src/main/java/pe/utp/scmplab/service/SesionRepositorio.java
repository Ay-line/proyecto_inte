package pe.utp.scmplab.service;

import pe.utp.scmplab.model.Sesion;

import java.util.Optional;

/** Almacén de sesiones activas. Abstracción para no depender de dónde se guardan (SOLID - D). */
public interface SesionRepositorio {
    void guardar(Sesion sesion);

    Optional<Sesion> buscar(String token);

    void eliminar(String token);
}
