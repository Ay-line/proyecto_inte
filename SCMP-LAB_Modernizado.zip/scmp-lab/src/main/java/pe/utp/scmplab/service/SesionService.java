package pe.utp.scmplab.service;

import org.springframework.stereotype.Service;
import pe.utp.scmplab.dao.AuditoriaDAO;
import pe.utp.scmplab.model.Sesion;
import pe.utp.scmplab.model.Usuario;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

/**
 * RF02 - Cerrar sesión o expirarla por inactividad.
 * Única responsabilidad (SOLID - S): ciclo de vida de la sesión (crear, validar, cerrar).
 */
@Service
public class SesionService {

    public static final int MINUTOS_INACTIVIDAD = 20;
    static final String MSG_INVALIDA = "Inicie sesión para continuar";
    static final String MSG_EXPIRADA = "Su sesión expiró por inactividad";
    static final String MSG_CERRADA = "Sesión cerrada";
    static final String MSG_PENDIENTES = "Hay cambios sin guardar. ¿Desea cerrar sesión?";

    private final SesionRepositorio sesiones;
    private final AuditoriaDAO auditoriaDAO;

    public SesionService(SesionRepositorio sesiones, AuditoriaDAO auditoriaDAO) {
        this.sesiones = sesiones;
        this.auditoriaDAO = auditoriaDAO;
    }

    public Sesion iniciar(Usuario usuario, LocalDateTime ahora) {
        Sesion sesion = new Sesion(UUID.randomUUID().toString(), usuario.getIdUsuario(), ahora);
        sesiones.guardar(sesion);
        return sesion;
    }

    public ResultadoSesion validar(String token, LocalDateTime ahora) {
        Optional<Sesion> encontrada = sesiones.buscar(token);
        if (encontrada.isEmpty()) {
            return new ResultadoSesion(ResultadoSesion.Estado.INVALIDA, MSG_INVALIDA);
        }
        Sesion sesion = encontrada.get();
        long minutosInactivo = Duration.between(sesion.getUltimaActividad(), ahora).toMinutes();
        if (minutosInactivo > MINUTOS_INACTIVIDAD) {
            sesiones.eliminar(token);
            auditoriaDAO.registrar(ahora, "SESION_EXPIRADA", "USUARIO", String.valueOf(sesion.getIdUsuario()), sesion.getIdUsuario());
            return new ResultadoSesion(ResultadoSesion.Estado.EXPIRADA, MSG_EXPIRADA);
        }
        sesion.setUltimaActividad(ahora);
        return new ResultadoSesion(ResultadoSesion.Estado.VALIDA, "Sesión activa");
    }

    public ResultadoSesion cerrar(String token, boolean hayCambiosPendientes, boolean confirmado, LocalDateTime ahora) {
        Optional<Sesion> encontrada = sesiones.buscar(token);
        if (encontrada.isEmpty()) {
            return new ResultadoSesion(ResultadoSesion.Estado.INVALIDA, MSG_INVALIDA);
        }
        if (hayCambiosPendientes && !confirmado) {
            return new ResultadoSesion(ResultadoSesion.Estado.REQUIERE_CONFIRMACION, MSG_PENDIENTES);
        }
        Sesion sesion = encontrada.get();
        sesiones.eliminar(token);
        auditoriaDAO.registrar(ahora, "CIERRE_SESION", "USUARIO", String.valueOf(sesion.getIdUsuario()), sesion.getIdUsuario());
        return new ResultadoSesion(ResultadoSesion.Estado.CERRADA, MSG_CERRADA);
    }
}
