package pe.utp.scmplab.security;

/** VER: consultar. CREAR: registrar nuevos datos. GESTIONAR: clasificar, asignar o cambiar estados. */
public enum Accion { VER, CREAR, GESTIONAR }
