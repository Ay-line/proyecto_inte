(function () {
  'use strict';
  var body = document.body;
  var boton = document.getElementById('btn-menu');
  var velo = document.getElementById('velo');

  function alternarMenu(abrir) {
    body.classList.toggle('menu-abierto', abrir);
    if (boton) boton.setAttribute('aria-expanded', abrir ? 'true' : 'false');
  }
  if (boton) boton.addEventListener('click', function () { alternarMenu(!body.classList.contains('menu-abierto')); });
  if (velo) velo.addEventListener('click', function () { alternarMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') alternarMenu(false); });

  // Filtro rápido de tablas: oculta las filas que no contienen el texto buscado.
  document.querySelectorAll('input[data-filtro]').forEach(function (campo) {
    var tabla = document.getElementById(campo.getAttribute('data-filtro'));
    if (!tabla) return;
    campo.addEventListener('input', function () {
      var texto = campo.value.trim().toLowerCase();
      tabla.querySelectorAll('tbody tr').forEach(function (fila) {
        fila.hidden = texto !== '' && fila.textContent.toLowerCase().indexOf(texto) === -1;
      });
    });
  });
})();
