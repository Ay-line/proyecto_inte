package pe.utp.scmplab.dao;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Consultas y comandos de los módulos operativos definidos en el modelo físico. */
public interface OperacionesDAO {
    List<Map<String, Object>> listar(String modulo, Integer idUsuario);
    List<Map<String, Object>> opciones(String catalogo);
    void crear(String modulo, Map<String, String> f, Integer idUsuario);
    void actualizarEstadoOrden(int idOrden, String estado);
    void asignarTecnicoOrden(int idOrden, int idTecnico);
    void clasificarReporte(int idReporte, String prioridad, Integer idTipoFalla);
    Optional<Map<String, Object>> buscarOrden(int id);
    List<Map<String, Object>> repuestosDeOrden(int id);
    List<Map<String, Object>> evidenciasDeOrden(int id);
    Optional<Map<String, Object>> buscarReporte(int id);
    List<Map<String, Object>> ordenesDeReporte(int id);
}
