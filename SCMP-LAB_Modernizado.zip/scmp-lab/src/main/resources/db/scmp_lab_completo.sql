-- SCMP-LAB completo basado en Capítulo 5 del informe.
-- Importar una sola vez en MySQL Workbench. No elimina la BD scmp_lab existente.
CREATE DATABASE IF NOT EXISTS scmp_lab_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE scmp_lab_app;

-- SCMP-LAB: esquema físico (24 tablas). Compatible con MySQL 8 y H2 en modo MySQL.

CREATE TABLE ROL (
  id_rol       INT          NOT NULL AUTO_INCREMENT,
  nombre       VARCHAR(50)  NOT NULL,
  descripcion  VARCHAR(150) NULL,
  CONSTRAINT PK_ROL        PRIMARY KEY (id_rol),
  CONSTRAINT UQ_ROL_NOMBRE UNIQUE (nombre)
);

CREATE TABLE USUARIO (
  id_usuario  INT          NOT NULL AUTO_INCREMENT,
  nombre      VARCHAR(120) NOT NULL,
  correo      VARCHAR(120) NOT NULL,
  clave_hash  VARCHAR(255) NOT NULL,
  estado      VARCHAR(20)  NOT NULL DEFAULT 'Activo',
  intentos_fallidos INT    NOT NULL DEFAULT 0,
  bloqueado_hasta   DATETIME NULL,
  id_rol      INT          NOT NULL,
  CONSTRAINT PK_USUARIO        PRIMARY KEY (id_usuario),
  CONSTRAINT UQ_USUARIO_CORREO UNIQUE (correo),
  CONSTRAINT CK_USUARIO_ESTADO CHECK (estado IN ('Activo','Inactivo')),
  CONSTRAINT FK_USUARIO_ROL    FOREIGN KEY (id_rol) REFERENCES ROL (id_rol)
);

CREATE TABLE LABORATORIO (
  id_laboratorio         INT          NOT NULL AUTO_INCREMENT,
  codigo                 VARCHAR(20)  NOT NULL,
  nombre                 VARCHAR(100) NOT NULL,
  sede                   VARCHAR(80)  NOT NULL,
  piso                   VARCHAR(20)  NULL,
  id_usuario_responsable INT          NULL,
  CONSTRAINT PK_LABORATORIO        PRIMARY KEY (id_laboratorio),
  CONSTRAINT UQ_LABORATORIO_CODIGO UNIQUE (codigo),
  CONSTRAINT FK_LABORATORIO_USUARIO FOREIGN KEY (id_usuario_responsable)
    REFERENCES USUARIO (id_usuario)
);

CREATE TABLE TIPO_EQUIPO (
  id_tipo_equipo INT          NOT NULL AUTO_INCREMENT,
  nombre         VARCHAR(60)  NOT NULL,
  descripcion    VARCHAR(150) NULL,
  CONSTRAINT PK_TIPO_EQUIPO        PRIMARY KEY (id_tipo_equipo),
  CONSTRAINT UQ_TIPO_EQUIPO_NOMBRE UNIQUE (nombre)
);

CREATE TABLE EQUIPO (
  id_equipo         INT         NOT NULL AUTO_INCREMENT,
  codigo_interno    VARCHAR(30) NOT NULL,
  numero_serie      VARCHAR(80) NOT NULL,
  marca             VARCHAR(60) NULL,
  modelo            VARCHAR(80) NULL,
  fecha_adquisicion DATE        NULL,
  estado            VARCHAR(30) NOT NULL DEFAULT 'Operativo',
  id_tipo_equipo    INT         NOT NULL,
  id_laboratorio    INT         NOT NULL,
  CONSTRAINT PK_EQUIPO        PRIMARY KEY (id_equipo),
  CONSTRAINT UQ_EQUIPO_CODIGO UNIQUE (codigo_interno),
  CONSTRAINT UQ_EQUIPO_SERIE  UNIQUE (numero_serie),
  CONSTRAINT CK_EQUIPO_ESTADO CHECK (estado IN ('Operativo','En mantenimiento','Inoperativo','Baja')),
  CONSTRAINT FK_EQUIPO_TIPO   FOREIGN KEY (id_tipo_equipo) REFERENCES TIPO_EQUIPO (id_tipo_equipo),
  CONSTRAINT FK_EQUIPO_LAB    FOREIGN KEY (id_laboratorio) REFERENCES LABORATORIO (id_laboratorio)
);

CREATE TABLE COMPONENTE (
  id_componente INT         NOT NULL AUTO_INCREMENT,
  tipo          VARCHAR(60) NOT NULL,
  marca         VARCHAR(60) NULL,
  capacidad     VARCHAR(60) NULL,
  CONSTRAINT PK_COMPONENTE PRIMARY KEY (id_componente)
);

CREATE TABLE INSTALACION_COMPONENTE (
  id_equipo         INT  NOT NULL,
  id_componente     INT  NOT NULL,
  fecha_instalacion DATE NOT NULL,
  fecha_retiro      DATE NULL,
  CONSTRAINT PK_INSTALACION PRIMARY KEY (id_equipo, id_componente),
  CONSTRAINT CK_INSTALACION_FECHAS CHECK (fecha_retiro IS NULL OR fecha_retiro >= fecha_instalacion),
  CONSTRAINT FK_INSTALACION_EQUIPO     FOREIGN KEY (id_equipo)     REFERENCES EQUIPO (id_equipo),
  CONSTRAINT FK_INSTALACION_COMPONENTE FOREIGN KEY (id_componente) REFERENCES COMPONENTE (id_componente)
);

CREATE TABLE TIPO_FALLA (
  id_tipo_falla INT          NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(80)  NOT NULL,
  descripcion   VARCHAR(150) NULL,
  CONSTRAINT PK_TIPO_FALLA        PRIMARY KEY (id_tipo_falla),
  CONSTRAINT UQ_TIPO_FALLA_NOMBRE UNIQUE (nombre)
);

CREATE TABLE TECNICO (
  id_tecnico   INT          NOT NULL AUTO_INCREMENT,
  nombre       VARCHAR(120) NOT NULL,
  correo       VARCHAR(120) NULL,
  especialidad VARCHAR(80)  NULL,
  CONSTRAINT PK_TECNICO PRIMARY KEY (id_tecnico)
);

CREATE TABLE REPUESTO (
  id_repuesto       INT           NOT NULL AUTO_INCREMENT,
  nombre            VARCHAR(100)  NOT NULL,
  costo_unitario    DECIMAL(10,2) NOT NULL,
  stock_referencial INT           NULL,
  CONSTRAINT PK_REPUESTO PRIMARY KEY (id_repuesto),
  CONSTRAINT CK_REPUESTO_COSTO CHECK (costo_unitario >= 0)
);

CREATE TABLE TAREA_CHECKLIST (
  id_tarea       INT          NOT NULL AUTO_INCREMENT,
  descripcion    VARCHAR(200) NOT NULL,
  id_tipo_equipo INT          NOT NULL,
  CONSTRAINT PK_TAREA_CHECKLIST PRIMARY KEY (id_tarea),
  CONSTRAINT FK_TAREA_TIPO_EQUIPO FOREIGN KEY (id_tipo_equipo)
    REFERENCES TIPO_EQUIPO (id_tipo_equipo)
);

CREATE TABLE MANTENIMIENTO (
  id_mantenimiento INT          NOT NULL AUTO_INCREMENT,
  tipo             VARCHAR(20)  NOT NULL,
  fecha_inicio     DATETIME     NOT NULL,
  fecha_fin        DATETIME     NULL,
  resultado        VARCHAR(30)  NOT NULL,
  observacion      VARCHAR(255) NULL,
  id_equipo        INT          NOT NULL,
  id_tecnico       INT          NOT NULL,
  CONSTRAINT PK_MANTENIMIENTO PRIMARY KEY (id_mantenimiento),
  CONSTRAINT CK_MANT_TIPO      CHECK (tipo IN ('Preventivo','Correctivo')),
  CONSTRAINT CK_MANT_RESULTADO CHECK (resultado IN ('Conforme','Observado')),
  CONSTRAINT CK_MANT_FECHAS    CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio),
  CONSTRAINT FK_MANT_EQUIPO  FOREIGN KEY (id_equipo)  REFERENCES EQUIPO (id_equipo),
  CONSTRAINT FK_MANT_TECNICO FOREIGN KEY (id_tecnico) REFERENCES TECNICO (id_tecnico)
);

CREATE TABLE DETALLE_CHECKLIST (
  id_mantenimiento INT          NOT NULL,
  id_tarea         INT          NOT NULL,
  resultado        VARCHAR(30)  NOT NULL,
  comentario       VARCHAR(255) NULL,
  CONSTRAINT PK_DETALLE_CHECKLIST PRIMARY KEY (id_mantenimiento, id_tarea),
  CONSTRAINT CK_DETCHK_RESULTADO CHECK (resultado IN ('Conforme','Observado','No aplica')),
  CONSTRAINT FK_DETCHK_MANT  FOREIGN KEY (id_mantenimiento) REFERENCES MANTENIMIENTO (id_mantenimiento)
    ON DELETE CASCADE,
  CONSTRAINT FK_DETCHK_TAREA FOREIGN KEY (id_tarea) REFERENCES TAREA_CHECKLIST (id_tarea)
);

CREATE TABLE REPORTE_FALLA (
  id_reporte          INT         NOT NULL AUTO_INCREMENT,
  fecha_reporte       DATETIME    NOT NULL,
  descripcion_problema TEXT       NOT NULL,
  canal               VARCHAR(30) NOT NULL,
  prioridad           VARCHAR(20) NULL,
  estado              VARCHAR(30) NOT NULL DEFAULT 'Registrado',
  id_usuario          INT         NOT NULL,
  id_equipo           INT         NOT NULL,
  id_tipo_falla       INT         NULL,
  CONSTRAINT PK_REPORTE_FALLA PRIMARY KEY (id_reporte),
  CONSTRAINT CK_REPORTE_CANAL     CHECK (canal IN ('QR','Formulario web')),
  CONSTRAINT CK_REPORTE_PRIORIDAD CHECK (prioridad IS NULL OR prioridad IN ('Baja','Media','Alta','Crítica')),
  CONSTRAINT CK_REPORTE_ESTADO    CHECK (estado IN ('Registrado','Con orden de trabajo','Cerrado')),
  CONSTRAINT FK_REPORTE_USUARIO FOREIGN KEY (id_usuario)    REFERENCES USUARIO (id_usuario),
  CONSTRAINT FK_REPORTE_EQUIPO  FOREIGN KEY (id_equipo)     REFERENCES EQUIPO (id_equipo),
  CONSTRAINT FK_REPORTE_TIPO    FOREIGN KEY (id_tipo_falla) REFERENCES TIPO_FALLA (id_tipo_falla)
);

CREATE TABLE ORDEN_TRABAJO (
  id_orden         INT         NOT NULL AUTO_INCREMENT,
  fecha_creacion   DATETIME    NOT NULL,
  prioridad        VARCHAR(20) NOT NULL,
  estado           VARCHAR(30) NOT NULL DEFAULT 'Creada',
  diagnostico      TEXT        NULL,
  fecha_asignacion DATETIME    NULL,
  fecha_cierre     DATETIME    NULL,
  id_reporte       INT         NULL,
  id_equipo        INT         NOT NULL,
  id_tecnico       INT         NULL,
  CONSTRAINT PK_ORDEN_TRABAJO PRIMARY KEY (id_orden),
  CONSTRAINT CK_OT_PRIORIDAD CHECK (prioridad IN ('Baja','Media','Alta','Crítica')),
  CONSTRAINT CK_OT_ESTADO CHECK (estado IN ('Creada','Asignada','En reparación','Resuelta','Observada','Cerrada')),
  CONSTRAINT CK_OT_FECHAS CHECK (fecha_cierre IS NULL OR fecha_cierre >= fecha_creacion),
  CONSTRAINT FK_OT_REPORTE FOREIGN KEY (id_reporte) REFERENCES REPORTE_FALLA (id_reporte),
  CONSTRAINT FK_OT_EQUIPO  FOREIGN KEY (id_equipo)  REFERENCES EQUIPO (id_equipo),
  CONSTRAINT FK_OT_TECNICO FOREIGN KEY (id_tecnico) REFERENCES TECNICO (id_tecnico)
);

CREATE TABLE DETALLE_ORDEN (
  id_orden       INT           NOT NULL,
  id_repuesto    INT           NOT NULL,
  cantidad       INT           NOT NULL,
  costo_aplicado DECIMAL(10,2) NOT NULL,   -- costo del repuesto al momento de la atención
  CONSTRAINT PK_DETALLE_ORDEN PRIMARY KEY (id_orden, id_repuesto),
  CONSTRAINT CK_DETORD_CANTIDAD CHECK (cantidad > 0),
  CONSTRAINT CK_DETORD_COSTO    CHECK (costo_aplicado >= 0),
  CONSTRAINT FK_DETORD_ORDEN    FOREIGN KEY (id_orden) REFERENCES ORDEN_TRABAJO (id_orden)
    ON DELETE CASCADE,
  CONSTRAINT FK_DETORD_REPUESTO FOREIGN KEY (id_repuesto) REFERENCES REPUESTO (id_repuesto)
);

-- ---------------------------------------------------------------------
-- Tablas de soporte (planificación, evidencias, alertas, configuración)
-- ---------------------------------------------------------------------
CREATE TABLE PLAN_MANTENIMIENTO (
  id_plan           INT          NOT NULL AUTO_INCREMENT,
  nombre            VARCHAR(100) NOT NULL,
  periodicidad_dias INT          NULL,
  horas_uso         INT          NULL,
  activo            BOOLEAN      NOT NULL DEFAULT TRUE,
  id_tipo_equipo    INT          NOT NULL,
  CONSTRAINT PK_PLAN PRIMARY KEY (id_plan),
  CONSTRAINT CK_PLAN_PERIODO CHECK (periodicidad_dias IS NOT NULL OR horas_uso IS NOT NULL),
  CONSTRAINT FK_PLAN_TIPO FOREIGN KEY (id_tipo_equipo) REFERENCES TIPO_EQUIPO (id_tipo_equipo)
);

CREATE TABLE PROGRAMACION_MANTENIMIENTO (
  id_programacion INT         NOT NULL AUTO_INCREMENT,
  fecha_programada DATE       NOT NULL,
  estado          VARCHAR(30) NOT NULL DEFAULT 'Programado',
  hora_inicio     TIME        NULL,
  hora_fin        TIME        NULL,
  id_plan         INT         NOT NULL,
  id_equipo       INT         NOT NULL,
  CONSTRAINT PK_PROGRAMACION PRIMARY KEY (id_programacion),
  CONSTRAINT CK_PROG_ESTADO CHECK (estado IN ('Programado','Reprogramado','Vencido','Ejecutado')),
  CONSTRAINT FK_PROG_PLAN   FOREIGN KEY (id_plan)   REFERENCES PLAN_MANTENIMIENTO (id_plan),
  CONSTRAINT FK_PROG_EQUIPO FOREIGN KEY (id_equipo) REFERENCES EQUIPO (id_equipo)
);

CREATE TABLE EVIDENCIA_ORDEN (
  id_evidencia INT          NOT NULL AUTO_INCREMENT,
  ruta_archivo VARCHAR(255) NOT NULL,
  fecha_carga  DATETIME     NOT NULL,
  id_orden     INT          NOT NULL,
  CONSTRAINT PK_EVIDENCIA PRIMARY KEY (id_evidencia),
  CONSTRAINT FK_EVID_ORDEN FOREIGN KEY (id_orden) REFERENCES ORDEN_TRABAJO (id_orden) ON DELETE CASCADE
);

CREATE TABLE ALERTA (
  id_alerta        INT          NOT NULL AUTO_INCREMENT,
  tipo             VARCHAR(40)  NOT NULL,
  fecha_generacion DATETIME     NOT NULL,
  mensaje          VARCHAR(255) NOT NULL,
  estado           VARCHAR(20)  NOT NULL DEFAULT 'Generada',
  id_orden         INT          NULL,
  id_programacion  INT          NULL,
  CONSTRAINT PK_ALERTA PRIMARY KEY (id_alerta),
  CONSTRAINT CK_ALERTA_ESTADO CHECK (estado IN ('Generada','Enviada','Atendida','Fallida')),
  CONSTRAINT FK_ALERTA_ORDEN FOREIGN KEY (id_orden) REFERENCES ORDEN_TRABAJO (id_orden),
  CONSTRAINT FK_ALERTA_PROG  FOREIGN KEY (id_programacion) REFERENCES PROGRAMACION_MANTENIMIENTO (id_programacion)
);

CREATE TABLE CONFIG_ALERTA (
  id_config_alerta INT          NOT NULL AUTO_INCREMENT,
  tipo_alerta      VARCHAR(40)  NOT NULL,
  canal            VARCHAR(30)  NOT NULL,
  destinatario     VARCHAR(120) NOT NULL,
  activo           BOOLEAN      NOT NULL DEFAULT TRUE,
  CONSTRAINT PK_CONFIG_ALERTA PRIMARY KEY (id_config_alerta),
  CONSTRAINT CK_CFGALERTA_CANAL CHECK (canal IN ('Correo','Sistema'))
);

CREATE TABLE AUDITORIA (
  id_auditoria   BIGINT       NOT NULL AUTO_INCREMENT,
  fecha          DATETIME     NOT NULL,
  accion         VARCHAR(100) NOT NULL,
  tabla_afectada VARCHAR(60)  NULL,
  id_registro    VARCHAR(50)  NULL,
  id_usuario     INT          NULL,
  CONSTRAINT PK_AUDITORIA PRIMARY KEY (id_auditoria),
  CONSTRAINT FK_AUDITORIA_USUARIO FOREIGN KEY (id_usuario) REFERENCES USUARIO (id_usuario)
);

CREATE TABLE CONFIG_GENERAL (
  id_parametro INT          NOT NULL AUTO_INCREMENT,
  clave        VARCHAR(80)  NOT NULL,
  valor        VARCHAR(255) NULL,
  descripcion  VARCHAR(200) NULL,
  CONSTRAINT PK_CONFIG_GENERAL PRIMARY KEY (id_parametro),
  CONSTRAINT UQ_CONFIG_CLAVE UNIQUE (clave)
);

CREATE TABLE RESPALDO (
  id_respaldo      INT          NOT NULL AUTO_INCREMENT,
  fecha_programada DATETIME     NOT NULL,
  fecha_ejecucion  DATETIME     NULL,
  estado           VARCHAR(30)  NOT NULL DEFAULT 'Programado',
  ubicacion        VARCHAR(255) NULL,
  CONSTRAINT PK_RESPALDO PRIMARY KEY (id_respaldo),
  CONSTRAINT CK_RESPALDO_ESTADO CHECK (estado IN ('Programado','Exitoso','Fallido'))
);


-- Vistas del modelo físico: los valores calculados no se almacenan en las tablas.
CREATE VIEW V_DETALLE_ORDEN_SUBTOTAL AS
SELECT d.id_orden, r.nombre AS repuesto, d.cantidad, d.costo_aplicado,
       d.cantidad * d.costo_aplicado AS subtotal
FROM DETALLE_ORDEN d JOIN REPUESTO r ON r.id_repuesto = d.id_repuesto;

CREATE VIEW V_ORDEN_COSTO_TOTAL AS
SELECT o.id_orden, o.fecha_creacion, o.estado, e.numero_serie,
       COALESCE(SUM(d.cantidad * d.costo_aplicado), 0) AS costo_total_repuestos
FROM ORDEN_TRABAJO o JOIN EQUIPO e ON e.id_equipo=o.id_equipo
LEFT JOIN DETALLE_ORDEN d ON d.id_orden=o.id_orden
GROUP BY o.id_orden,o.fecha_creacion,o.estado,e.numero_serie;

CREATE VIEW V_MANTENIMIENTO_DURACION AS
SELECT m.id_mantenimiento,m.tipo,e.numero_serie,t.nombre AS tecnico,
       m.fecha_inicio,m.fecha_fin,
       TIMESTAMPDIFF(MINUTE,m.fecha_inicio,m.fecha_fin) AS tiempo_empleado_min
FROM MANTENIMIENTO m JOIN EQUIPO e ON e.id_equipo=m.id_equipo
JOIN TECNICO t ON t.id_tecnico=m.id_tecnico;


-- Datos de demostración
-- Semillas de demostración de SCMP-LAB, alineadas con el capítulo 5 del informe.
-- Las contraseñas de los usuarios se almacenan en BCrypt; estos datos son solo para entorno local.
INSERT INTO ROL (nombre, descripcion) VALUES
 ('Administrador del sistema','Gestiona usuarios, roles, parámetros y respaldos'),
 ('Jefe de infraestructura TI','Planifica, asigna, prioriza y aprueba'),
 ('Administrador de laboratorio','Responsable del inventario del laboratorio'),
 ('Usuario de laboratorio','Docente o estudiante que reporta fallas');

INSERT INTO USUARIO (nombre, correo, clave_hash, estado, id_rol) VALUES
 ('Administrador del Sistema','admin@utp.edu.pe','$2a$10$Ww8uIOwaRDIJcwRPyGIh.erDWjnji4gOdWkX5xOKZXj2hke9FSrGS','Activo',1),
 ('Jefe de Infraestructura TI','jefe@utp.edu.pe','$2a$10$ENI36dogRnVJQYavp/G/nO1vNzJaNbQYj6OYgYPVeFQ/N7HOSaBNa','Activo',2),
 ('Administrador de Laboratorio','labadmin@utp.edu.pe','$2a$10$IS7.K.0Vlxq5VVjybhjiIuRU4cNbG38SNn17bCuDJvbMayngRlAl6','Activo',3),
 ('Docente de Laboratorio','docente@utp.edu.pe','$2a$10$KIpGnHmAzKRDGvl3ZxFik.zASH81Mua/hXVUU28Lkh5lL1lARpFr.','Activo',4);

INSERT INTO LABORATORIO (codigo,nombre,sede,piso,id_usuario_responsable) VALUES
 ('LIM-01','Laboratorio piloto','Lima','2',3);
INSERT INTO TIPO_EQUIPO (nombre,descripcion) VALUES
 ('PC','Computadora de escritorio'),('Laptop','Computadora portátil'),('Impresora','Equipo de impresión');
INSERT INTO EQUIPO (codigo_interno,numero_serie,marca,modelo,fecha_adquisicion,estado,id_tipo_equipo,id_laboratorio) VALUES
 ('EQ-PC-001','SN-UTP-0001','Dell','OptiPlex 7090','2025-03-10','Operativo',1,1),
 ('EQ-PC-002','SN-UTP-0002','Dell','OptiPlex 7090','2025-03-10','Operativo',1,1),
 ('EQ-PC-003','SN-UTP-0003','HP','ProDesk 600','2025-03-10','En mantenimiento',1,1);
INSERT INTO COMPONENTE (tipo,marca,capacidad) VALUES
 ('RAM','Kingston','16 GB'),('SSD','Kingston','512 GB'),('Fuente','Dell','240 W');
INSERT INTO INSTALACION_COMPONENTE (id_equipo,id_componente,fecha_instalacion) VALUES
 (1,1,'2025-03-10'),(1,2,'2025-03-10'),(1,3,'2025-03-10');
INSERT INTO TIPO_FALLA (nombre,descripcion) VALUES
 ('No enciende','El equipo no inicia'),('Falla de almacenamiento','El disco no es detectado');
INSERT INTO TECNICO (nombre,correo,especialidad) VALUES
 ('Técnico 01','tecnico01@utp.edu.pe','Hardware y mantenimiento');
INSERT INTO REPUESTO (nombre,costo_unitario,stock_referencial) VALUES
 ('SSD 512 GB',180.00,5),('Cable SATA',15.00,10),('Pasta térmica',12.00,8);
INSERT INTO TAREA_CHECKLIST (descripcion,id_tipo_equipo) VALUES
 ('Limpiar ventiladores y rejillas',1),('Revisar cableado y conexiones',1),
 ('Verificar temperatura del equipo',1),('Comprobar almacenamiento',1),('Verificar periféricos',1);
INSERT INTO MANTENIMIENTO (tipo,fecha_inicio,fecha_fin,resultado,observacion,id_equipo,id_tecnico) VALUES
 ('Preventivo','2026-10-05 08:00:00','2026-10-05 08:45:00','Conforme','Mantenimiento preventivo realizado sin incidencias',1,1);
INSERT INTO DETALLE_CHECKLIST (id_mantenimiento,id_tarea,resultado,comentario) VALUES
 (1,1,'Conforme','Limpieza realizada'),(1,2,'Conforme','Conexiones firmes'),
 (1,3,'Conforme','Temperatura dentro del rango esperado'),(1,4,'Conforme','SSD sin alertas'),
 (1,5,'Observado','Teclado con desgaste leve');
INSERT INTO REPORTE_FALLA (fecha_reporte,descripcion_problema,canal,prioridad,estado,id_usuario,id_equipo,id_tipo_falla) VALUES
 ('2026-09-30 10:15:00','El equipo no enciende al presionar el botón de inicio','Formulario web','Alta','Registrado',4,2,1),
 ('2026-09-30 10:10:00','El equipo no detecta el disco al iniciar','Formulario web','Alta','Con orden de trabajo',4,1,2);
INSERT INTO ORDEN_TRABAJO (fecha_creacion,prioridad,estado,diagnostico,fecha_asignacion,id_reporte,id_equipo,id_tecnico) VALUES
 ('2026-09-30 10:15:00','Alta','En reparación','SSD no detectado por el equipo','2026-09-30 10:20:00',2,1,1);
INSERT INTO DETALLE_ORDEN (id_orden,id_repuesto,cantidad,costo_aplicado) VALUES
 (1,1,1,180.00),(1,2,1,15.00),(1,3,1,12.00);
INSERT INTO PLAN_MANTENIMIENTO (nombre,periodicidad_dias,horas_uso,activo,id_tipo_equipo) VALUES
 ('Preventivo trimestral de PC',90,NULL,TRUE,1);
INSERT INTO PROGRAMACION_MANTENIMIENTO (fecha_programada,estado,hora_inicio,hora_fin,id_plan,id_equipo) VALUES
 ('2026-11-05','Programado','08:00:00','09:00:00',1,2);
INSERT INTO EVIDENCIA_ORDEN (ruta_archivo,fecha_carga,id_orden) VALUES
 ('referencia-demo/OT-001/diagnostico.txt','2026-09-30 10:30:00',1);
INSERT INTO ALERTA (tipo,fecha_generacion,mensaje,estado,id_orden,id_programacion) VALUES
 ('Mantenimiento programado','2026-10-27 08:00:00','Se aproxima el mantenimiento preventivo del equipo EQ-PC-002','Generada',NULL,1),
 ('Orden prioritaria','2026-09-30 10:20:00','La orden de trabajo 1 tiene prioridad alta','Generada',1,NULL);
INSERT INTO CONFIG_ALERTA (tipo_alerta,canal,destinatario,activo) VALUES
 ('Mantenimiento programado','Sistema','Jefe de infraestructura TI',TRUE),
 ('Orden prioritaria','Correo','infraestructura@utp.edu.pe',TRUE);
INSERT INTO AUDITORIA (fecha,accion,tabla_afectada,id_registro,id_usuario) VALUES
 ('2026-10-05 08:00:00','EJECUTAR_MANTENIMIENTO','MANTENIMIENTO','1',2),
 ('2026-09-30 10:15:00','REGISTRAR_REPORTE','REPORTE_FALLA','2',4);
INSERT INTO CONFIG_GENERAL (clave,valor,descripcion) VALUES
 ('nombre_sistema','SCMP-LAB','Nombre visible del sistema'),
 ('zona_horaria','America/Lima','Zona horaria de operación');
INSERT INTO RESPALDO (fecha_programada,fecha_ejecucion,estado,ubicacion) VALUES
 ('2026-11-01 02:00:00',NULL,'Programado',NULL);
