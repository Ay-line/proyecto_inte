package pe.utp.scmplab.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PanelDAOJdbc implements PanelDAO {

    private final JdbcTemplate jdbc;

    public PanelDAOJdbc(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private long contar(String sql, Object... args) {
        Long n = jdbc.queryForObject(sql, Long.class, args);
        return n == null ? 0 : n;
    }

    @Override
    public Map<String, Long> equiposPorEstado() {
        Map<String, Long> m = new LinkedHashMap<>();
        for (Map<String, Object> f : jdbc.queryForList("SELECT estado, COUNT(*) AS total FROM EQUIPO GROUP BY estado")) {
            m.put((String) f.get("estado"), ((Number) f.get("total")).longValue());
        }
        return m;
    }

    @Override
    public long reportesSinOrden() { return contar("SELECT COUNT(*) FROM REPORTE_FALLA WHERE estado = 'Registrado'"); }

    @Override
    public long reportesAbiertos() { return contar("SELECT COUNT(*) FROM REPORTE_FALLA WHERE estado <> 'Cerrado'"); }

    @Override
    public long reportesDeUsuario(int idUsuario, boolean soloAbiertos) {
        return soloAbiertos
                ? contar("SELECT COUNT(*) FROM REPORTE_FALLA WHERE id_usuario = ? AND estado <> 'Cerrado'", idUsuario)
                : contar("SELECT COUNT(*) FROM REPORTE_FALLA WHERE id_usuario = ?", idUsuario);
    }

    @Override
    public long ordenesAbiertas() { return contar("SELECT COUNT(*) FROM ORDEN_TRABAJO WHERE estado <> 'Cerrada'"); }

    @Override
    public long ordenesUrgentes() {
        return contar("SELECT COUNT(*) FROM ORDEN_TRABAJO WHERE estado <> 'Cerrada' AND prioridad IN ('Alta','Crítica')");
    }

    @Override
    public long alertasGeneradas() { return contar("SELECT COUNT(*) FROM ALERTA WHERE estado = 'Generada'"); }

    @Override
    public long programacionesVencidas(LocalDate hoy) {
        return contar("SELECT COUNT(*) FROM PROGRAMACION_MANTENIMIENTO WHERE estado IN ('Programado','Reprogramado') AND fecha_programada < ?", Date.valueOf(hoy));
    }

    @Override
    public long programacionesEntre(LocalDate desde, LocalDate hasta) {
        return contar("SELECT COUNT(*) FROM PROGRAMACION_MANTENIMIENTO WHERE estado IN ('Programado','Reprogramado') AND fecha_programada BETWEEN ? AND ?",
                Date.valueOf(desde), Date.valueOf(hasta));
    }

    @Override
    public List<Map<String, Object>> reportesSinOrdenRecientes(int limite) {
        return jdbc.queryForList("""
            SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, e.codigo_interno AS equipo,
                   COALESCE(r.prioridad, 'Sin prioridad') AS prioridad, r.descripcion_problema AS descripcion
            FROM REPORTE_FALLA r JOIN EQUIPO e ON e.id_equipo = r.id_equipo
            WHERE r.estado = 'Registrado'
            ORDER BY r.fecha_reporte DESC LIMIT ?
            """, limite);
    }

    @Override
    public List<Map<String, Object>> reportesRecientes(int limite, Integer idUsuario) {
        String base = """
            SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, e.codigo_interno AS equipo,
                   r.estado AS estado, r.descripcion_problema AS descripcion
            FROM REPORTE_FALLA r JOIN EQUIPO e ON e.id_equipo = r.id_equipo
            """;
        return idUsuario == null
                ? jdbc.queryForList(base + " ORDER BY r.fecha_reporte DESC LIMIT ?", limite)
                : jdbc.queryForList(base + " WHERE r.id_usuario = ? ORDER BY r.fecha_reporte DESC LIMIT ?", idUsuario, limite);
    }

    @Override
    public List<Map<String, Object>> ordenesAbiertasPrioritarias(int limite) {
        return jdbc.queryForList("""
            SELECT o.id_orden AS id, e.codigo_interno AS equipo, o.prioridad AS prioridad, o.estado AS estado,
                   COALESCE(t.nombre, 'Sin asignar') AS tecnico
            FROM ORDEN_TRABAJO o
            JOIN EQUIPO e ON e.id_equipo = o.id_equipo
            LEFT JOIN TECNICO t ON t.id_tecnico = o.id_tecnico
            WHERE o.estado <> 'Cerrada'
            ORDER BY CASE o.prioridad WHEN 'Crítica' THEN 1 WHEN 'Alta' THEN 2 WHEN 'Media' THEN 3 ELSE 4 END, o.fecha_creacion
            LIMIT ?
            """, limite);
    }

    @Override
    public List<Map<String, Object>> programacionesPendientes(LocalDate hoy, int limite) {
        return jdbc.queryForList("""
            SELECT pg.id_programacion AS id, pg.fecha_programada AS fecha, e.codigo_interno AS equipo, p.nombre AS plan,
                   CASE WHEN pg.fecha_programada < ? THEN 'Vencido' ELSE pg.estado END AS estado
            FROM PROGRAMACION_MANTENIMIENTO pg
            JOIN PLAN_MANTENIMIENTO p ON p.id_plan = pg.id_plan
            JOIN EQUIPO e ON e.id_equipo = pg.id_equipo
            WHERE pg.estado IN ('Programado','Reprogramado')
            ORDER BY pg.fecha_programada LIMIT ?
            """, Date.valueOf(hoy), limite);
    }
}
