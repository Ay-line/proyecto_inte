package pe.utp.scmplab.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import pe.utp.scmplab.security.CsrfToken;

import java.util.Set;

/** Rechaza cualquier petición que modifique datos si no trae el token de la sesión (formulario o cabecera). */
@Component
public class CsrfInterceptor implements HandlerInterceptor {

    private static final Logger LOG = LoggerFactory.getLogger(CsrfInterceptor.class);
    private static final Set<String> METODOS_SEGUROS = Set.of("GET", "HEAD", "OPTIONS", "TRACE");

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (METODOS_SEGUROS.contains(request.getMethod())) return true;
        HttpSession sesion = request.getSession(false);
        String esperado = sesion == null ? null : (String) sesion.getAttribute(CsrfToken.ATRIBUTO_SESION);
        String recibido = request.getParameter(CsrfToken.PARAMETRO);
        if (recibido == null) recibido = request.getHeader(CsrfToken.CABECERA);
        if (CsrfToken.coinciden(esperado, recibido)) return true;
        LOG.warn("Petición {} {} rechazada: token CSRF ausente o inválido", request.getMethod(), request.getRequestURI());
        response.sendError(HttpServletResponse.SC_FORBIDDEN, "Token de formulario inválido");
        return false;
    }

    /** Devuelve el token de la sesión, creándolo la primera vez. */
    public static String tokenDe(HttpSession sesion) {
        Object actual = sesion.getAttribute(CsrfToken.ATRIBUTO_SESION);
        if (actual instanceof String s && !s.isEmpty()) return s;
        String nuevo = CsrfToken.generar();
        sesion.setAttribute(CsrfToken.ATRIBUTO_SESION, nuevo);
        return nuevo;
    }
}
