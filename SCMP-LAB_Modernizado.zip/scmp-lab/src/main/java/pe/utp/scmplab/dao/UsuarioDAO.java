package pe.utp.scmplab.dao;

import pe.utp.scmplab.model.Usuario;

import java.time.LocalDateTime;
import java.util.Optional;

/** Acceso a datos de USUARIO. Es la única interfaz que habla con la tabla USUARIO. */
public interface UsuarioDAO {
    Optional<Usuario> buscarPorCorreo(String correo);

    Optional<Usuario> buscarPorId(int idUsuario);

    void actualizarIntentos(int idUsuario, int intentosFallidos, LocalDateTime bloqueadoHasta);
}
