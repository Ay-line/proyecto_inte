# SCMP-LAB — Fase 1: panel e inventario inicial

Esta versión amplía el proyecto inicial conservando Java 17, Spring Boot 3.3.5, Thymeleaf, JdbcTemplate y H2 en memoria.

## Qué se agregó

- Panel principal con indicadores que consultan las tablas de la base de datos activa.
- Navegación a Inventario de equipos, Laboratorios y Tipos de equipo.
- Consulta y registro de equipos con validación básica y control de códigos/números de serie duplicados por las restricciones de la base.
- Consulta y registro de laboratorios.
- Consulta y registro de tipos de equipo.
- Datos de demostración de un laboratorio, tres tipos y tres equipos para que las vistas no aparezcan vacías al arrancar.
- Restricciones sencillas de escritura por rol: administrador del sistema y jefe de infraestructura administran catálogos; el administrador de laboratorio también puede registrar equipos.
- Módulos de mantenimientos, reportes de fallas y órdenes de trabajo se muestran como pendientes y no como funciones completas.

## Ejecutar en Windows

Desde la carpeta que contiene `pom.xml`:

```powershell
mvn clean test
mvn spring-boot:run
```

Abrir `http://localhost:8080/login`.

## Usuarios de demostración

| Rol | Correo | Contraseña |
|---|---|---|
| Administrador del sistema | admin@utp.edu.pe | Admin#2026 |
| Jefe de infraestructura TI | jefe@utp.edu.pe | Jefe#2026 |
| Técnico de soporte TI | tecnico@utp.edu.pe | Tec#2026 |
| Administrador de laboratorio | labadmin@utp.edu.pe | Lab#2026 |
| Usuario de laboratorio | docente@utp.edu.pe | Doc#2026 |

## Importante sobre MySQL

La ejecución predeterminada sigue usando H2 en memoria. No activar todavía el perfil `mysql` contra la base existente: el SQL físico entregado por separado no contiene el mismo conjunto de tablas/columnas que el esquema de esta aplicación. Primero se deben reconciliar ambos esquemas y configurar la inicialización de MySQL de forma segura. Los datos de H2 se reinician al detener el proceso.

## Alcance y validación

Esta entrega se preparó a partir del ZIP inicial. En el entorno de preparación no estaba instalado Maven, por lo que la compilación de esta versión modificada todavía debe verificarse con `mvn clean test` en el equipo donde se ejecutará. No se afirma que los módulos de mantenimiento, reportes u órdenes ya estén implementados.
