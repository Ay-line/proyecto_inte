package pe.utp.scmplab.modulo;

import java.util.List;

/** Campo de un formulario de alta. El nombre coincide con la clave que lee el DAO. */
public final class Campo {
    private final String name;
    private final String label;
    private final String tipo;
    private boolean requerido;
    private boolean ancho;
    private boolean soloGestion;
    private Integer max;
    private String min;
    private String step;
    private String placeholder;
    private String opciones;
    private String vacio;
    private List<String> valores = List.of();

    private Campo(String name, String label, String tipo) { this.name = name; this.label = label; this.tipo = tipo; }

    public static Campo texto(String name, String label, int max) { Campo c = new Campo(name, label, "texto"); c.max = max; return c; }
    public static Campo correo(String name, String label, int max) { Campo c = new Campo(name, label, "correo"); c.max = max; return c; }
    public static Campo area(String name, String label, int max) { Campo c = new Campo(name, label, "area"); c.max = max; c.ancho = true; return c; }
    public static Campo numero(String name, String label) { return new Campo(name, label, "numero"); }
    public static Campo fecha(String name, String label) { return new Campo(name, label, "fecha"); }
    public static Campo fechaHora(String name, String label) { return new Campo(name, label, "fechahora"); }
    public static Campo hora(String name, String label) { return new Campo(name, label, "hora"); }
    public static Campo lista(String name, String label, String... valores) { Campo c = new Campo(name, label, "lista"); c.valores = List.of(valores); return c; }
    /** Lista cuyos valores salen de la base; {@code vacio} es el texto de la opción sin selección. */
    public static Campo seleccion(String name, String label, String opciones, String vacio) { Campo c = new Campo(name, label, "seleccion"); c.opciones = opciones; c.vacio = vacio; return c; }

    public Campo req() { this.requerido = true; return this; }
    public Campo ancho() { this.ancho = true; return this; }
    public Campo gestion() { this.soloGestion = true; return this; }
    public Campo min(String v) { this.min = v; return this; }
    public Campo step(String v) { this.step = v; return this; }
    public Campo ph(String v) { this.placeholder = v; return this; }

    public String getName() { return name; }
    public String getLabel() { return label; }
    public String getTipo() { return tipo; }
    public boolean isRequerido() { return requerido; }
    public boolean isAncho() { return ancho; }
    public boolean isSoloGestion() { return soloGestion; }
    public Integer getMax() { return max; }
    public String getMin() { return min; }
    public String getStep() { return step; }
    public String getPlaceholder() { return placeholder; }
    public String getOpciones() { return opciones; }
    public String getVacio() { return vacio; }
    public List<String> getValores() { return valores; }

    /** Tipo HTML del input (solo para los campos de una línea). */
    public String getHtmlType() {
        return switch (tipo) {
            case "correo" -> "email";
            case "numero" -> "number";
            case "fecha" -> "date";
            case "fechahora" -> "datetime-local";
            case "hora" -> "time";
            default -> "text";
        };
    }
}
