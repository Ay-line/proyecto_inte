package pe.utp.scmplab.web;

import pe.utp.scmplab.modulo.CatalogoModulos;
import pe.utp.scmplab.modulo.Grupo;
import pe.utp.scmplab.modulo.Modulo;
import pe.utp.scmplab.security.Accion;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.security.RolSistema;

import java.util.ArrayList;
import java.util.List;

/** Menú principal: Inicio y las secciones con los módulos que el rol puede consultar. */
public final class Navegacion {

    private Navegacion() { }

    public static final class Enlace {
        private final String titulo;
        private final String ruta;
        private final boolean activo;
        Enlace(String titulo, String ruta, boolean activo) { this.titulo = titulo; this.ruta = ruta; this.activo = activo; }
        public String getTitulo() { return titulo; }
        public String getRuta() { return ruta; }
        public boolean isActivo() { return activo; }
    }

    public static final class Seccion {
        private final String titulo;
        private final List<Enlace> enlaces;
        private final boolean activa;
        Seccion(String titulo, List<Enlace> enlaces, boolean activa) { this.titulo = titulo; this.enlaces = enlaces; this.activa = activa; }
        public String getTitulo() { return titulo; }
        public List<Enlace> getEnlaces() { return enlaces; }
        public boolean isActiva() { return activa; }
    }

    /** Solo se incluyen las secciones con al menos un módulo permitido. {@code ruta} es la ruta actual sin contexto. */
    public static List<Seccion> construir(PoliticaAcceso acceso, RolSistema rol, String ruta) {
        List<Seccion> secciones = new ArrayList<>();
        for (Grupo grupo : Grupo.values()) {
            List<Enlace> enlaces = new ArrayList<>();
            boolean activa = false;
            for (Modulo m : CatalogoModulos.todos()) {
                if (m.getGrupo() != grupo || !acceso.permite(rol, m.getClave(), Accion.VER)) continue;
                boolean activo = coincide(ruta, m.getRuta());
                activa |= activo;
                enlaces.add(new Enlace(m.getTitulo(), m.getRuta(), activo));
            }
            if (!enlaces.isEmpty()) secciones.add(new Seccion(grupo.getTitulo(), enlaces, activa));
        }
        return secciones;
    }

    static boolean coincide(String ruta, String base) {
        return ruta != null && (ruta.equals(base) || ruta.startsWith(base + "/"));
    }
}
