package pe.utp.scmplab.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** Generación y comparación del token anti-CSRF (sin dependencias de servlet para poder probarlo). */
public final class CsrfToken {

    public static final String ATRIBUTO_SESION = "scmp.csrf";
    public static final String PARAMETRO = "_csrf";
    public static final String CABECERA = "X-CSRF-TOKEN";

    private static final SecureRandom ALEATORIO = new SecureRandom();

    private CsrfToken() { }

    public static String generar() {
        byte[] bytes = new byte[32];
        ALEATORIO.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /** Comparación en tiempo constante; un token ausente o vacío nunca coincide. */
    public static boolean coinciden(String esperado, String recibido) {
        if (esperado == null || esperado.isEmpty() || recibido == null || recibido.isEmpty()) return false;
        return MessageDigest.isEqual(esperado.getBytes(StandardCharsets.UTF_8), recibido.getBytes(StandardCharsets.UTF_8));
    }
}
