package pe.utp.scmplab.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import pe.utp.scmplab.config.AuthInterceptor;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.security.Accion;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.service.PanelService;

import java.time.LocalDate;

/** Panel de inicio con indicadores de la base activa, distintos según el rol. */
@Controller
public class InicioController {
    private final PanelService panelService;
    private final PoliticaAcceso acceso;

    public InicioController(PanelService panelService, PoliticaAcceso acceso) {
        this.panelService = panelService;
        this.acceso = acceso;
    }

    @GetMapping({"/", "/inicio"})
    public String inicio(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario usuario, Model model,
                         @RequestParam(required = false) String sinPermiso) {
        var rol = acceso.rolDe(usuario);
        if (rol == null) {
            model.addAttribute("sinRol", true);
            return "inicio";
        }
        model.addAttribute("panel", panelService.construir(usuario, rol, LocalDate.now()));
        model.addAttribute("puedeReportar", acceso.permite(usuario, "reportes", Accion.CREAR));
        model.addAttribute("sinPermiso", sinPermiso != null);
        return "inicio";
    }
}
