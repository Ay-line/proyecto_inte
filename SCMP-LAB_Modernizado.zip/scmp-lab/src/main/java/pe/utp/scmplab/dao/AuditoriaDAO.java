package pe.utp.scmplab.dao;

import java.time.LocalDateTime;

/** Acceso a datos de AUDITORIA. Los registros solo se insertan; nunca se modifican. */
public interface AuditoriaDAO {
    void registrar(LocalDateTime fecha, String accion, String tablaAfectada, String idRegistro, Integer idUsuario);
}
