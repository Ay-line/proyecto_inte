package pe.utp.scmplab.service;

/** Resultado de validar o cerrar una sesión. */
public class ResultadoSesion {

    public enum Estado { VALIDA, INVALIDA, EXPIRADA, CERRADA, REQUIERE_CONFIRMACION }

    private final Estado estado;
    private final String mensaje;

    public ResultadoSesion(Estado estado, String mensaje) {
        this.estado = estado;
        this.mensaje = mensaje;
    }
    public Estado getEstado() { return estado; }
    public String getMensaje() { return mensaje; }
    public boolean esValida() { return estado == Estado.VALIDA; }
}
