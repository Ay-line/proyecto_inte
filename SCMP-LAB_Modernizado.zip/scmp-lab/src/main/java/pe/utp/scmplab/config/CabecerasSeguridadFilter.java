package pe.utp.scmplab.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/** Cabeceras de seguridad para todas las respuestas y sin caché para las páginas con datos de sesión. */
@Component
public class CabecerasSeguridadFilter extends OncePerRequestFilter {

    private static final String CSP = "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            + "form-action 'self'; frame-ancestors 'none'; base-uri 'self'";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String ruta = request.getRequestURI();
        if (!ruta.startsWith(request.getContextPath() + "/h2-console")) {
            response.setHeader("Content-Security-Policy", CSP);
            response.setHeader("X-Frame-Options", "DENY");
        }
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Referrer-Policy", "same-origin");
        boolean estatico = ruta.startsWith(request.getContextPath() + "/css/")
                || ruta.startsWith(request.getContextPath() + "/js/")
                || ruta.startsWith(request.getContextPath() + "/img/");
        if (!estatico) {
            response.setHeader("Cache-Control", "no-store");
        }
        chain.doFilter(request, response);
    }
}
