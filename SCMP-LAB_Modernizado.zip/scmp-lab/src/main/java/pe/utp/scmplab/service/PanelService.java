package pe.utp.scmplab.service;

import org.springframework.stereotype.Service;
import pe.utp.scmplab.dao.PanelDAO;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.modulo.Columna;
import pe.utp.scmplab.security.RolSistema;
import pe.utp.scmplab.web.Formato;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Arma los indicadores y listas del panel de inicio según el rol; todos los datos salen de la base activa. */
@Service
public class PanelService {

    private static final int LIMITE = 5;
    private static final int DIAS_PROXIMOS = 30;

    private final PanelDAO dao;

    public PanelService(PanelDAO dao) { this.dao = dao; }

    public Map<String, Object> construir(Usuario usuario, RolSistema rol, LocalDate hoy) {
        Map<String, Object> p = new LinkedHashMap<>();
        if (rol == RolSistema.USUARIO_LABORATORIO) {
            int id = usuario.getIdUsuario();
            p.put("vista", "usuario");
            p.put("misReportes", dao.reportesDeUsuario(id, false));
            p.put("misReportesAbiertos", dao.reportesDeUsuario(id, true));
            p.put("reportesRecientes", Formato.filas(dao.reportesRecientes(LIMITE, id), columnasReportes()));
            return p;
        }
        Map<String, Long> estados = dao.equiposPorEstado();
        long total = estados.values().stream().mapToLong(Long::longValue).sum();
        p.put("equiposTotal", total);
        p.put("equiposOperativos", estados.getOrDefault("Operativo", 0L));
        p.put("equiposMantenimiento", estados.getOrDefault("En mantenimiento", 0L));
        p.put("equiposInoperativos", estados.getOrDefault("Inoperativo", 0L));
        if (rol == RolSistema.ADMIN_LABORATORIO) {
            p.put("vista", "laboratorio");
            p.put("reportesAbiertos", dao.reportesAbiertos());
            p.put("reportesRecientes", Formato.filas(dao.reportesRecientes(LIMITE, null), columnasReportes()));
            return p;
        }
        p.put("vista", "gestion");
        p.put("reportesSinOrden", dao.reportesSinOrden());
        p.put("ordenesAbiertas", dao.ordenesAbiertas());
        p.put("ordenesUrgentes", dao.ordenesUrgentes());
        p.put("programacionesVencidas", dao.programacionesVencidas(hoy));
        p.put("programacionesProximas", dao.programacionesEntre(hoy, hoy.plusDays(DIAS_PROXIMOS)));
        p.put("alertasGeneradas", dao.alertasGeneradas());
        p.put("diasProximos", DIAS_PROXIMOS);
        p.put("reportesPendientes", Formato.filas(dao.reportesSinOrdenRecientes(LIMITE),
                List.of(new Columna("id", ""), new Columna("fecha", ""), new Columna("equipo", ""), new Columna("prioridad", "").etiqueta(), new Columna("descripcion", ""))));
        p.put("ordenesPrioritarias", Formato.filas(dao.ordenesAbiertasPrioritarias(LIMITE),
                List.of(new Columna("id", ""), new Columna("equipo", ""), new Columna("prioridad", "").etiqueta(), new Columna("estado", "").etiqueta(), new Columna("tecnico", ""))));
        p.put("programacionesPendientes", Formato.filas(dao.programacionesPendientes(hoy, LIMITE),
                List.of(new Columna("id", ""), new Columna("fecha", ""), new Columna("equipo", ""), new Columna("plan", ""), new Columna("estado", "").etiqueta())));
        return p;
    }

    private static List<Columna> columnasReportes() {
        return List.of(new Columna("id", ""), new Columna("fecha", ""), new Columna("equipo", ""), new Columna("estado", "").etiqueta(), new Columna("descripcion", ""));
    }
}
