package pe.utp.scmplab.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class OperacionesDAOJdbc implements OperacionesDAO {
    private final JdbcTemplate jdbc;
    public OperacionesDAOJdbc(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public List<Map<String, Object>> listar(String m, Integer idUsuario) {
        if ("reportes".equals(m) && idUsuario != null) {
            return jdbc.queryForList("""
                SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, u.nombre AS usuario, e.codigo_interno AS equipo,
                       COALESCE(tf.nombre, 'Sin clasificar') AS tipo_falla, r.canal,
                       COALESCE(r.prioridad, 'Sin prioridad') AS prioridad, r.estado,
                       r.descripcion_problema AS descripcion
                FROM REPORTE_FALLA r JOIN USUARIO u ON u.id_usuario=r.id_usuario
                JOIN EQUIPO e ON e.id_equipo=r.id_equipo
                LEFT JOIN TIPO_FALLA tf ON tf.id_tipo_falla=r.id_tipo_falla
                WHERE r.id_usuario=? ORDER BY r.fecha_reporte DESC
                """, idUsuario);
        }
        String sql = switch (m) {
            case "hoja-vida" -> "SELECT e.codigo_interno AS codigo, e.numero_serie AS serie, COALESCE(e.marca,'—') AS marca_equipo, COALESCE(e.modelo,'—') AS modelo, e.fecha_adquisicion AS adquisicion, e.estado, te.nombre AS tipo_equipo, l.codigo AS codigo_laboratorio, l.nombre AS laboratorio, COALESCE(c.tipo,'—') AS componente, COALESCE(c.marca,'—') AS marca_componente, COALESCE(c.capacidad,'—') AS capacidad, i.fecha_instalacion, i.fecha_retiro FROM EQUIPO e JOIN TIPO_EQUIPO te ON te.id_tipo_equipo=e.id_tipo_equipo JOIN LABORATORIO l ON l.id_laboratorio=e.id_laboratorio LEFT JOIN INSTALACION_COMPONENTE i ON i.id_equipo=e.id_equipo LEFT JOIN COMPONENTE c ON c.id_componente=i.id_componente ORDER BY e.codigo_interno,c.tipo";
            case "inventario-laboratorios" -> "SELECT l.codigo AS codigo_laboratorio, l.nombre AS laboratorio, l.sede, COALESCE(l.piso,'—') AS piso, COALESCE(u.nombre,'Sin responsable') AS responsable, COALESCE(e.codigo_interno,'Sin equipos') AS equipo, COALESCE(te.nombre,'—') AS tipo_equipo, COALESCE(e.numero_serie,'—') AS serie, COALESCE(e.marca,'—') AS marca, COALESCE(e.modelo,'—') AS modelo, COALESCE(e.estado,'—') AS estado FROM LABORATORIO l LEFT JOIN USUARIO u ON u.id_usuario=l.id_usuario_responsable LEFT JOIN EQUIPO e ON e.id_laboratorio=l.id_laboratorio LEFT JOIN TIPO_EQUIPO te ON te.id_tipo_equipo=e.id_tipo_equipo ORDER BY l.codigo,e.codigo_interno";
            case "componentes" -> "SELECT id_componente AS id, tipo, COALESCE(marca,'—') AS marca, COALESCE(capacidad,'—') AS capacidad FROM COMPONENTE ORDER BY id_componente DESC";
            case "instalaciones" -> "SELECT e.codigo_interno AS equipo, c.tipo AS componente, COALESCE(c.marca,'—') AS marca, i.fecha_instalacion AS fecha_instalacion, i.fecha_retiro AS fecha_retiro FROM INSTALACION_COMPONENTE i JOIN EQUIPO e ON e.id_equipo=i.id_equipo JOIN COMPONENTE c ON c.id_componente=i.id_componente ORDER BY i.fecha_instalacion DESC";
            case "tecnicos" -> "SELECT id_tecnico AS id, nombre, COALESCE(correo,'—') AS correo, COALESCE(especialidad,'—') AS especialidad FROM TECNICO ORDER BY nombre";
            case "repuestos" -> "SELECT id_repuesto AS id, nombre, costo_unitario AS costo, stock_referencial AS stock FROM REPUESTO ORDER BY nombre";
            case "tipos-falla" -> "SELECT id_tipo_falla AS id, nombre, COALESCE(descripcion,'—') AS descripcion FROM TIPO_FALLA ORDER BY nombre";
            case "checklist-tareas" -> "SELECT t.id_tarea AS id, t.descripcion, te.nombre AS tipo_equipo FROM TAREA_CHECKLIST t JOIN TIPO_EQUIPO te ON te.id_tipo_equipo=t.id_tipo_equipo ORDER BY te.nombre,t.id_tarea";
            case "mantenimientos" -> "SELECT m.id_mantenimiento AS id, m.tipo, e.codigo_interno AS equipo, t.nombre AS tecnico, m.fecha_inicio AS inicio, m.fecha_fin AS fin, dur.tiempo_empleado_min AS duracion_min, m.resultado, COALESCE(m.observacion,'—') AS observacion FROM MANTENIMIENTO m JOIN EQUIPO e ON e.id_equipo=m.id_equipo JOIN TECNICO t ON t.id_tecnico=m.id_tecnico LEFT JOIN V_MANTENIMIENTO_DURACION dur ON dur.id_mantenimiento=m.id_mantenimiento ORDER BY m.fecha_inicio DESC";
            case "checklist-detalle" -> "SELECT d.id_mantenimiento AS mantenimiento, e.codigo_interno AS equipo, d.id_tarea AS tarea, tc.descripcion, d.resultado, COALESCE(d.comentario,'—') AS comentario FROM DETALLE_CHECKLIST d JOIN MANTENIMIENTO m ON m.id_mantenimiento=d.id_mantenimiento JOIN EQUIPO e ON e.id_equipo=m.id_equipo JOIN TAREA_CHECKLIST tc ON tc.id_tarea=d.id_tarea ORDER BY d.id_mantenimiento DESC,d.id_tarea";
            case "reportes" -> "SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, u.nombre AS usuario, e.codigo_interno AS equipo, COALESCE(tf.nombre,'Sin clasificar') AS tipo_falla, r.canal, COALESCE(r.prioridad,'Sin prioridad') AS prioridad, r.estado, r.descripcion_problema AS descripcion FROM REPORTE_FALLA r JOIN USUARIO u ON u.id_usuario=r.id_usuario JOIN EQUIPO e ON e.id_equipo=r.id_equipo LEFT JOIN TIPO_FALLA tf ON tf.id_tipo_falla=r.id_tipo_falla ORDER BY r.fecha_reporte DESC";
            case "ordenes" -> "SELECT o.id_orden AS id, o.fecha_creacion AS fecha, e.codigo_interno AS equipo, o.prioridad, o.estado, COALESCE(t.nombre,'Sin asignar') AS tecnico, COALESCE(o.diagnostico,'—') AS diagnostico, COALESCE(ct.costo_total_repuestos,0) AS costo_repuestos FROM ORDEN_TRABAJO o JOIN EQUIPO e ON e.id_equipo=o.id_equipo LEFT JOIN TECNICO t ON t.id_tecnico=o.id_tecnico LEFT JOIN V_ORDEN_COSTO_TOTAL ct ON ct.id_orden=o.id_orden ORDER BY o.fecha_creacion DESC";
            case "detalle-orden" -> "SELECT d.id_orden AS orden, d.repuesto, d.cantidad, d.costo_aplicado AS costo_unitario, d.subtotal FROM V_DETALLE_ORDEN_SUBTOTAL d ORDER BY d.id_orden DESC";
            case "planes" -> "SELECT p.id_plan AS id, p.nombre, te.nombre AS tipo_equipo, p.periodicidad_dias AS periodicidad_dias, p.horas_uso, p.activo FROM PLAN_MANTENIMIENTO p JOIN TIPO_EQUIPO te ON te.id_tipo_equipo=p.id_tipo_equipo ORDER BY p.nombre";
            case "programaciones" -> "SELECT pg.id_programacion AS id, pg.fecha_programada AS fecha, pg.estado, pg.hora_inicio AS hora_inicio, pg.hora_fin AS hora_fin, p.nombre AS plan, e.codigo_interno AS equipo FROM PROGRAMACION_MANTENIMIENTO pg JOIN PLAN_MANTENIMIENTO p ON p.id_plan=pg.id_plan JOIN EQUIPO e ON e.id_equipo=pg.id_equipo ORDER BY pg.fecha_programada";
            case "evidencias" -> "SELECT ev.id_evidencia AS id, ev.ruta_archivo, ev.fecha_carga, ev.id_orden AS orden FROM EVIDENCIA_ORDEN ev ORDER BY ev.fecha_carga DESC";
            case "alertas" -> "SELECT a.id_alerta AS id, a.tipo, a.fecha_generacion AS fecha, a.mensaje, a.estado, a.id_orden AS orden, a.id_programacion AS programacion FROM ALERTA a ORDER BY a.fecha_generacion DESC";
            case "config-alertas" -> "SELECT id_config_alerta AS id, tipo_alerta, canal, destinatario, activo FROM CONFIG_ALERTA ORDER BY tipo_alerta";
            case "auditoria" -> "SELECT a.id_auditoria AS id, a.fecha, a.accion, COALESCE(a.tabla_afectada,'—') AS tabla, COALESCE(a.id_registro,'—') AS registro, COALESCE(u.correo,'sistema') AS usuario FROM AUDITORIA a LEFT JOIN USUARIO u ON u.id_usuario=a.id_usuario ORDER BY a.fecha DESC";
            case "configuracion" -> "SELECT id_parametro AS id, clave, COALESCE(valor,'—') AS valor, COALESCE(descripcion,'—') AS descripcion FROM CONFIG_GENERAL ORDER BY clave";
            case "respaldos" -> "SELECT id_respaldo AS id, fecha_programada, fecha_ejecucion, estado, COALESCE(ubicacion,'—') AS ubicacion FROM RESPALDO ORDER BY fecha_programada DESC";
            case "usuarios" -> "SELECT u.id_usuario AS id, u.nombre, u.correo, u.estado, r.nombre AS rol FROM USUARIO u JOIN ROL r ON r.id_rol=u.id_rol ORDER BY u.nombre";
            case "roles" -> "SELECT id_rol AS id, nombre, COALESCE(descripcion,'—') AS descripcion FROM ROL ORDER BY id_rol";
            default -> throw new IllegalArgumentException("Módulo no válido.");
        };
        return jdbc.queryForList(sql);
    }

    @Override
    public List<Map<String, Object>> opciones(String c) {
        String sql = switch (c) {
            case "equipos" -> "SELECT id_equipo AS id, codigo_interno AS nombre FROM EQUIPO ORDER BY codigo_interno";
            case "laboratorios" -> "SELECT id_laboratorio AS id, CONCAT(codigo,' — ',nombre) AS nombre FROM LABORATORIO ORDER BY codigo";
            case "tipos-equipo" -> "SELECT id_tipo_equipo AS id, nombre FROM TIPO_EQUIPO ORDER BY nombre";
            case "componentes" -> "SELECT id_componente AS id, CONCAT(tipo,' — ',COALESCE(marca,''),' ',COALESCE(capacidad,'')) AS nombre FROM COMPONENTE ORDER BY tipo";
            case "tecnicos" -> "SELECT id_tecnico AS id, nombre FROM TECNICO ORDER BY nombre";
            case "tipos-falla" -> "SELECT id_tipo_falla AS id, nombre FROM TIPO_FALLA ORDER BY nombre";
            case "tareas" -> "SELECT id_tarea AS id, descripcion AS nombre FROM TAREA_CHECKLIST ORDER BY descripcion";
            case "mantenimientos" -> "SELECT id_mantenimiento AS id, CONCAT('Mantenimiento #',id_mantenimiento,' — ',tipo) AS nombre FROM MANTENIMIENTO ORDER BY id_mantenimiento DESC";
            case "reportes" -> "SELECT id_reporte AS id, CONCAT('Reporte #',id_reporte,' — ',estado) AS nombre FROM REPORTE_FALLA ORDER BY id_reporte DESC";
            case "ordenes" -> "SELECT id_orden AS id, CONCAT('Orden #',id_orden,' — ',estado) AS nombre FROM ORDEN_TRABAJO ORDER BY id_orden DESC";
            case "repuestos" -> "SELECT id_repuesto AS id, CONCAT(nombre,' (S/ ',costo_unitario,')') AS nombre FROM REPUESTO ORDER BY nombre";
            case "planes" -> "SELECT id_plan AS id, nombre FROM PLAN_MANTENIMIENTO WHERE activo=TRUE ORDER BY nombre";
            case "programaciones" -> "SELECT id_programacion AS id, CONCAT('Programación #',id_programacion) AS nombre FROM PROGRAMACION_MANTENIMIENTO ORDER BY id_programacion DESC";
            default -> throw new IllegalArgumentException("Catálogo de opciones no válido.");
        };
        return jdbc.queryForList(sql);
    }

    @Override
    @Transactional
    public void crear(String m, Map<String, String> f, Integer idUsuario) {
        switch (m) {
            case "componentes" -> jdbc.update("INSERT INTO COMPONENTE(tipo,marca,capacidad) VALUES(?,?,?)", req(f,"tipo"), nullable(f.get("marca")), nullable(f.get("capacidad")));
            case "instalaciones" -> {
                Date instalacion = Date.valueOf(req(f,"fecha_instalacion")); Date retiro = date(f.get("fecha_retiro"));
                if (retiro != null && retiro.before(instalacion)) throw new IllegalArgumentException("La fecha de retiro no puede ser anterior a la de instalación.");
                jdbc.update("INSERT INTO INSTALACION_COMPONENTE(id_equipo,id_componente,fecha_instalacion,fecha_retiro) VALUES(?,?,?,?)", integer(f,"id_equipo"), integer(f,"id_componente"), instalacion, retiro);
            }
            case "tecnicos" -> jdbc.update("INSERT INTO TECNICO(nombre,correo,especialidad) VALUES(?,?,?)", req(f,"nombre"), nullable(f.get("correo")), nullable(f.get("especialidad")));
            case "repuestos" -> jdbc.update("INSERT INTO REPUESTO(nombre,costo_unitario,stock_referencial) VALUES(?,?,?)", req(f,"nombre"), decimal(f,"costo_unitario"), nullableInt(f.get("stock_referencial")));
            case "tipos-falla" -> jdbc.update("INSERT INTO TIPO_FALLA(nombre,descripcion) VALUES(?,?)", req(f,"nombre"), nullable(f.get("descripcion")));
            case "checklist-tareas" -> jdbc.update("INSERT INTO TAREA_CHECKLIST(descripcion,id_tipo_equipo) VALUES(?,?)", req(f,"descripcion"), integer(f,"id_tipo_equipo"));
            case "mantenimientos" -> {
                Timestamp inicio = timestamp(req(f,"fecha_inicio")); Timestamp fin = timestampNullable(f.get("fecha_fin"));
                if (fin != null && fin.before(inicio)) throw new IllegalArgumentException("La fecha de fin no puede ser anterior al inicio.");
                jdbc.update("INSERT INTO MANTENIMIENTO(tipo,fecha_inicio,fecha_fin,resultado,observacion,id_equipo,id_tecnico) VALUES(?,?,?,?,?,?,?)", oneOf(req(f,"tipo"),"Preventivo","Correctivo"), inicio, fin, oneOf(req(f,"resultado"),"Conforme","Observado"), nullable(f.get("observacion")), integer(f,"id_equipo"), integer(f,"id_tecnico"));
            }
            case "checklist-detalle" -> jdbc.update("INSERT INTO DETALLE_CHECKLIST(id_mantenimiento,id_tarea,resultado,comentario) VALUES(?,?,?,?)", integer(f,"id_mantenimiento"), integer(f,"id_tarea"), oneOf(req(f,"resultado"),"Conforme","Observado","No aplica"), nullable(f.get("comentario")));
            case "reportes" -> {
                if (idUsuario == null) throw new IllegalArgumentException("No se pudo identificar al usuario de la sesión.");
                jdbc.update("INSERT INTO REPORTE_FALLA(fecha_reporte,descripcion_problema,canal,prioridad,estado,id_usuario,id_equipo,id_tipo_falla) VALUES(?,?,?,?, 'Registrado',?,?,?)", Timestamp.valueOf(LocalDateTime.now()), req(f,"descripcion_problema"), oneOf(req(f,"canal"),"QR","Formulario web"), oneOfNullable(f.get("prioridad"),"Baja","Media","Alta","Crítica"), idUsuario, integer(f,"id_equipo"), nullableInt(f.get("id_tipo_falla")));
            }
            case "ordenes" -> {
                Integer idReporte = nullableInt(f.get("id_reporte"));
                int idEquipo = integer(f,"id_equipo");
                Integer idTecnico = nullableInt(f.get("id_tecnico"));
                if (idReporte != null) {
                    List<Integer> equiposReporte = jdbc.query("SELECT id_equipo FROM REPORTE_FALLA WHERE id_reporte=?", (rs, rowNum) -> rs.getInt(1), idReporte);
                    if (equiposReporte.isEmpty()) throw new IllegalArgumentException("El reporte seleccionado no existe.");
                    if (equiposReporte.get(0) != idEquipo) throw new IllegalArgumentException("El equipo de la orden debe coincidir con el equipo del reporte seleccionado.");
                }
                // Con técnico la orden nace asignada y con su fecha de asignación; sin técnico queda creada.
                Timestamp ahora = Timestamp.valueOf(LocalDateTime.now());
                jdbc.update("INSERT INTO ORDEN_TRABAJO(fecha_creacion,prioridad,estado,diagnostico,fecha_asignacion,fecha_cierre,id_reporte,id_equipo,id_tecnico) VALUES(?,?,?,?,?,NULL,?,?,?)", ahora, oneOf(req(f,"prioridad"),"Baja","Media","Alta","Crítica"), idTecnico == null ? "Creada" : "Asignada", nullable(f.get("diagnostico")), idTecnico == null ? null : ahora, idReporte, idEquipo, idTecnico);
                if (idReporte != null) jdbc.update("UPDATE REPORTE_FALLA SET estado='Con orden de trabajo' WHERE id_reporte=? AND estado <> 'Cerrado'", idReporte);
            }
            case "detalle-orden" -> {
                int order = integer(f,"id_orden"); int spare = integer(f,"id_repuesto"); int qty = integer(f,"cantidad");
                if (qty <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
                int inserted = jdbc.update("INSERT INTO DETALLE_ORDEN(id_orden,id_repuesto,cantidad,costo_aplicado) SELECT ?,id_repuesto,?,costo_unitario FROM REPUESTO WHERE id_repuesto=?", order, qty, spare);
                if (inserted == 0) throw new IllegalArgumentException("No se encontró el repuesto seleccionado.");
            }
            case "planes" -> {
                Integer days = nullableInt(f.get("periodicidad_dias")); Integer hours = nullableInt(f.get("horas_uso"));
                if ((days == null || days <= 0) && (hours == null || hours <= 0)) throw new IllegalArgumentException("Indica una periodicidad en días o una referencia de horas de uso mayor que cero.");
                jdbc.update("INSERT INTO PLAN_MANTENIMIENTO(nombre,periodicidad_dias,horas_uso,activo,id_tipo_equipo) VALUES(?,?,?,TRUE,?)", req(f,"nombre"), days, hours, integer(f,"id_tipo_equipo"));
            }
            case "programaciones" -> jdbc.update("INSERT INTO PROGRAMACION_MANTENIMIENTO(fecha_programada,estado,hora_inicio,hora_fin,id_plan,id_equipo) VALUES(?,?,?, ?,?,?)", Date.valueOf(req(f,"fecha_programada")), oneOf(req(f,"estado"),"Programado","Reprogramado","Vencido","Ejecutado"), time(f.get("hora_inicio")), time(f.get("hora_fin")), integer(f,"id_plan"), integer(f,"id_equipo"));
            case "evidencias" -> jdbc.update("INSERT INTO EVIDENCIA_ORDEN(ruta_archivo,fecha_carga,id_orden) VALUES(?,?,?)", req(f,"ruta_archivo"), Timestamp.valueOf(LocalDateTime.now()), integer(f,"id_orden"));
            case "alertas" -> jdbc.update("INSERT INTO ALERTA(tipo,fecha_generacion,mensaje,estado,id_orden,id_programacion) VALUES(?,?,?,'Generada',?,?)", req(f,"tipo"), Timestamp.valueOf(LocalDateTime.now()), req(f,"mensaje"), nullableInt(f.get("id_orden")), nullableInt(f.get("id_programacion")));
            case "config-alertas" -> jdbc.update("INSERT INTO CONFIG_ALERTA(tipo_alerta,canal,destinatario,activo) VALUES(?,?,?,TRUE)", req(f,"tipo_alerta"), oneOf(req(f,"canal"),"Correo","Sistema"), req(f,"destinatario"));
            case "configuracion" -> jdbc.update("INSERT INTO CONFIG_GENERAL(clave,valor,descripcion) VALUES(?,?,?)", req(f,"clave"), nullable(f.get("valor")), nullable(f.get("descripcion")));
            case "respaldos" -> jdbc.update("INSERT INTO RESPALDO(fecha_programada,estado,ubicacion) VALUES(?,'Programado',?)", timestamp(req(f,"fecha_programada")), nullable(f.get("ubicacion")));
            default -> throw new IllegalArgumentException("Este módulo es de consulta o no admite altas desde esta pantalla.");
        }
    }

    @Override
    @Transactional
    public void actualizarEstadoOrden(int idOrden, String estado) {
        oneOf(estado,"Creada","Asignada","En reparación","Resuelta","Observada","Cerrada");
        List<Map<String, Object>> actual = jdbc.queryForList("SELECT estado, id_tecnico FROM ORDEN_TRABAJO WHERE id_orden=?", idOrden);
        if (actual.isEmpty()) throw new IllegalArgumentException("No se encontró la orden de trabajo.");
        if (!"Creada".equals(estado) && actual.get(0).get("id_tecnico") == null) throw new IllegalArgumentException("Asigna un técnico antes de avanzar el estado de la orden.");
        Timestamp now = Timestamp.valueOf(LocalDateTime.now());
        jdbc.update("UPDATE ORDEN_TRABAJO SET estado=?, fecha_asignacion=CASE WHEN ?='Asignada' AND fecha_asignacion IS NULL THEN ? ELSE fecha_asignacion END, fecha_cierre=CASE WHEN ?='Cerrada' AND fecha_cierre IS NULL THEN ? WHEN ?<>'Cerrada' THEN NULL ELSE fecha_cierre END WHERE id_orden=?", estado, estado, now, estado, now, estado, idOrden);
        if ("Cerrada".equals(estado)) jdbc.update("UPDATE REPORTE_FALLA SET estado='Cerrado' WHERE id_reporte=(SELECT id_reporte FROM ORDEN_TRABAJO WHERE id_orden=?) AND id_reporte IS NOT NULL", idOrden);
        else jdbc.update("UPDATE REPORTE_FALLA SET estado='Con orden de trabajo' WHERE id_reporte=(SELECT id_reporte FROM ORDEN_TRABAJO WHERE id_orden=?) AND id_reporte IS NOT NULL", idOrden);
    }

    @Override
    @Transactional
    public void asignarTecnicoOrden(int idOrden, int idTecnico) {
        List<String> estados = jdbc.query("SELECT estado FROM ORDEN_TRABAJO WHERE id_orden=?", (rs, i) -> rs.getString(1), idOrden);
        if (estados.isEmpty()) throw new IllegalArgumentException("No se encontró la orden de trabajo.");
        if ("Cerrada".equals(estados.get(0))) throw new IllegalArgumentException("Una orden cerrada no puede reasignarse.");
        Integer existe = jdbc.queryForObject("SELECT COUNT(*) FROM TECNICO WHERE id_tecnico=?", Integer.class, idTecnico);
        if (existe == null || existe == 0) throw new IllegalArgumentException("El técnico seleccionado no existe.");
        jdbc.update("UPDATE ORDEN_TRABAJO SET id_tecnico=?, fecha_asignacion=?, estado=CASE WHEN estado='Creada' THEN 'Asignada' ELSE estado END WHERE id_orden=?", idTecnico, Timestamp.valueOf(LocalDateTime.now()), idOrden);
    }

    @Override
    @Transactional
    public void clasificarReporte(int idReporte, String prioridad, Integer idTipoFalla) {
        String p = oneOfNullable(prioridad,"Baja","Media","Alta","Crítica");
        int n = jdbc.update("UPDATE REPORTE_FALLA SET prioridad=?, id_tipo_falla=? WHERE id_reporte=?", p, idTipoFalla, idReporte);
        if (n == 0) throw new IllegalArgumentException("No se encontró el reporte.");
    }

    @Override
    public Optional<Map<String, Object>> buscarOrden(int id) {
        return jdbc.queryForList("""
            SELECT o.id_orden AS id, o.fecha_creacion AS fecha, o.prioridad, o.estado, o.diagnostico,
                   o.fecha_asignacion AS asignada, o.fecha_cierre AS cierre, o.id_reporte AS id_reporte,
                   e.id_equipo AS id_equipo, e.codigo_interno AS equipo, e.numero_serie AS serie,
                   e.marca AS marca_equipo, e.modelo AS modelo_equipo, l.nombre AS laboratorio,
                   o.id_tecnico AS id_tecnico, t.nombre AS tecnico,
                   COALESCE(ct.costo_total_repuestos, 0) AS costo_total
            FROM ORDEN_TRABAJO o
            JOIN EQUIPO e ON e.id_equipo = o.id_equipo
            JOIN LABORATORIO l ON l.id_laboratorio = e.id_laboratorio
            LEFT JOIN TECNICO t ON t.id_tecnico = o.id_tecnico
            LEFT JOIN V_ORDEN_COSTO_TOTAL ct ON ct.id_orden = o.id_orden
            WHERE o.id_orden = ?
            """, id).stream().findFirst();
    }

    @Override
    public List<Map<String, Object>> repuestosDeOrden(int id) {
        return jdbc.queryForList("SELECT repuesto, cantidad, costo_aplicado AS costo, subtotal FROM V_DETALLE_ORDEN_SUBTOTAL WHERE id_orden=? ORDER BY repuesto", id);
    }

    @Override
    public List<Map<String, Object>> evidenciasDeOrden(int id) {
        return jdbc.queryForList("SELECT ruta_archivo, fecha_carga FROM EVIDENCIA_ORDEN WHERE id_orden=? ORDER BY fecha_carga DESC", id);
    }

    @Override
    public Optional<Map<String, Object>> buscarReporte(int id) {
        return jdbc.queryForList("""
            SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, r.descripcion_problema AS descripcion, r.canal,
                   r.prioridad, r.estado, r.id_usuario AS id_usuario, u.nombre AS usuario,
                   r.id_equipo AS id_equipo, e.codigo_interno AS equipo, e.numero_serie AS serie,
                   l.nombre AS laboratorio, r.id_tipo_falla AS id_tipo_falla, tf.nombre AS tipo_falla
            FROM REPORTE_FALLA r
            JOIN USUARIO u ON u.id_usuario = r.id_usuario
            JOIN EQUIPO e ON e.id_equipo = r.id_equipo
            JOIN LABORATORIO l ON l.id_laboratorio = e.id_laboratorio
            LEFT JOIN TIPO_FALLA tf ON tf.id_tipo_falla = r.id_tipo_falla
            WHERE r.id_reporte = ?
            """, id).stream().findFirst();
    }

    @Override
    public List<Map<String, Object>> ordenesDeReporte(int id) {
        return jdbc.queryForList("SELECT o.id_orden AS id, o.fecha_creacion AS fecha, o.prioridad, o.estado, COALESCE(t.nombre,'Sin asignar') AS tecnico FROM ORDEN_TRABAJO o LEFT JOIN TECNICO t ON t.id_tecnico=o.id_tecnico WHERE o.id_reporte=? ORDER BY o.fecha_creacion DESC", id);
    }

    private static String req(Map<String,String> f,String k){String v=f.get(k);if(v==null||v.isBlank())throw new IllegalArgumentException("El campo '"+k.replace('_',' ') +"' es obligatorio.");return v.trim();}
    private static String nullable(String v){return v==null||v.isBlank()?null:v.trim();}
    private static Integer integer(Map<String,String> f,String k){try{return Integer.valueOf(req(f,k));}catch(NumberFormatException e){throw new IllegalArgumentException("Selecciona un valor numérico válido.");}}
    private static Integer nullableInt(String s){if(s==null||s.isBlank())return null;try{return Integer.valueOf(s.trim());}catch(NumberFormatException e){throw new IllegalArgumentException("El valor numérico no es válido.");}}
    private static BigDecimal decimal(Map<String,String> f,String k){try{BigDecimal n=new BigDecimal(req(f,k));if(n.signum()<0)throw new IllegalArgumentException("El costo no puede ser negativo.");return n;}catch(NumberFormatException e){throw new IllegalArgumentException("Introduce un costo válido.");}}
    private static Date date(String s){return s==null||s.isBlank()?null:Date.valueOf(s);}
    private static Timestamp timestamp(String s){try{String v=req(Map.of("fecha",s),"fecha").replace('T',' ');if(v.length()==16)v += ":00";return Timestamp.valueOf(v);}catch(Exception e){throw new IllegalArgumentException("Indica una fecha y hora válida.");}}
    private static Timestamp timestampNullable(String s){return s==null||s.isBlank()?null:timestamp(s);}
    private static java.sql.Time time(String s){return s==null||s.isBlank()?null:java.sql.Time.valueOf(s.length()==5?s+":00":s);}
    private static String oneOf(String v,String... allowed){for(String a:allowed)if(a.equals(v))return v;throw new IllegalArgumentException("Selecciona una opción válida.");}
    private static String oneOfNullable(String v,String... allowed){return v==null||v.isBlank()?null:oneOf(v,allowed);}
}
