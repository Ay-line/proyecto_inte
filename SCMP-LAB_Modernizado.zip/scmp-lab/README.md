# SCMP-LAB

Sistema de control de equipos, mantenimientos e incidencias de laboratorios de cómputo.
Java 17 · Spring Boot 3.3.5 · Thymeleaf · JdbcTemplate · MySQL 8 (o H2 en memoria para probar).

> `README_FASE1.md` y `README_FASE2.md` son notas históricas de entregas anteriores. Este archivo describe el estado actual.

## Ejecutar

Desde la carpeta que contiene `pom.xml`:

```powershell
mvn clean test
mvn spring-boot:run
```

Abrir `http://localhost:8080/login`. Con H2 los datos viven en memoria y se reinician al detener la aplicación.

### Con MySQL 8

1. Ejecuta **una sola vez** `src/main/resources/db/scmp_lab_completo.sql` en MySQL Workbench. Crea la base `scmp_lab_app`; no toca `scmp_lab`.
2. Configura el usuario y la clave de MySQL con variables de entorno (no se guardan en el código):

```powershell
$env:SCMP_DB_USER="root"
$env:SCMP_DB_PASSWORD="TU_CLAVE_MYSQL"
mvn spring-boot:run "-Dspring-boot.run.profiles=mysql"
```

## Usuarios de demostración (solo entorno local)

| Rol | Correo | Contraseña |
|---|---|---|
| Administrador del sistema | `admin@utp.edu.pe` | `Admin#2026` |
| Jefe de infraestructura TI | `jefe@utp.edu.pe` | `Jefe#2026` |
| Administrador de laboratorio | `labadmin@utp.edu.pe` | `Lab#2026` |
| Usuario de laboratorio | `docente@utp.edu.pe` | `Doc#2026` |

Cámbialas antes de usar datos reales. El técnico es una entidad operativa (`TECNICO`), no un quinto rol.

## Permisos por rol

Se definen en un único lugar: `security/PoliticaAcceso.java`. Cada controlador los comprueba en el servidor; el menú solo refleja lo permitido. Un módulo o rol que no figure en la tabla se niega.

| Sección | Administrador del sistema | Jefe de infraestructura | Administrador de laboratorio | Usuario de laboratorio |
|---|---|---|---|---|
| Inventario (equipos, laboratorios, tipos, componentes, instalaciones, vistas) | Ver y registrar | Ver y registrar | Ver y registrar | — |
| Mantenimiento (mantenimientos, checklist) | Ver y registrar | Ver y registrar | Solo ver | — |
| Planes, programación, técnicos, repuestos | Ver y registrar | Ver y registrar | — | — |
| Reportes de falla | Ver, registrar, clasificar | Ver, registrar, clasificar | Ver todos y registrar | Ver los propios y registrar |
| Órdenes de trabajo, repuestos por orden, evidencias, alertas | Ver, registrar, gestionar | Ver, registrar, gestionar | — | — |
| Auditoría | Ver | Ver | — | — |
| Usuarios, roles, configuración general, respaldos | Ver (y registrar donde aplica) | — | — | — |

Cambio respecto a la entrega anterior: el Jefe ya no ve usuarios, roles, configuración general ni respaldos (el informe asigna esas funciones al Administrador del sistema). Si prefieres el comportamiento anterior, se cambia en `PoliticaAcceso`.

## Seguridad

- Contraseñas con BCrypt; bloqueo de 15 min tras 5 intentos fallidos; sesión con expiración por inactividad (20 min).
- Protección CSRF en todos los formularios y peticiones que modifican datos.
- Nuevo identificador de sesión al iniciar sesión; el usuario se vuelve a leer de la base en cada petición (una cuenta desactivada o un cambio de rol se aplican de inmediato).
- Cabeceras de seguridad (CSP, `X-Frame-Options`, `nosniff`), páginas sin caché y cookies `HttpOnly` y `SameSite=Lax`.
- Consola H2 desactivada por defecto. Si publicas con HTTPS, añade `server.servlet.session.cookie.secure=true`.
- Todo el SQL usa parámetros; los nombres de tablas y columnas salen de listas fijas en el código.

## Estructura

- `modulo/CatalogoModulos.java`: define cada módulo una vez (menú, columnas del listado y campos del formulario).
- `controller/`: `InicioController`, `CatalogoController` (equipos, laboratorios, tipos), `OperacionesController` (resto de módulos, reportes y órdenes), `LoginController`.
- `service/` y `dao/`: lógica y SQL. `security/` y `config/`: acceso, CSRF, cabeceras, sesión.
- `templates/`: `fragmentos/layout.html` (menú y estructura común), una plantilla genérica para los listados y pantallas de detalle de equipo, reporte y orden.

## Limitaciones conocidas

- No hay edición ni eliminación de registros, ni gestión de usuarios/roles/contraseñas desde la interfaz.
- Un administrador de laboratorio ve el inventario y los reportes de todos los laboratorios, no solo de los que tiene a cargo.
- Las evidencias guardan una referencia de texto, no suben archivos. Las alertas se registran, pero no se envían por correo. Los respaldos registran la programación, no ejecutan la copia.
- Los listados se cargan completos (con filtro rápido en pantalla); no hay paginación en el servidor.
- Las sesiones activas viven en memoria: se pierden al reiniciar la aplicación.
