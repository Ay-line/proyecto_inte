package pe.utp.scmplab.fakes;

import pe.utp.scmplab.dao.UsuarioDAO;
import pe.utp.scmplab.model.Usuario;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** DAO falso en memoria: las pruebas no necesitan MySQL ni H2. */
public class UsuarioDAOFalso implements UsuarioDAO {

    private final Map<String, Usuario> porCorreo = new HashMap<>();

    public void guardar(Usuario usuario) {
        porCorreo.put(usuario.getCorreo().toLowerCase(), usuario);
    }

    @Override
    public Optional<Usuario> buscarPorCorreo(String correo) {
        return Optional.ofNullable(porCorreo.get(correo.toLowerCase()));
    }

    @Override
    public Optional<Usuario> buscarPorId(int idUsuario) {
        return porCorreo.values().stream().filter(u -> u.getIdUsuario() == idUsuario).findFirst();
    }

    @Override
    public void actualizarIntentos(int idUsuario, int intentosFallidos, LocalDateTime bloqueadoHasta) {
        for (Usuario u : porCorreo.values()) {
            if (u.getIdUsuario() == idUsuario) {
                u.setIntentosFallidos(intentosFallidos);
                u.setBloqueadoHasta(bloqueadoHasta);
            }
        }
    }
}
