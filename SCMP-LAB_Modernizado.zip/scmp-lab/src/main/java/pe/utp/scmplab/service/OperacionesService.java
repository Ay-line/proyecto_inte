package pe.utp.scmplab.service;

import org.springframework.stereotype.Service;
import pe.utp.scmplab.dao.AuditoriaDAO;
import pe.utp.scmplab.dao.OperacionesDAO;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.modulo.CatalogoModulos;
import pe.utp.scmplab.modulo.Columna;
import pe.utp.scmplab.security.Accion;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.security.RolSistema;
import pe.utp.scmplab.web.Formato;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class OperacionesService {

    public static final List<String> ESTADOS_ORDEN = List.of("Creada", "Asignada", "En reparación", "Resuelta", "Observada", "Cerrada");
    public static final List<String> PRIORIDADES = List.of("Baja", "Media", "Alta", "Crítica");

    private final OperacionesDAO dao;
    private final AuditoriaDAO auditoria;
    private final PoliticaAcceso acceso;

    public OperacionesService(OperacionesDAO dao, AuditoriaDAO auditoria, PoliticaAcceso acceso) {
        this.dao = dao;
        this.auditoria = auditoria;
        this.acceso = acceso;
    }

    /** Listado del módulo con las celdas ya formateadas. Un usuario de laboratorio solo ve sus propios reportes. */
    public List<Map<String, Object>> listar(String modulo, Usuario usuario) {
        Integer soloUsuario = "reportes".equals(modulo) && esUsuarioLaboratorio(usuario) ? usuario.getIdUsuario() : null;
        List<Columna> columnas = CatalogoModulos.obtener(modulo).map(m -> m.getColumnas()).orElse(List.of());
        return Formato.filas(dao.listar(modulo, soloUsuario), columnas);
    }

    public List<Map<String, Object>> opciones(String clave) { return dao.opciones(clave); }

    public void crear(String modulo, Map<String, String> campos, Usuario usuario) {
        Map<String, String> datos = new HashMap<>(campos);
        // Quien reporta no define prioridad ni tipo de falla: lo hace quien gestiona (se aplica aquí, no solo en el formulario).
        if ("reportes".equals(modulo) && !acceso.permite(usuario, "reportes", Accion.GESTIONAR)) {
            datos.remove("prioridad");
            datos.remove("id_tipo_falla");
        }
        dao.crear(modulo, datos, usuario == null ? null : usuario.getIdUsuario());
        registrar("CREAR_" + modulo.toUpperCase().replace('-', '_'), tablaAuditada(modulo), null, usuario);
    }

    // ---------------- Órdenes de trabajo ----------------

    public void actualizarEstadoOrden(int id, String estado, Usuario usuario) {
        dao.actualizarEstadoOrden(id, estado);
        registrar("CAMBIAR_ESTADO_ORDEN", "ORDEN_TRABAJO", Integer.toString(id), usuario);
    }

    public void asignarTecnicoOrden(int id, int idTecnico, Usuario usuario) {
        dao.asignarTecnicoOrden(id, idTecnico);
        registrar("ASIGNAR_TECNICO_ORDEN", "ORDEN_TRABAJO", Integer.toString(id), usuario);
    }

    /** Agrega un repuesto a la orden indicada en la ruta (no se confía en un id enviado por el formulario). */
    public void agregarRepuestoAOrden(int idOrden, String idRepuesto, String cantidad, Usuario usuario) {
        Map<String, String> campos = new HashMap<>();
        campos.put("id_orden", Integer.toString(idOrden));
        campos.put("id_repuesto", idRepuesto);
        campos.put("cantidad", cantidad);
        dao.crear("detalle-orden", campos, usuario.getIdUsuario());
        registrar("CREAR_DETALLE_ORDEN", "DETALLE_ORDEN", Integer.toString(idOrden), usuario);
    }

    public void agregarEvidenciaAOrden(int idOrden, String ruta, Usuario usuario) {
        Map<String, String> campos = new HashMap<>();
        campos.put("id_orden", Integer.toString(idOrden));
        campos.put("ruta_archivo", ruta);
        dao.crear("evidencias", campos, usuario.getIdUsuario());
        registrar("CREAR_EVIDENCIAS", "EVIDENCIA_ORDEN", Integer.toString(idOrden), usuario);
    }

    /** Datos de la pantalla de detalle de una orden; vacío si no existe. */
    public Optional<Map<String, Object>> detalleOrden(int id) {
        Optional<Map<String, Object>> orden = dao.buscarOrden(id);
        if (orden.isEmpty()) return Optional.empty();
        Map<String, Object> crudo = orden.get();
        Map<String, Object> modelo = new LinkedHashMap<>();
        modelo.put("orden", Formato.fila(crudo));
        modelo.put("ordenTono", Formato.tono((String) crudo.get("estado")));
        modelo.put("prioridadTono", Formato.tono((String) crudo.get("prioridad")));
        modelo.put("cerrada", "Cerrada".equals(crudo.get("estado")));
        modelo.put("conReporte", crudo.get("id_reporte") != null);
        modelo.put("repuestosOrden", Formato.filas(dao.repuestosDeOrden(id), List.of(new Columna("repuesto", ""), new Columna("cantidad", ""), new Columna("costo", ""), new Columna("subtotal", ""))));
        modelo.put("evidencias", Formato.filas(dao.evidenciasDeOrden(id), List.of(new Columna("ruta_archivo", ""), new Columna("fecha_carga", ""))));
        return Optional.of(modelo);
    }

    // ---------------- Reportes de falla ----------------

    /** Detalle de un reporte; un usuario de laboratorio solo puede abrir los suyos. */
    public Optional<Map<String, Object>> detalleReporte(int id, Usuario usuario) {
        Optional<Map<String, Object>> reporte = dao.buscarReporte(id);
        if (reporte.isEmpty()) return Optional.empty();
        Map<String, Object> crudo = reporte.get();
        if (esUsuarioLaboratorio(usuario) && !esElMismo(usuario, crudo.get("id_usuario"))) return Optional.empty();
        Map<String, Object> modelo = new LinkedHashMap<>();
        Map<String, Object> vista = Formato.fila(crudo);
        modelo.put("reporte", vista);
        modelo.put("estadoTono", Formato.tono((String) crudo.get("estado")));
        modelo.put("prioridadTono", Formato.tono((String) crudo.get("prioridad")));
        modelo.put("prioridadActual", crudo.get("prioridad"));
        modelo.put("tipoFallaActual", crudo.get("id_tipo_falla"));
        modelo.put("cerrado", "Cerrado".equals(crudo.get("estado")));
        modelo.put("ordenes", Formato.filas(dao.ordenesDeReporte(id), List.of(new Columna("id", ""), new Columna("fecha", ""), new Columna("prioridad", "").etiqueta(), new Columna("estado", "").etiqueta(), new Columna("tecnico", ""))));
        return Optional.of(modelo);
    }

    public void clasificarReporte(int id, String prioridad, Integer idTipoFalla, Usuario usuario) {
        dao.clasificarReporte(id, prioridad, idTipoFalla);
        registrar("CLASIFICAR_REPORTE", "REPORTE_FALLA", Integer.toString(id), usuario);
    }

    /** Crea una orden de trabajo para el equipo del reporte (la prioridad por defecto es la del reporte). */
    public void crearOrdenDesdeReporte(int idReporte, String prioridad, Integer idTecnico, Usuario usuario) {
        Map<String, Object> reporte = dao.buscarReporte(idReporte).orElseThrow(() -> new IllegalArgumentException("No se encontró el reporte."));
        Map<String, String> campos = new HashMap<>();
        campos.put("id_equipo", String.valueOf(reporte.get("id_equipo")));
        campos.put("id_reporte", Integer.toString(idReporte));
        campos.put("prioridad", prioridad);
        if (idTecnico != null) campos.put("id_tecnico", idTecnico.toString());
        dao.crear("ordenes", campos, usuario.getIdUsuario());
        registrar("CREAR_ORDENES", "ORDEN_TRABAJO", null, usuario);
    }

    // ---------------- Utilidades ----------------

    private static boolean esElMismo(Usuario usuario, Object idPropietario) {
        return idPropietario instanceof Number n && usuario.getIdUsuario() != null && n.intValue() == usuario.getIdUsuario();
    }

    private boolean esUsuarioLaboratorio(Usuario usuario) {
        return usuario != null && RolSistema.USUARIO_LABORATORIO == acceso.rolDe(usuario);
    }

    private void registrar(String accion, String tabla, String idRegistro, Usuario usuario) {
        if (usuario != null) auditoria.registrar(LocalDateTime.now(), accion, tabla, idRegistro, usuario.getIdUsuario());
    }

    private String tablaAuditada(String modulo) {
        return switch (modulo) {
            case "componentes" -> "COMPONENTE"; case "instalaciones" -> "INSTALACION_COMPONENTE";
            case "tecnicos" -> "TECNICO"; case "repuestos" -> "REPUESTO"; case "tipos-falla" -> "TIPO_FALLA";
            case "checklist-tareas" -> "TAREA_CHECKLIST"; case "mantenimientos" -> "MANTENIMIENTO";
            case "checklist-detalle" -> "DETALLE_CHECKLIST"; case "reportes" -> "REPORTE_FALLA";
            case "ordenes" -> "ORDEN_TRABAJO"; case "detalle-orden" -> "DETALLE_ORDEN";
            case "planes" -> "PLAN_MANTENIMIENTO"; case "programaciones" -> "PROGRAMACION_MANTENIMIENTO";
            case "evidencias" -> "EVIDENCIA_ORDEN"; case "alertas" -> "ALERTA";
            case "config-alertas" -> "CONFIG_ALERTA"; case "configuracion" -> "CONFIG_GENERAL"; case "respaldos" -> "RESPALDO";
            default -> "SISTEMA";
        };
    }
}
