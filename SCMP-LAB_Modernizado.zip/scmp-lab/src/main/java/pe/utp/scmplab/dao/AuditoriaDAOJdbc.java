package pe.utp.scmplab.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Repository
public class AuditoriaDAOJdbc implements AuditoriaDAO {

    private final JdbcTemplate jdbc;

    public AuditoriaDAOJdbc(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void registrar(LocalDateTime fecha, String accion, String tablaAfectada, String idRegistro, Integer idUsuario) {
        jdbc.update("INSERT INTO AUDITORIA (fecha, accion, tabla_afectada, id_registro, id_usuario) VALUES (?, ?, ?, ?, ?)",
                Timestamp.valueOf(fecha), accion, tablaAfectada, idRegistro, idUsuario);
    }
}
