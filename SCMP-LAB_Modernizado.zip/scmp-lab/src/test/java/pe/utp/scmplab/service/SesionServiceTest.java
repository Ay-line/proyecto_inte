package pe.utp.scmplab.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pe.utp.scmplab.fakes.AuditoriaDAOFalso;
import pe.utp.scmplab.model.Sesion;
import pe.utp.scmplab.model.Usuario;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/** Ficha de pruebas RF02 — Cerrar sesión o expirarla (CP01 a CP04; CP05 es prueba manual de pantalla). */
class SesionServiceTest {

    private static final LocalDateTime NUEVE = LocalDateTime.of(2026, 10, 26, 9, 0);

    private SesionRepositorioMemoria repositorio;
    private AuditoriaDAOFalso auditoriaDAO;
    private SesionService servicio;
    private Usuario jefe;

    @BeforeEach
    void preparar() {
        repositorio = new SesionRepositorioMemoria();
        auditoriaDAO = new AuditoriaDAOFalso();
        servicio = new SesionService(repositorio, auditoriaDAO);
        jefe = new Usuario();
        jefe.setIdUsuario(1);
    }

    @Test
    @DisplayName("CP01 - Flujo exitoso — cierre manual")
    void cp01CierreManual() {
        // ARRANGE
        Sesion sesion = servicio.iniciar(jefe, NUEVE);
        // ACT
        ResultadoSesion r = servicio.cerrar(sesion.getToken(), false, false, NUEVE.plusMinutes(5));
        // ASSERT
        assertEquals(ResultadoSesion.Estado.CERRADA, r.getEstado());
        assertEquals("Sesión cerrada", r.getMensaje());
        assertTrue(repositorio.buscar(sesion.getToken()).isEmpty());
        assertTrue(auditoriaDAO.acciones.contains("CIERRE_SESION"));
    }

    @Test
    @DisplayName("CP02 - Cierre con operación pendiente (E1)")
    void cp02CierreConPendientes() {
        // ARRANGE
        Sesion sesion = servicio.iniciar(jefe, NUEVE);
        // ACT: primero sin confirmar, luego confirmando
        ResultadoSesion sinConfirmar = servicio.cerrar(sesion.getToken(), true, false, NUEVE);
        ResultadoSesion confirmado = servicio.cerrar(sesion.getToken(), true, true, NUEVE);
        // ASSERT
        assertEquals(ResultadoSesion.Estado.REQUIERE_CONFIRMACION, sinConfirmar.getEstado());
        assertEquals("Hay cambios sin guardar. ¿Desea cerrar sesión?", sinConfirmar.getMensaje());
        assertEquals(ResultadoSesion.Estado.CERRADA, confirmado.getEstado());
        assertTrue(repositorio.buscar(sesion.getToken()).isEmpty());
    }

    @Test
    @DisplayName("CP03 - Expira por inactividad (E2)")
    void cp03ExpiraPorInactividad() {
        // ARRANGE: última actividad 09:00; hora actual 09:21 (dato de prueba)
        Sesion sesion = servicio.iniciar(jefe, NUEVE);
        // ACT
        ResultadoSesion r = servicio.validar(sesion.getToken(), LocalDateTime.of(2026, 10, 26, 9, 21));
        // ASSERT
        assertEquals(ResultadoSesion.Estado.EXPIRADA, r.getEstado());
        assertEquals("Su sesión expiró por inactividad", r.getMensaje());
        assertTrue(repositorio.buscar(sesion.getToken()).isEmpty());
    }

    @Test
    @DisplayName("CP03b - Justo en el límite de 20 minutos la sesión sigue válida (E2)")
    void cp03bLimiteDeVeinteMinutos() {
        // ARRANGE
        Sesion sesion = servicio.iniciar(jefe, NUEVE);
        // ACT
        ResultadoSesion r = servicio.validar(sesion.getToken(), LocalDateTime.of(2026, 10, 26, 9, 20));
        // ASSERT
        assertEquals(ResultadoSesion.Estado.VALIDA, r.getEstado());
    }

    @Test
    @DisplayName("CP04 - Sesión inexistente (E3)")
    void cp04SesionInexistente() {
        // ARRANGE: el token ya fue invalidado (no existe en el repositorio)
        // ACT
        ResultadoSesion r = servicio.validar("token-invalidado", NUEVE);
        // ASSERT
        assertEquals(ResultadoSesion.Estado.INVALIDA, r.getEstado());
        assertEquals("Inicie sesión para continuar", r.getMensaje());
    }
}
