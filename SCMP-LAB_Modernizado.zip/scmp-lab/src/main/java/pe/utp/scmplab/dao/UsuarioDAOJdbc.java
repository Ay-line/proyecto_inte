package pe.utp.scmplab.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import pe.utp.scmplab.model.Usuario;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/** Implementación JDBC de {@link UsuarioDAO}. Todo el SQL de USUARIO vive aquí. */
@Repository
public class UsuarioDAOJdbc implements UsuarioDAO {

    private static final String SELECT_BASE =
            "SELECT u.id_usuario, u.nombre, u.correo, u.clave_hash, u.estado, u.intentos_fallidos, "
          + "u.bloqueado_hasta, u.id_rol, r.nombre AS nombre_rol "
          + "FROM USUARIO u JOIN ROL r ON r.id_rol = u.id_rol ";

    private final JdbcTemplate jdbc;

    public UsuarioDAOJdbc(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private static final RowMapper<Usuario> MAPPER = (rs, i) -> {
        Usuario u = new Usuario();
        u.setIdUsuario(rs.getInt("id_usuario"));
        u.setNombre(rs.getString("nombre"));
        u.setCorreo(rs.getString("correo"));
        u.setClaveHash(rs.getString("clave_hash"));
        u.setEstado(rs.getString("estado"));
        u.setIntentosFallidos(rs.getInt("intentos_fallidos"));
        Timestamp bloqueo = rs.getTimestamp("bloqueado_hasta");
        u.setBloqueadoHasta(bloqueo == null ? null : bloqueo.toLocalDateTime());
        u.setIdRol(rs.getInt("id_rol"));
        u.setNombreRol(rs.getString("nombre_rol"));
        return u;
    };

    @Override
    public Optional<Usuario> buscarPorCorreo(String correo) {
        List<Usuario> lista = jdbc.query(SELECT_BASE + "WHERE LOWER(u.correo) = LOWER(?)", MAPPER, correo);
        return lista.stream().findFirst();
    }

    @Override
    public Optional<Usuario> buscarPorId(int idUsuario) {
        return jdbc.query(SELECT_BASE + "WHERE u.id_usuario = ?", MAPPER, idUsuario).stream().findFirst();
    }

    @Override
    public void actualizarIntentos(int idUsuario, int intentosFallidos, LocalDateTime bloqueadoHasta) {
        jdbc.update("UPDATE USUARIO SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id_usuario = ?",
                intentosFallidos, bloqueadoHasta == null ? null : Timestamp.valueOf(bloqueadoHasta), idUsuario);
    }
}
