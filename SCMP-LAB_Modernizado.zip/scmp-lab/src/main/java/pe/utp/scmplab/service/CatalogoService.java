package pe.utp.scmplab.service;

import org.springframework.stereotype.Service;
import pe.utp.scmplab.dao.CatalogoDAO;
import pe.utp.scmplab.modulo.Columna;
import pe.utp.scmplab.security.RolSistema;
import pe.utp.scmplab.web.Formato;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Casos de uso de consulta y registro del inventario (equipos, laboratorios y tipos de equipo). */
@Service
public class CatalogoService {

    public static final List<String> ESTADOS_EQUIPO = List.of("Operativo", "En mantenimiento", "Inoperativo", "Baja");

    private final CatalogoDAO dao;

    public CatalogoService(CatalogoDAO dao) {
        this.dao = dao;
    }

    public long contar(String tabla) { return dao.contar(tabla); }
    public List<Map<String, Object>> listarLaboratorios() { return dao.listarLaboratorios(); }
    public List<Map<String, Object>> listarTiposEquipo() { return dao.listarTiposEquipo(); }

    /** Usuarios que pueden ser responsables de un laboratorio (rol Administrador de laboratorio, cuenta activa). */
    public List<Map<String, Object>> listarResponsablesPosibles() {
        return dao.listarResponsablesPosibles(RolSistema.ADMIN_LABORATORIO.getNombre());
    }

    /** Equipos con el color de su estado ya calculado para la etiqueta. */
    public List<Map<String, Object>> listarEquipos() {
        List<Map<String, Object>> filas = dao.listarEquipos();
        filas.forEach(f -> f.put("estado" + Formato.SUFIJO_TONO, Formato.tono((String) f.get("estado"))));
        return filas;
    }

    public void crearLaboratorio(String codigo, String nombre, String sede, String piso, Integer responsable) {
        exigirTexto(codigo, "El código del laboratorio");
        exigirTexto(nombre, "El nombre del laboratorio");
        exigirTexto(sede, "La sede");
        if (responsable != null && listarResponsablesPosibles().stream().noneMatch(r -> responsable.equals(((Number) r.get("id")).intValue()))) {
            throw new IllegalArgumentException("El responsable debe ser un administrador de laboratorio activo.");
        }
        dao.crearLaboratorio(codigo.trim(), nombre.trim(), sede.trim(), piso == null ? null : piso.trim(), responsable);
    }

    public void crearTipoEquipo(String nombre, String descripcion) {
        exigirTexto(nombre, "El nombre del tipo de equipo");
        dao.crearTipoEquipo(nombre.trim(), descripcion == null ? null : descripcion.trim());
    }

    public void crearEquipo(String codigo, String serie, String marca, String modelo, String fecha,
                            String estado, Integer idTipoEquipo, Integer idLaboratorio) {
        exigirTexto(codigo, "El código interno");
        exigirTexto(serie, "El número de serie");
        exigirTexto(estado, "El estado");
        if (!ESTADOS_EQUIPO.contains(estado)) {
            throw new IllegalArgumentException("Selecciona un estado válido para el equipo.");
        }
        if (idTipoEquipo == null || idTipoEquipo < 1 || idLaboratorio == null || idLaboratorio < 1) {
            throw new IllegalArgumentException("Selecciona el tipo de equipo y el laboratorio.");
        }
        if (fecha != null && !fecha.isBlank()) {
            try {
                LocalDate.parse(fecha.trim());
            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("La fecha de adquisición no es válida.");
            }
        }
        dao.crearEquipo(codigo.trim(), serie.trim(), marca, modelo, fecha == null ? null : fecha.trim(), estado, idTipoEquipo, idLaboratorio);
    }

    /** Ficha del equipo con sus componentes, mantenimientos, reportes y órdenes; vacío si no existe. */
    public Optional<Map<String, Object>> detalleEquipo(int id) {
        Optional<Map<String, Object>> equipo = dao.buscarEquipo(id);
        if (equipo.isEmpty()) return Optional.empty();
        Map<String, Object> crudo = equipo.get();
        Map<String, Object> modelo = new LinkedHashMap<>();
        modelo.put("equipo", Formato.fila(crudo));
        modelo.put("estadoTono", Formato.tono((String) crudo.get("estado")));
        modelo.put("componentes", Formato.filas(dao.componentesDeEquipo(id), List.of(
                new Columna("tipo", ""), new Columna("marca", ""), new Columna("capacidad", ""), new Columna("instalado", ""), new Columna("retirado", ""))));
        modelo.put("mantenimientos", Formato.filas(dao.mantenimientosDeEquipo(id), List.of(
                new Columna("id", ""), new Columna("tipo", ""), new Columna("fecha", ""), new Columna("tecnico", ""), new Columna("resultado", "").etiqueta(), new Columna("minutos", ""))));
        modelo.put("reportes", Formato.filas(dao.reportesDeEquipo(id), List.of(
                new Columna("id", ""), new Columna("fecha", ""), new Columna("tipo_falla", ""), new Columna("prioridad", "").etiqueta(), new Columna("estado", "").etiqueta())));
        modelo.put("ordenes", Formato.filas(dao.ordenesDeEquipo(id), List.of(
                new Columna("id", ""), new Columna("fecha", ""), new Columna("prioridad", "").etiqueta(), new Columna("estado", "").etiqueta(), new Columna("tecnico", ""), new Columna("costo", ""))));
        return Optional.of(modelo);
    }

    private void exigirTexto(String valor, String campo) {
        if (valor == null || valor.isBlank()) throw new IllegalArgumentException(campo + " es obligatorio.");
    }
}
