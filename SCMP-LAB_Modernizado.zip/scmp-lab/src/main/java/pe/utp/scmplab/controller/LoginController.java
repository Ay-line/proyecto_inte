package pe.utp.scmplab.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import pe.utp.scmplab.model.Sesion;
import pe.utp.scmplab.service.AutenticacionService;
import pe.utp.scmplab.service.ResultadoLogin;
import pe.utp.scmplab.service.SesionService;

import java.time.LocalDateTime;

/** Pantalla de acceso y cierre de sesión. Delega toda la lógica en los servicios. */
@Controller
public class LoginController {

    private final AutenticacionService autenticacionService;
    private final SesionService sesionService;

    public LoginController(AutenticacionService autenticacionService, SesionService sesionService) {
        this.autenticacionService = autenticacionService;
        this.sesionService = sesionService;
    }

    @GetMapping("/login")
    public String mostrarLogin(@RequestParam(required = false) String expirada,
                               @RequestParam(required = false) String cerrada, Model model) {
        if (expirada != null) model.addAttribute("aviso", "Tu sesión expiró por inactividad. Ingresa de nuevo.");
        if (cerrada != null) model.addAttribute("aviso", "Cerraste sesión correctamente.");
        return "login";
    }

    @PostMapping("/login")
    public String iniciarSesion(@RequestParam String correo, @RequestParam String clave,
                                HttpServletRequest request, Model model) {
        LocalDateTime ahora = LocalDateTime.now();
        ResultadoLogin resultado = autenticacionService.login(correo, clave, ahora);
        if (!resultado.esExitoso()) {
            model.addAttribute("error", resultado.getMensaje());
            model.addAttribute("correo", correo);
            return "login";
        }
        // Nuevo identificador de sesión tras autenticarse (evita la fijación de sesión).
        request.getSession(true);
        request.changeSessionId();
        HttpSession httpSession = request.getSession();
        Sesion sesion = sesionService.iniciar(resultado.getUsuario(), ahora);
        httpSession.setAttribute("token", sesion.getToken());
        httpSession.setAttribute("uid", resultado.getUsuario().getIdUsuario());
        return "redirect:/inicio";
    }

    @PostMapping("/logout")
    public String cerrarSesion(HttpServletRequest request) {
        HttpSession httpSession = request.getSession(false);
        if (httpSession != null) {
            sesionService.cerrar((String) httpSession.getAttribute("token"), false, true, LocalDateTime.now());
            httpSession.invalidate();
        }
        return "redirect:/login?cerrada=1";
    }
}
