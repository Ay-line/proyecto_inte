package pe.utp.scmplab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Punto de entrada de SCMP-LAB. */
@SpringBootApplication
public class ScmpLabApplication {
    public static void main(String[] args) {
        SpringApplication.run(ScmpLabApplication.class, args);
    }
}
