package pe.utp.scmplab.web;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ResponseStatus;
import pe.utp.scmplab.config.AuthInterceptor;
import pe.utp.scmplab.config.CsrfInterceptor;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.security.PoliticaAcceso;

/** Datos comunes a todas las vistas: usuario vigente, token de formulario y menú según el rol. */
@ControllerAdvice
public class VistaAdvice {

    private static final Logger LOG = LoggerFactory.getLogger(VistaAdvice.class);

    private final PoliticaAcceso acceso;

    public VistaAdvice(PoliticaAcceso acceso) { this.acceso = acceso; }

    @ModelAttribute
    public void comunes(HttpServletRequest request, Model model) {
        model.addAttribute("csrf", CsrfInterceptor.tokenDe(request.getSession()));
        Usuario usuario = (Usuario) request.getAttribute(AuthInterceptor.ATRIBUTO_USUARIO);
        if (usuario == null) return;
        String ruta = request.getRequestURI().substring(request.getContextPath().length());
        model.addAttribute("usuarioActual", usuario);
        model.addAttribute("rutaActual", ruta);
        model.addAttribute("nav", Navegacion.construir(acceso, acceso.rolDe(usuario), ruta));
    }

    /** Un fallo de base de datos no mostrado al usuario como página técnica, y queda en el registro del servidor. */
    @ExceptionHandler(DataAccessException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String errorDeDatos(DataAccessException ex, Model model) {
        LOG.error("Error de acceso a datos", ex);
        model.addAttribute("status", 500);
        model.addAttribute("titulo", "No se pudo completar la operación");
        model.addAttribute("mensaje", "Ocurrió un problema al consultar o guardar los datos. Inténtalo de nuevo; si continúa, avisa al administrador.");
        return "error";
    }
}
