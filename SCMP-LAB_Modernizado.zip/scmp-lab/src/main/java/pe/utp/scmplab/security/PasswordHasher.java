package pe.utp.scmplab.security;

/** Abstracción del cifrado de contraseñas (SOLID - D: los servicios dependen de esta interfaz, no de BCrypt). */
public interface PasswordHasher {
    String cifrar(String claveClara);

    boolean coincide(String claveClara, String hash);
}
