package pe.utp.scmplab.fakes;

import pe.utp.scmplab.security.PasswordHasher;

/** Cifrado falso y rápido para pruebas: "hash:" + clave. */
public class PasswordHasherFalso implements PasswordHasher {
    @Override
    public String cifrar(String claveClara) { return "hash:" + claveClara; }

    @Override
    public boolean coincide(String claveClara, String hash) { return cifrar(claveClara).equals(hash); }
}
