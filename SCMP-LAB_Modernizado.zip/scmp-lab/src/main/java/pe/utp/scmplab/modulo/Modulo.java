package pe.utp.scmplab.modulo;

import java.util.ArrayList;
import java.util.List;

/** Definición de un módulo de la aplicación: dónde está en la navegación, qué lista y qué registra. */
public final class Modulo {
    private final String clave;
    private final Grupo grupo;
    private final String titulo;
    private final String descripcion;
    private String ruta;
    private boolean generico = true;
    private String etiquetaAlta = "Registrar";
    private String rutaDetalle;
    private List<Columna> columnas = new ArrayList<>();
    private List<Campo> campos = new ArrayList<>();

    public Modulo(String clave, Grupo grupo, String titulo, String descripcion) {
        this.clave = clave; this.grupo = grupo; this.titulo = titulo; this.descripcion = descripcion;
        this.ruta = "/gestion/" + clave;
    }

    public Modulo ruta(String r) { this.ruta = r; this.generico = false; return this; }
    public Modulo alta(String etiqueta) { this.etiquetaAlta = etiqueta; return this; }
    public Modulo detalle(String base) { this.rutaDetalle = base; return this; }
    public Modulo columnas(Columna... c) { this.columnas = List.of(c); return this; }
    public Modulo campos(Campo... c) { this.campos = List.of(c); return this; }

    public String getClave() { return clave; }
    public Grupo getGrupo() { return grupo; }
    public String getTitulo() { return titulo; }
    public String getDescripcion() { return descripcion; }
    public String getRuta() { return ruta; }
    /** Verdadero si lo atiende la pantalla genérica /gestion/{clave}; falso si tiene página propia. */
    public boolean isGenerico() { return generico; }
    public String getEtiquetaAlta() { return etiquetaAlta; }
    public String getRutaDetalle() { return rutaDetalle; }
    public List<Columna> getColumnas() { return columnas; }
    public List<Campo> getCampos() { return campos; }
}
