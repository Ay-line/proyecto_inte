package pe.utp.scmplab.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pe.utp.scmplab.fakes.AuditoriaDAOFalso;
import pe.utp.scmplab.fakes.PasswordHasherFalso;
import pe.utp.scmplab.fakes.UsuarioDAOFalso;
import pe.utp.scmplab.model.Usuario;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/** Ficha de pruebas RF01 — Iniciar sesión en el sistema (CP01 a CP05). */
class AutenticacionServiceTest {

    private static final LocalDateTime AHORA = LocalDateTime.of(2026, 10, 26, 9, 0);

    private UsuarioDAOFalso usuarioDAO;
    private AuditoriaDAOFalso auditoriaDAO;
    private AutenticacionService servicio;

    @BeforeEach
    void preparar() {
        usuarioDAO = new UsuarioDAOFalso();
        auditoriaDAO = new AuditoriaDAOFalso();
        servicio = new AutenticacionService(usuarioDAO, auditoriaDAO, new PasswordHasherFalso());
    }

    private Usuario usuario(String correo, String clave, String estado, int intentos) {
        Usuario u = new Usuario();
        u.setIdUsuario(1);
        u.setNombre("Jefe de Infraestructura TI");
        u.setCorreo(correo);
        u.setClaveHash(new PasswordHasherFalso().cifrar(clave));
        u.setEstado(estado);
        u.setIntentosFallidos(intentos);
        u.setNombreRol("Jefe de infraestructura TI");
        usuarioDAO.guardar(u);
        return u;
    }

    @Test
    @DisplayName("CP01 - Flujo exitoso — ingreso válido")
    void cp01FlujoExitoso() {
        // ARRANGE
        usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 0);
        // ACT
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#2026", AHORA);
        // ASSERT
        assertEquals(ResultadoLogin.Estado.EXITO, r.getEstado());
        assertEquals("Jefe de infraestructura TI", r.getUsuario().getNombreRol());
        assertTrue(auditoriaDAO.acciones.contains("INICIO_SESION"));
        assertEquals(AHORA, auditoriaDAO.fechas.get(0));
    }

    @Test
    @DisplayName("CP02 - Correo no registrado (E1)")
    void cp02CorreoNoRegistrado() {
        // ARRANGE: no existe ninguno@utp.edu.pe
        // ACT
        ResultadoLogin r = servicio.login("ninguno@utp.edu.pe", "Admin#2026", AHORA);
        // ASSERT
        assertEquals(ResultadoLogin.Estado.CREDENCIALES_INVALIDAS, r.getEstado());
        assertEquals("Usuario o contraseña incorrectos", r.getMensaje());
        assertNull(r.getUsuario());
        assertTrue(auditoriaDAO.acciones.isEmpty());
    }

    @Test
    @DisplayName("CP03 - Clave incorrecta, 1.er intento (E2)")
    void cp03ClaveIncorrectaPrimerIntento() {
        // ARRANGE
        Usuario u = usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 0);
        // ACT
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#0000", AHORA);
        // ASSERT
        assertEquals(ResultadoLogin.Estado.CREDENCIALES_INVALIDAS, r.getEstado());
        assertEquals("Usuario o contraseña incorrectos. Le quedan 4 intentos", r.getMensaje());
        assertEquals(1, u.getIntentosFallidos());
        assertNull(r.getUsuario());
    }

    @Test
    @DisplayName("CP04 - Bloqueo por 5 intentos fallidos (E3)")
    void cp04BloqueoPorCincoIntentos() {
        // ARRANGE
        Usuario u = usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 4);
        // ACT
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#0000", AHORA);
        // ASSERT
        assertEquals(ResultadoLogin.Estado.CUENTA_BLOQUEADA, r.getEstado());
        assertEquals("Cuenta bloqueada por 15 minutos", r.getMensaje());
        assertEquals(AHORA.plusMinutes(15), u.getBloqueadoHasta());
        assertNull(r.getUsuario());
    }

    @Test
    @DisplayName("CP05 - Usuario inactivo (E4)")
    void cp05UsuarioInactivo() {
        // ARRANGE
        usuario("tecnico@utp.edu.pe", "Tec#2026", "Inactivo", 0);
        // ACT
        ResultadoLogin r = servicio.login("tecnico@utp.edu.pe", "Tec#2026", AHORA);
        // ASSERT
        assertEquals(ResultadoLogin.Estado.CUENTA_INACTIVA, r.getEstado());
        assertEquals("Su cuenta está inactiva. Comuníquese con el administrador", r.getMensaje());
        assertNull(r.getUsuario());
        assertTrue(auditoriaDAO.acciones.isEmpty());
    }

    @Test
    @DisplayName("CP06 - Tras vencer el bloqueo, un error no vuelve a bloquear la cuenta")
    void cp06BloqueoVencidoReiniciaIntentos() {
        // ARRANGE: cuenta bloqueada con 5 intentos; el bloqueo venció hace un minuto
        Usuario u = usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 5);
        u.setBloqueadoHasta(AHORA.minusMinutes(1));
        // ACT
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#0000", AHORA);
        // ASSERT: cuenta como primer intento fallido, no como el sexto
        assertEquals(ResultadoLogin.Estado.CREDENCIALES_INVALIDAS, r.getEstado());
        assertEquals("Usuario o contraseña incorrectos. Le quedan 4 intentos", r.getMensaje());
        assertEquals(1, u.getIntentosFallidos());
        assertNull(u.getBloqueadoHasta());
    }

    @Test
    @DisplayName("CP07 - Tras vencer el bloqueo, la clave correcta permite ingresar")
    void cp07BloqueoVencidoPermiteIngresar() {
        Usuario u = usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 5);
        u.setBloqueadoHasta(AHORA.minusMinutes(1));
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#2026", AHORA);
        assertEquals(ResultadoLogin.Estado.EXITO, r.getEstado());
        assertEquals(0, u.getIntentosFallidos());
    }

    @Test
    @DisplayName("CP08 - Con el bloqueo vigente se rechaza incluso la clave correcta")
    void cp08BloqueoVigente() {
        Usuario u = usuario("jefe@utp.edu.pe", "Admin#2026", "Activo", 5);
        u.setBloqueadoHasta(AHORA.plusMinutes(10));
        ResultadoLogin r = servicio.login("jefe@utp.edu.pe", "Admin#2026", AHORA);
        assertEquals(ResultadoLogin.Estado.CUENTA_BLOQUEADA, r.getEstado());
        assertNull(r.getUsuario());
    }
}
