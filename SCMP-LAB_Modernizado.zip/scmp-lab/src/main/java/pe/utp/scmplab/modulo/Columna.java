package pe.utp.scmplab.modulo;

/** Columna de un listado. Las de estado se muestran como etiqueta de color; las de enlace abren el detalle. */
public final class Columna {
    private final String key;
    private final String label;
    private boolean etiqueta;
    private boolean enlace;

    public Columna(String key, String label) { this.key = key; this.label = label; }

    public Columna etiqueta() { this.etiqueta = true; return this; }
    public Columna enlace() { this.enlace = true; return this; }

    public String getKey() { return key; }
    public String getLabel() { return label; }
    public boolean isEtiqueta() { return etiqueta; }
    public boolean isEnlace() { return enlace; }
}
