# SCMP-LAB — Fase 2: módulos basados en el capítulo 5

Esta entrega amplía la Fase 1 siguiendo el documento `SCMP-LAB_Cap5_Modelo_ER_Logico_Fisico_APF3.pdf`. Mantiene Java 17, Spring Boot 3.3.5, Thymeleaf y JdbcTemplate.

## Alcance implementado

- Panel de inicio por rol y accesos a los módulos implementados.
- Vistas consolidadas Hoja de vida del equipo e Inventario por laboratorio, alineadas con las vistas del informe.
- Inventario de equipos, laboratorios y tipos de equipo.
- Catálogos operativos: componentes, instalaciones de componentes, técnicos, repuestos, tipos de falla y tareas de checklist.
- Mantenimientos y detalle del checklist.
- Reportes de falla; los usuarios de laboratorio consultan sus propios reportes.
- Órdenes de trabajo con cambio de estado, fechas de asignación/cierre y detalle de repuestos con costo histórico.
- Planes y programación de mantenimientos.
- Registro de referencias de evidencia, alertas y configuración de alertas.
- Consulta de auditoría, configuración general, respaldos (metadatos), usuarios y roles.
- Vistas de cálculo `V_DETALLE_ORDEN_SUBTOTAL`, `V_ORDEN_COSTO_TOTAL` y `V_MANTENIMIENTO_DURACION`.
- Registro de acciones de los módulos operativos en `AUDITORIA`.

## Correspondencia con el informe

El modelo documenta 16 entidades principales y 8 tablas de soporte transversal (24 tablas en total). Se mantienen los cuatro roles de acceso descritos por el informe. `TECNICO` se mantiene como entidad independiente de `ROL`. Las columnas `intentos_fallidos` y `bloqueado_hasta` se conservan en `USUARIO` como extensión técnica para las funciones de bloqueo por intentos fallidos.

## Ejecutar con H2 (recomendado para las primeras pruebas)

Desde el directorio que contiene `pom.xml`:

```powershell
mvn clean test
mvn spring-boot:run
```

Abrir `http://localhost:8080/login`. H2 es en memoria; los cambios se reinician al detener la aplicación.

## Usuarios de demostración H2 / MySQL completo

| Rol | Correo | Contraseña local |
|---|---|---|
| Administrador del sistema | `admin@utp.edu.pe` | `Admin#2026` |
| Jefe de infraestructura TI | `jefe@utp.edu.pe` | `Jefe#2026` |
| Administrador de laboratorio | `labadmin@utp.edu.pe` | `Lab#2026` |
| Usuario de laboratorio | `docente@utp.edu.pe` | `Doc#2026` |

Son credenciales de demostración: cambiarlas antes de utilizar datos reales. El técnico operativo se registra en `TECNICO`; no es un quinto rol de acceso.

## Uso con MySQL Workbench

1. No vuelvas a ejecutar el SQL original que contiene `DROP DATABASE IF EXISTS scmp_lab` sobre tu base existente.
2. Para preparar el proyecto, abre `src/main/resources/db/scmp_lab_completo.sql` en Workbench y ejecútalo una sola vez. El script usa una base separada `scmp_lab_app`, no elimina `scmp_lab`.
3. Si tu usuario MySQL no es `root`, otorga los permisos necesarios y configura `SCMP_DB_USER`. Configura `SCMP_DB_PASSWORD` con la contraseña local. En PowerShell, por ejemplo:

```powershell
$env:SCMP_DB_USER="root"
$env:SCMP_DB_PASSWORD="TU_CLAVE_MYSQL"
mvn spring-boot:run "-Dspring-boot.run.profiles=mysql"
```

El perfil `mysql` no vuelve a ejecutar `schema.sql` ni `data.sql`: conecta a la base que se preparó mediante Workbench.

## Alcance y limitaciones conocidas

- Las pantallas de los módulos implementan consulta y altas; no se ha implementado CRUD completo para cada entidad (edición/eliminación) ni mantenimiento de usuarios/roles.
- Evidencias guarda una ruta/referencia en la base de datos, no carga archivos binarios.
- Alertas se registran, pero no hay envío automático de correos ni tarea programada de vencimientos.
- El módulo de respaldos registra metadatos/programaciones; no ejecuta una copia física automática de la base.
- `AUDITORIA` registra inicio/cierre de sesión y operaciones de creación/cambio de estado disponibles.
- Las credenciales demo son para entorno académico local. Antes de producción habría que implementar protección CSRF, controles de seguridad completos, gestión segura de secretos, pruebas de integración y revisión de permisos.

## Validación

La Fase 1 que se probó localmente pasó las 10 pruebas de servicio. Esta Fase 2 debe verificarse al extraerla con `mvn clean test`, luego ejecutar `mvn spring-boot:run` y probar el flujo de los módulos. No se afirma que esta versión nueva ya haya pasado Maven en un entorno externo.
