package pe.utp.scmplab.service;

import org.springframework.stereotype.Service;
import pe.utp.scmplab.dao.AuditoriaDAO;
import pe.utp.scmplab.dao.UsuarioDAO;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.security.PasswordHasher;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * RF01 - Iniciar sesión en el sistema.
 * Única responsabilidad (SOLID - S): validar credenciales y controlar el bloqueo por intentos fallidos.
 * La fecha/hora llega como parámetro para que las pruebas no dependan del reloj del sistema.
 */
@Service
public class AutenticacionService {

    public static final int MAX_INTENTOS = 5;
    public static final int MINUTOS_BLOQUEO = 15;
    static final String MSG_CREDENCIALES = "Usuario o contraseña incorrectos";
    static final String MSG_INACTIVA = "Su cuenta está inactiva. Comuníquese con el administrador";

    private final UsuarioDAO usuarioDAO;
    private final AuditoriaDAO auditoriaDAO;
    private final PasswordHasher hasher;

    public AutenticacionService(UsuarioDAO usuarioDAO, AuditoriaDAO auditoriaDAO, PasswordHasher hasher) {
        this.usuarioDAO = usuarioDAO;
        this.auditoriaDAO = auditoriaDAO;
        this.hasher = hasher;
    }

    public ResultadoLogin login(String correo, String clave, LocalDateTime ahora) {
        Optional<Usuario> encontrado = (correo == null || correo.isBlank())
                ? Optional.empty() : usuarioDAO.buscarPorCorreo(correo.trim());
        if (encontrado.isEmpty()) {
            return new ResultadoLogin(ResultadoLogin.Estado.CREDENCIALES_INVALIDAS, MSG_CREDENCIALES, null);
        }
        Usuario usuario = encontrado.get();

        if (usuario.getBloqueadoHasta() != null && ahora.isBefore(usuario.getBloqueadoHasta())) {
            long minutos = Math.max(1, Duration.between(ahora, usuario.getBloqueadoHasta()).toMinutes());
            return new ResultadoLogin(ResultadoLogin.Estado.CUENTA_BLOQUEADA,
                    "Cuenta bloqueada. Intente nuevamente en " + minutos + " minutos", null);
        }

        if (usuario.getBloqueadoHasta() != null) {
            // El bloqueo ya venció: se empieza de cero; si no, el primer error siguiente volvería a bloquear la cuenta.
            usuarioDAO.actualizarIntentos(usuario.getIdUsuario(), 0, null);
            usuario.setIntentosFallidos(0);
            usuario.setBloqueadoHasta(null);
        }

        if (!hasher.coincide(clave, usuario.getClaveHash())) {
            return registrarFallo(usuario, ahora);
        }
        if (!usuario.estaActivo()) {
            return new ResultadoLogin(ResultadoLogin.Estado.CUENTA_INACTIVA, MSG_INACTIVA, null);
        }

        usuarioDAO.actualizarIntentos(usuario.getIdUsuario(), 0, null);
        auditoriaDAO.registrar(ahora, "INICIO_SESION", "USUARIO", String.valueOf(usuario.getIdUsuario()), usuario.getIdUsuario());
        return new ResultadoLogin(ResultadoLogin.Estado.EXITO, "Ingreso correcto", usuario);
    }

    private ResultadoLogin registrarFallo(Usuario usuario, LocalDateTime ahora) {
        int intentos = usuario.getIntentosFallidos() + 1;
        if (intentos >= MAX_INTENTOS) {
            usuarioDAO.actualizarIntentos(usuario.getIdUsuario(), intentos, ahora.plusMinutes(MINUTOS_BLOQUEO));
            auditoriaDAO.registrar(ahora, "CUENTA_BLOQUEADA", "USUARIO", String.valueOf(usuario.getIdUsuario()), usuario.getIdUsuario());
            return new ResultadoLogin(ResultadoLogin.Estado.CUENTA_BLOQUEADA,
                    "Cuenta bloqueada por " + MINUTOS_BLOQUEO + " minutos", null);
        }
        usuarioDAO.actualizarIntentos(usuario.getIdUsuario(), intentos, null);
        int restantes = MAX_INTENTOS - intentos;
        return new ResultadoLogin(ResultadoLogin.Estado.CREDENCIALES_INVALIDAS,
                MSG_CREDENCIALES + ". Le quedan " + restantes + " intentos", null);
    }
}
