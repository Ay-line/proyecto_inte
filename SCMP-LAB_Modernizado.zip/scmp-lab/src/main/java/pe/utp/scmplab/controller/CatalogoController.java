package pe.utp.scmplab.controller;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import pe.utp.scmplab.config.AuthInterceptor;
import pe.utp.scmplab.dao.AuditoriaDAO;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.security.Accion;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.service.CatalogoService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/** Inventario: equipos (con su ficha), laboratorios y tipos de equipo. Los permisos se validan en el servidor. */
@Controller
public class CatalogoController {
    private static final String SIN_PERMISO = "redirect:/inicio?sinPermiso=1";

    private final CatalogoService service;
    private final AuditoriaDAO auditoriaDAO;
    private final PoliticaAcceso acceso;

    public CatalogoController(CatalogoService service, AuditoriaDAO auditoriaDAO, PoliticaAcceso acceso) {
        this.service = service;
        this.auditoriaDAO = auditoriaDAO;
        this.acceso = acceso;
    }

    // ------------------------------------------------------------------ Equipos

    @GetMapping("/equipos")
    public String equipos(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "equipos", Accion.VER)) return SIN_PERMISO;
        cargarEquipos(model, u);
        return "catalogos/equipos";
    }

    @GetMapping("/equipos/{id}")
    public String detalleEquipo(@PathVariable int id, @RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "equipos", Accion.VER)) return SIN_PERMISO;
        var detalle = service.detalleEquipo(id);
        if (detalle.isEmpty()) return "redirect:/equipos";
        model.addAllAttributes(detalle.get());
        return "catalogos/equipo-detalle";
    }

    @PostMapping("/equipos/crear")
    public String crearEquipo(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model, RedirectAttributes redirect,
            @RequestParam String codigo, @RequestParam String serie,
            @RequestParam(required = false) String marca, @RequestParam(required = false) String modelo,
            @RequestParam(required = false) String fechaAdquisicion, @RequestParam String estado,
            @RequestParam(required = false) Integer idTipoEquipo,
            @RequestParam(required = false) Integer idLaboratorio) {
        if (!acceso.permite(u, "equipos", Accion.CREAR)) return SIN_PERMISO;
        try {
            service.crearEquipo(codigo, serie, marca, modelo, fechaAdquisicion, estado, idTipoEquipo, idLaboratorio);
            auditar("CREAR_EQUIPO", "EQUIPO", u);
            redirect.addFlashAttribute("exito", "El equipo se registró correctamente.");
            return "redirect:/equipos";
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            cargarEquipos(model, u);
            model.addAttribute("abrirFormulario", true);
            model.addAttribute("error", ex instanceof IllegalArgumentException ? ex.getMessage()
                    : "No se pudo registrar: revisa que el código y el número de serie no estén repetidos y que el tipo y el laboratorio existan.");
            return "catalogos/equipos";
        }
    }

    // ------------------------------------------------------------------ Laboratorios

    @GetMapping("/laboratorios")
    public String laboratorios(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "laboratorios", Accion.VER)) return SIN_PERMISO;
        cargarLaboratorios(model, u);
        return "catalogos/laboratorios";
    }

    @PostMapping("/laboratorios/crear")
    public String crearLaboratorio(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model, RedirectAttributes redirect,
            @RequestParam String codigo, @RequestParam String nombre, @RequestParam String sede,
            @RequestParam(required = false) String piso,
            @RequestParam(name = "idResponsable", required = false) Integer idResponsable) {
        if (!acceso.permite(u, "laboratorios", Accion.CREAR)) return SIN_PERMISO;
        try {
            service.crearLaboratorio(codigo, nombre, sede, piso, idResponsable);
            auditar("CREAR_LABORATORIO", "LABORATORIO", u);
            redirect.addFlashAttribute("exito", "El laboratorio se registró correctamente.");
            return "redirect:/laboratorios";
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            cargarLaboratorios(model, u);
            model.addAttribute("abrirFormulario", true);
            model.addAttribute("error", ex instanceof IllegalArgumentException ? ex.getMessage()
                    : "No se pudo registrar: el código podría estar repetido.");
            return "catalogos/laboratorios";
        }
    }

    // ------------------------------------------------------------------ Tipos de equipo

    @GetMapping("/tipos-equipo")
    public String tiposEquipo(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model) {
        if (!acceso.permite(u, "tipos-equipo", Accion.VER)) return SIN_PERMISO;
        cargarTipos(model, u);
        return "catalogos/tipos-equipo";
    }

    @PostMapping("/tipos-equipo/crear")
    public String crearTipoEquipo(@RequestAttribute(AuthInterceptor.ATRIBUTO_USUARIO) Usuario u, Model model, RedirectAttributes redirect,
            @RequestParam String nombre, @RequestParam(required = false) String descripcion) {
        if (!acceso.permite(u, "tipos-equipo", Accion.CREAR)) return SIN_PERMISO;
        try {
            service.crearTipoEquipo(nombre, descripcion);
            auditar("CREAR_TIPO_EQUIPO", "TIPO_EQUIPO", u);
            redirect.addFlashAttribute("exito", "El tipo de equipo se registró correctamente.");
            return "redirect:/tipos-equipo";
        } catch (IllegalArgumentException | DataIntegrityViolationException ex) {
            cargarTipos(model, u);
            model.addAttribute("abrirFormulario", true);
            model.addAttribute("error", ex instanceof IllegalArgumentException ? ex.getMessage()
                    : "No se pudo registrar: ya existe un tipo de equipo con ese nombre.");
            return "catalogos/tipos-equipo";
        }
    }

    // ------------------------------------------------------------------ Datos de las vistas

    private void cargarEquipos(Model model, Usuario u) {
        model.addAttribute("equipos", service.listarEquipos());
        model.addAttribute("tipos", service.listarTiposEquipo());
        model.addAttribute("laboratorios", service.listarLaboratorios());
        model.addAttribute("estados", List.of("Operativo", "En mantenimiento", "Inoperativo", "Baja"));
        model.addAttribute("puedeCrear", acceso.permite(u, "equipos", Accion.CREAR));
    }

    private void cargarLaboratorios(Model model, Usuario u) {
        model.addAttribute("laboratorios", service.listarLaboratorios());
        model.addAttribute("responsables", service.listarResponsablesPosibles());
        model.addAttribute("puedeCrear", acceso.permite(u, "laboratorios", Accion.CREAR));
    }

    private void cargarTipos(Model model, Usuario u) {
        model.addAttribute("tipos", service.listarTiposEquipo());
        model.addAttribute("puedeCrear", acceso.permite(u, "tipos-equipo", Accion.CREAR));
    }

    private void auditar(String accion, String tabla, Usuario u) {
        auditoriaDAO.registrar(LocalDateTime.now(), accion, tabla, null, u.getIdUsuario());
    }
}
