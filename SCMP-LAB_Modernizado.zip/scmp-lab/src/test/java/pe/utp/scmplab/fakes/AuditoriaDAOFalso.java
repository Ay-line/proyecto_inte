package pe.utp.scmplab.fakes;

import pe.utp.scmplab.dao.AuditoriaDAO;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AuditoriaDAOFalso implements AuditoriaDAO {

    public final List<String> acciones = new ArrayList<>();
    public final List<LocalDateTime> fechas = new ArrayList<>();

    @Override
    public void registrar(LocalDateTime fecha, String accion, String tablaAfectada, String idRegistro, Integer idUsuario) {
        acciones.add(accion);
        fechas.add(fecha);
    }
}
