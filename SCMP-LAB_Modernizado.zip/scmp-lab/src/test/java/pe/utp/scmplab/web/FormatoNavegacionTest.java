package pe.utp.scmplab.web;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pe.utp.scmplab.security.PoliticaAcceso;
import pe.utp.scmplab.security.RolSistema;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class FormatoNavegacionTest {

    @Test
    @DisplayName("Las celdas se muestran en formato legible")
    void celdas() {
        assertEquals("—", Formato.celda(null));
        assertEquals("—", Formato.celda("  "));
        assertEquals("05/10/2026 08:00", Formato.celda(Timestamp.valueOf("2026-10-05 08:00:00")));
        assertEquals("05/10/2026 08:00", Formato.celda(LocalDateTime.of(2026, 10, 5, 8, 0)));
        assertEquals("05/10/2026", Formato.celda(java.sql.Date.valueOf("2026-10-05")));
        assertEquals("Sí", Formato.celda(Boolean.TRUE));
        assertEquals("207.00", Formato.celda(new BigDecimal("207")));
        assertEquals("45", Formato.celda(45));
    }

    @Test
    @DisplayName("El color de la etiqueta depende del valor")
    void tonos() {
        assertEquals("ok", Formato.tono("Operativo"));
        assertEquals("aviso", Formato.tono("En mantenimiento"));
        assertEquals("peligro", Formato.tono("Crítica"));
        assertEquals("info", Formato.tono("Con orden de trabajo"));
        assertEquals("neutro", Formato.tono("Baja"));
        assertEquals("neutro", Formato.tono(null));
    }

    private static Set<String> titulos(RolSistema rol) {
        return Navegacion.construir(new PoliticaAcceso(), rol, "/gestion/ordenes/3").stream()
                .flatMap(s -> s.getEnlaces().stream()).map(Navegacion.Enlace::getTitulo).collect(Collectors.toSet());
    }

    @Test
    @DisplayName("El menú solo incluye lo que el rol puede consultar")
    void menuPorRol() {
        assertEquals(Set.of("Reportes de falla"), titulos(RolSistema.USUARIO_LABORATORIO));
        assertTrue(titulos(RolSistema.ADMINISTRADOR).contains("Usuarios"));
        assertFalse(titulos(RolSistema.JEFE).contains("Usuarios"));
        assertFalse(titulos(RolSistema.ADMIN_LABORATORIO).contains("Órdenes de trabajo"));
    }

    @Test
    @DisplayName("Una ruta de detalle marca activo su módulo y su sección")
    void menuActivo() {
        var secciones = Navegacion.construir(new PoliticaAcceso(), RolSistema.JEFE, "/gestion/ordenes/3");
        var activas = secciones.stream().filter(Navegacion.Seccion::isActiva).map(Navegacion.Seccion::getTitulo).collect(Collectors.toList());
        assertEquals(List.of("Incidencias"), activas);
        assertFalse(Navegacion.coincide("/gestion/planes2", "/gestion/planes"));
        assertTrue(Navegacion.coincide("/equipos/4", "/equipos"));
    }
}
