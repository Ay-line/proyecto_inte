package pe.utp.scmplab.service;

import pe.utp.scmplab.model.Usuario;

/** Resultado de un intento de inicio de sesión. */
public class ResultadoLogin {

    public enum Estado { EXITO, CREDENCIALES_INVALIDAS, CUENTA_BLOQUEADA, CUENTA_INACTIVA }

    private final Estado estado;
    private final String mensaje;
    private final Usuario usuario;

    public ResultadoLogin(Estado estado, String mensaje, Usuario usuario) {
        this.estado = estado;
        this.mensaje = mensaje;
        this.usuario = usuario;
    }
    public Estado getEstado() { return estado; }
    public String getMensaje() { return mensaje; }
    public Usuario getUsuario() { return usuario; }
    public boolean esExitoso() { return estado == Estado.EXITO; }
}
