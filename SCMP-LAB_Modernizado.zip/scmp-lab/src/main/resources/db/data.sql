-- Semillas de demostración de SCMP-LAB, alineadas con el capítulo 5 del informe.
-- Las contraseñas de los usuarios se almacenan en BCrypt; estos datos son solo para entorno local.
INSERT INTO ROL (nombre, descripcion) VALUES
 ('Administrador del sistema','Gestiona usuarios, roles, parámetros y respaldos'),
 ('Jefe de infraestructura TI','Planifica, asigna, prioriza y aprueba'),
 ('Administrador de laboratorio','Responsable del inventario del laboratorio'),
 ('Usuario de laboratorio','Docente o estudiante que reporta fallas');

INSERT INTO USUARIO (nombre, correo, clave_hash, estado, id_rol) VALUES
 ('Administrador del Sistema','admin@utp.edu.pe','$2a$10$Ww8uIOwaRDIJcwRPyGIh.erDWjnji4gOdWkX5xOKZXj2hke9FSrGS','Activo',1),
 ('Jefe de Infraestructura TI','jefe@utp.edu.pe','$2a$10$ENI36dogRnVJQYavp/G/nO1vNzJaNbQYj6OYgYPVeFQ/N7HOSaBNa','Activo',2),
 ('Administrador de Laboratorio','labadmin@utp.edu.pe','$2a$10$IS7.K.0Vlxq5VVjybhjiIuRU4cNbG38SNn17bCuDJvbMayngRlAl6','Activo',3),
 ('Docente de Laboratorio','docente@utp.edu.pe','$2a$10$KIpGnHmAzKRDGvl3ZxFik.zASH81Mua/hXVUU28Lkh5lL1lARpFr.','Activo',4);

INSERT INTO LABORATORIO (codigo,nombre,sede,piso,id_usuario_responsable) VALUES
 ('LIM-01','Laboratorio piloto','Lima','2',3);
INSERT INTO TIPO_EQUIPO (nombre,descripcion) VALUES
 ('PC','Computadora de escritorio'),('Laptop','Computadora portátil'),('Impresora','Equipo de impresión');
INSERT INTO EQUIPO (codigo_interno,numero_serie,marca,modelo,fecha_adquisicion,estado,id_tipo_equipo,id_laboratorio) VALUES
 ('EQ-PC-001','SN-UTP-0001','Dell','OptiPlex 7090','2025-03-10','Operativo',1,1),
 ('EQ-PC-002','SN-UTP-0002','Dell','OptiPlex 7090','2025-03-10','Operativo',1,1),
 ('EQ-PC-003','SN-UTP-0003','HP','ProDesk 600','2025-03-10','En mantenimiento',1,1);
INSERT INTO COMPONENTE (tipo,marca,capacidad) VALUES
 ('RAM','Kingston','16 GB'),('SSD','Kingston','512 GB'),('Fuente','Dell','240 W');
INSERT INTO INSTALACION_COMPONENTE (id_equipo,id_componente,fecha_instalacion) VALUES
 (1,1,'2025-03-10'),(1,2,'2025-03-10'),(1,3,'2025-03-10');
INSERT INTO TIPO_FALLA (nombre,descripcion) VALUES
 ('No enciende','El equipo no inicia'),('Falla de almacenamiento','El disco no es detectado');
INSERT INTO TECNICO (nombre,correo,especialidad) VALUES
 ('Técnico 01','tecnico01@utp.edu.pe','Hardware y mantenimiento');
INSERT INTO REPUESTO (nombre,costo_unitario,stock_referencial) VALUES
 ('SSD 512 GB',180.00,5),('Cable SATA',15.00,10),('Pasta térmica',12.00,8);
INSERT INTO TAREA_CHECKLIST (descripcion,id_tipo_equipo) VALUES
 ('Limpiar ventiladores y rejillas',1),('Revisar cableado y conexiones',1),
 ('Verificar temperatura del equipo',1),('Comprobar almacenamiento',1),('Verificar periféricos',1);
INSERT INTO MANTENIMIENTO (tipo,fecha_inicio,fecha_fin,resultado,observacion,id_equipo,id_tecnico) VALUES
 ('Preventivo','2026-10-05 08:00:00','2026-10-05 08:45:00','Conforme','Mantenimiento preventivo realizado sin incidencias',1,1);
INSERT INTO DETALLE_CHECKLIST (id_mantenimiento,id_tarea,resultado,comentario) VALUES
 (1,1,'Conforme','Limpieza realizada'),(1,2,'Conforme','Conexiones firmes'),
 (1,3,'Conforme','Temperatura dentro del rango esperado'),(1,4,'Conforme','SSD sin alertas'),
 (1,5,'Observado','Teclado con desgaste leve');
INSERT INTO REPORTE_FALLA (fecha_reporte,descripcion_problema,canal,prioridad,estado,id_usuario,id_equipo,id_tipo_falla) VALUES
 ('2026-09-30 10:15:00','El equipo no enciende al presionar el botón de inicio','Formulario web','Alta','Registrado',4,2,1),
 ('2026-09-30 10:10:00','El equipo no detecta el disco al iniciar','Formulario web','Alta','Con orden de trabajo',4,1,2);
INSERT INTO ORDEN_TRABAJO (fecha_creacion,prioridad,estado,diagnostico,fecha_asignacion,id_reporte,id_equipo,id_tecnico) VALUES
 ('2026-09-30 10:15:00','Alta','En reparación','SSD no detectado por el equipo','2026-09-30 10:20:00',2,1,1);
INSERT INTO DETALLE_ORDEN (id_orden,id_repuesto,cantidad,costo_aplicado) VALUES
 (1,1,1,180.00),(1,2,1,15.00),(1,3,1,12.00);
INSERT INTO PLAN_MANTENIMIENTO (nombre,periodicidad_dias,horas_uso,activo,id_tipo_equipo) VALUES
 ('Preventivo trimestral de PC',90,NULL,TRUE,1);
INSERT INTO PROGRAMACION_MANTENIMIENTO (fecha_programada,estado,hora_inicio,hora_fin,id_plan,id_equipo) VALUES
 ('2026-11-05','Programado','08:00:00','09:00:00',1,2);
INSERT INTO EVIDENCIA_ORDEN (ruta_archivo,fecha_carga,id_orden) VALUES
 ('referencia-demo/OT-001/diagnostico.txt','2026-09-30 10:30:00',1);
INSERT INTO ALERTA (tipo,fecha_generacion,mensaje,estado,id_orden,id_programacion) VALUES
 ('Mantenimiento programado','2026-10-27 08:00:00','Se aproxima el mantenimiento preventivo del equipo EQ-PC-002','Generada',NULL,1),
 ('Orden prioritaria','2026-09-30 10:20:00','La orden de trabajo 1 tiene prioridad alta','Generada',1,NULL);
INSERT INTO CONFIG_ALERTA (tipo_alerta,canal,destinatario,activo) VALUES
 ('Mantenimiento programado','Sistema','Jefe de infraestructura TI',TRUE),
 ('Orden prioritaria','Correo','infraestructura@utp.edu.pe',TRUE);
INSERT INTO AUDITORIA (fecha,accion,tabla_afectada,id_registro,id_usuario) VALUES
 ('2026-10-05 08:00:00','EJECUTAR_MANTENIMIENTO','MANTENIMIENTO','1',2),
 ('2026-09-30 10:15:00','REGISTRAR_REPORTE','REPORTE_FALLA','2',4);
INSERT INTO CONFIG_GENERAL (clave,valor,descripcion) VALUES
 ('nombre_sistema','SCMP-LAB','Nombre visible del sistema'),
 ('zona_horaria','America/Lima','Zona horaria de operación');
INSERT INTO RESPALDO (fecha_programada,fecha_ejecucion,estado,ubicacion) VALUES
 ('2026-11-01 02:00:00',NULL,'Programado',NULL);
