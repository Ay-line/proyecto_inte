package pe.utp.scmplab.modulo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class CatalogoModulosTest {

    private static final Set<String> OPCIONES_CONOCIDAS = Set.of("equipos", "laboratorios", "tipos-equipo", "componentes", "tecnicos",
            "tipos-falla", "tareas", "mantenimientos", "reportes", "ordenes", "repuestos", "planes", "programaciones");

    @Test
    @DisplayName("Cada módulo genérico tiene columnas y los campos de formulario son coherentes")
    void definicionesCoherentes() {
        for (Modulo m : CatalogoModulos.todos()) {
            if (!m.isGenerico()) continue;
            assertFalse(m.getColumnas().isEmpty(), "Sin columnas: " + m.getClave());
            Set<String> nombres = new HashSet<>();
            for (Campo c : m.getCampos()) {
                assertTrue(nombres.add(c.getName()), "Campo repetido " + c.getName() + " en " + m.getClave());
                if ("seleccion".equals(c.getTipo())) {
                    assertTrue(OPCIONES_CONOCIDAS.contains(c.getOpciones()), "Opciones desconocidas: " + c.getOpciones());
                    assertNotNull(c.getVacio());
                }
                if ("lista".equals(c.getTipo())) assertFalse(c.getValores().isEmpty());
            }
        }
    }

    @Test
    @DisplayName("Los módulos con página propia mantienen sus rutas")
    void rutasPropias() {
        assertEquals("/equipos", CatalogoModulos.obtener("equipos").orElseThrow().getRuta());
        assertFalse(CatalogoModulos.obtener("laboratorios").orElseThrow().isGenerico());
        assertTrue(CatalogoModulos.obtener("reportes").orElseThrow().isGenerico());
        assertTrue(CatalogoModulos.obtener("inexistente").isEmpty());
    }
}
