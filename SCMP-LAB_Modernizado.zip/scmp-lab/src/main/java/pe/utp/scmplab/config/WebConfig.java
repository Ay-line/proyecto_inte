package pe.utp.scmplab.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private static final String[] PUBLICAS = {"/css/**", "/js/**", "/img/**", "/error", "/favicon.ico"};

    private final AuthInterceptor authInterceptor;
    private final CsrfInterceptor csrfInterceptor;

    public WebConfig(AuthInterceptor authInterceptor, CsrfInterceptor csrfInterceptor) {
        this.authInterceptor = authInterceptor;
        this.csrfInterceptor = csrfInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // Primero la sesión (una sesión vencida va al acceso) y después el token del formulario.
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/login")
                .excludePathPatterns(PUBLICAS);
        registry.addInterceptor(csrfInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(PUBLICAS);
    }
}
