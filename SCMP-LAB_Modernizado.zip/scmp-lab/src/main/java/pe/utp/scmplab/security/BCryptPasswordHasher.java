package pe.utp.scmplab.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/** Implementación con BCrypt (spring-security-crypto). Las contraseñas nunca se guardan en claro. */
@Component
public class BCryptPasswordHasher implements PasswordHasher {

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(10);

    @Override
    public String cifrar(String claveClara) {
        return encoder.encode(claveClara);
    }

    @Override
    public boolean coincide(String claveClara, String hash) {
        return claveClara != null && hash != null && encoder.matches(claveClara, hash);
    }
}
