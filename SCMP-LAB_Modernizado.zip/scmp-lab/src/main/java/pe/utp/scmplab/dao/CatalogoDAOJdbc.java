package pe.utp.scmplab.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** SQL del inventario y catálogos centralizado en la capa DAO. */
@Repository
public class CatalogoDAOJdbc implements CatalogoDAO {
    private final JdbcTemplate jdbc;

    public CatalogoDAOJdbc(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public long contar(String tabla) {
        // Solo se admiten nombres constantes internos, nunca datos enviados por el usuario.
        return switch (tabla) {
            case "LABORATORIO" -> jdbc.queryForObject("SELECT COUNT(*) FROM LABORATORIO", Long.class);
            case "EQUIPO" -> jdbc.queryForObject("SELECT COUNT(*) FROM EQUIPO", Long.class);
            case "MANTENIMIENTO" -> jdbc.queryForObject("SELECT COUNT(*) FROM MANTENIMIENTO", Long.class);
            case "REPORTE_FALLA" -> jdbc.queryForObject("SELECT COUNT(*) FROM REPORTE_FALLA", Long.class);
            case "ORDEN_TRABAJO" -> jdbc.queryForObject("SELECT COUNT(*) FROM ORDEN_TRABAJO", Long.class);
            default -> throw new IllegalArgumentException("Tabla de indicador no admitida");
        };
    }

    @Override
    public List<Map<String, Object>> listarLaboratorios() {
        return jdbc.queryForList("""
            SELECT l.id_laboratorio AS id, l.codigo AS codigo, l.nombre AS nombre,
                   l.sede AS sede, l.piso AS piso, COALESCE(u.nombre, 'Sin responsable') AS responsable
            FROM LABORATORIO l LEFT JOIN USUARIO u ON u.id_usuario = l.id_usuario_responsable
            ORDER BY l.codigo
            """);
    }

    @Override
    public List<Map<String, Object>> listarTiposEquipo() {
        return jdbc.queryForList("SELECT id_tipo_equipo AS id, nombre, descripcion FROM TIPO_EQUIPO ORDER BY nombre");
    }

    @Override
    public List<Map<String, Object>> listarEquipos() {
        return jdbc.queryForList("""
            SELECT e.id_equipo AS id, e.codigo_interno AS codigo, e.numero_serie AS serie,
                   COALESCE(e.marca, '—') AS marca, COALESCE(e.modelo, '—') AS modelo,
                   e.estado AS estado, te.nombre AS tipo, l.nombre AS laboratorio,
                   l.codigo AS codigo_laboratorio
            FROM EQUIPO e
            JOIN TIPO_EQUIPO te ON te.id_tipo_equipo = e.id_tipo_equipo
            JOIN LABORATORIO l ON l.id_laboratorio = e.id_laboratorio
            ORDER BY e.codigo_interno
            """);
    }

    @Override
    public void crearLaboratorio(String codigo, String nombre, String sede, String piso, Integer responsable) {
        jdbc.update("INSERT INTO LABORATORIO (codigo, nombre, sede, piso, id_usuario_responsable) VALUES (?, ?, ?, ?, ?)",
                codigo, nombre, sede, piso == null || piso.isBlank() ? null : piso, responsable);
    }

    @Override
    public void crearTipoEquipo(String nombre, String descripcion) {
        jdbc.update("INSERT INTO TIPO_EQUIPO (nombre, descripcion) VALUES (?, ?)",
                nombre, descripcion == null || descripcion.isBlank() ? null : descripcion);
    }

    @Override
    public void crearEquipo(String codigo, String serie, String marca, String modelo,
                            String fechaAdquisicion, String estado, int idTipoEquipo, int idLaboratorio) {
        Date fecha = (fechaAdquisicion == null || fechaAdquisicion.isBlank()) ? null : Date.valueOf(fechaAdquisicion);
        jdbc.update("""
            INSERT INTO EQUIPO (codigo_interno, numero_serie, marca, modelo, fecha_adquisicion,
                                estado, id_tipo_equipo, id_laboratorio)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, codigo, serie,
                marca == null || marca.isBlank() ? null : marca,
                modelo == null || modelo.isBlank() ? null : modelo,
                fecha, estado, idTipoEquipo, idLaboratorio);
    }

    @Override
    public List<Map<String, Object>> listarResponsablesPosibles(String nombreRol) {
        return jdbc.queryForList("""
            SELECT u.id_usuario AS id, u.nombre AS nombre
            FROM USUARIO u JOIN ROL r ON r.id_rol = u.id_rol
            WHERE r.nombre = ? AND u.estado = 'Activo'
            ORDER BY u.nombre
            """, nombreRol);
    }

    @Override
    public Optional<Map<String, Object>> buscarEquipo(int id) {
        return jdbc.queryForList("""
            SELECT e.id_equipo AS id, e.codigo_interno AS codigo, e.numero_serie AS serie, e.marca AS marca,
                   e.modelo AS modelo, e.fecha_adquisicion AS adquisicion, e.estado AS estado,
                   te.nombre AS tipo, l.codigo AS codigo_laboratorio, l.nombre AS laboratorio, l.sede AS sede
            FROM EQUIPO e
            JOIN TIPO_EQUIPO te ON te.id_tipo_equipo = e.id_tipo_equipo
            JOIN LABORATORIO l ON l.id_laboratorio = e.id_laboratorio
            WHERE e.id_equipo = ?
            """, id).stream().findFirst();
    }

    @Override
    public List<Map<String, Object>> componentesDeEquipo(int id) {
        return jdbc.queryForList("""
            SELECT c.tipo AS tipo, c.marca AS marca, c.capacidad AS capacidad,
                   i.fecha_instalacion AS instalado, i.fecha_retiro AS retirado
            FROM INSTALACION_COMPONENTE i JOIN COMPONENTE c ON c.id_componente = i.id_componente
            WHERE i.id_equipo = ? ORDER BY c.tipo
            """, id);
    }

    @Override
    public List<Map<String, Object>> mantenimientosDeEquipo(int id) {
        return jdbc.queryForList("""
            SELECT m.id_mantenimiento AS id, m.tipo AS tipo, m.fecha_inicio AS fecha, t.nombre AS tecnico,
                   m.resultado AS resultado, dur.tiempo_empleado_min AS minutos
            FROM MANTENIMIENTO m
            JOIN TECNICO t ON t.id_tecnico = m.id_tecnico
            LEFT JOIN V_MANTENIMIENTO_DURACION dur ON dur.id_mantenimiento = m.id_mantenimiento
            WHERE m.id_equipo = ? ORDER BY m.fecha_inicio DESC
            """, id);
    }

    @Override
    public List<Map<String, Object>> reportesDeEquipo(int id) {
        return jdbc.queryForList("""
            SELECT r.id_reporte AS id, r.fecha_reporte AS fecha, COALESCE(tf.nombre, 'Sin clasificar') AS tipo_falla,
                   COALESCE(r.prioridad, 'Sin prioridad') AS prioridad, r.estado AS estado
            FROM REPORTE_FALLA r LEFT JOIN TIPO_FALLA tf ON tf.id_tipo_falla = r.id_tipo_falla
            WHERE r.id_equipo = ? ORDER BY r.fecha_reporte DESC
            """, id);
    }

    @Override
    public List<Map<String, Object>> ordenesDeEquipo(int id) {
        return jdbc.queryForList("""
            SELECT o.id_orden AS id, o.fecha_creacion AS fecha, o.prioridad AS prioridad, o.estado AS estado,
                   COALESCE(t.nombre, 'Sin asignar') AS tecnico, COALESCE(ct.costo_total_repuestos, 0) AS costo
            FROM ORDEN_TRABAJO o
            LEFT JOIN TECNICO t ON t.id_tecnico = o.id_tecnico
            LEFT JOIN V_ORDEN_COSTO_TOTAL ct ON ct.id_orden = o.id_orden
            WHERE o.id_equipo = ? ORDER BY o.fecha_creacion DESC
            """, id);
    }
}
