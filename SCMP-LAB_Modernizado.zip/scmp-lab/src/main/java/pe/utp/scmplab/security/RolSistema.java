package pe.utp.scmplab.security;

import java.util.Optional;

/** Los cuatro roles de acceso documentados en el informe (tabla ROL). El técnico no es un rol de acceso. */
public enum RolSistema {
    ADMINISTRADOR("Administrador del sistema"),
    JEFE("Jefe de infraestructura TI"),
    ADMIN_LABORATORIO("Administrador de laboratorio"),
    USUARIO_LABORATORIO("Usuario de laboratorio");

    private final String nombre;

    RolSistema(String nombre) { this.nombre = nombre; }

    public String getNombre() { return nombre; }

    /** Resuelve el rol por el nombre guardado en ROL (único por restricción). Un nombre desconocido no da acceso. */
    public static Optional<RolSistema> desdeNombre(String nombre) {
        if (nombre == null) return Optional.empty();
        String limpio = nombre.trim();
        for (RolSistema r : values()) {
            if (r.nombre.equalsIgnoreCase(limpio)) return Optional.of(r);
        }
        return Optional.empty();
    }
}
