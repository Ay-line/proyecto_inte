package pe.utp.scmplab.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pe.utp.scmplab.model.Usuario;
import pe.utp.scmplab.modulo.CatalogoModulos;
import pe.utp.scmplab.modulo.Modulo;

import static org.junit.jupiter.api.Assertions.*;
import static pe.utp.scmplab.security.Accion.*;
import static pe.utp.scmplab.security.RolSistema.*;

class PoliticaAccesoTest {

    private final PoliticaAcceso p = new PoliticaAcceso();

    private static Usuario con(String rol) {
        Usuario u = new Usuario();
        u.setIdUsuario(1);
        u.setNombreRol(rol);
        return u;
    }

    @Test
    @DisplayName("El usuario de laboratorio solo accede a reportes y no gestiona")
    void usuarioLaboratorio() {
        for (Modulo m : CatalogoModulos.todos()) {
            boolean esReportes = m.getClave().equals("reportes");
            assertEquals(esReportes, p.permite(USUARIO_LABORATORIO, m.getClave(), VER), m.getClave());
            assertFalse(p.permite(USUARIO_LABORATORIO, m.getClave(), GESTIONAR), m.getClave());
        }
        assertTrue(p.permite(USUARIO_LABORATORIO, "reportes", CREAR));
    }

    @Test
    @DisplayName("El administrador de laboratorio ve inventario y reportes, pero no órdenes ni administración")
    void adminLaboratorio() {
        assertTrue(p.permite(ADMIN_LABORATORIO, "equipos", CREAR));
        assertTrue(p.permite(ADMIN_LABORATORIO, "mantenimientos", VER));
        assertFalse(p.permite(ADMIN_LABORATORIO, "mantenimientos", CREAR));
        assertFalse(p.permite(ADMIN_LABORATORIO, "ordenes", VER));
        assertFalse(p.permite(ADMIN_LABORATORIO, "tecnicos", VER));
        assertFalse(p.permite(ADMIN_LABORATORIO, "usuarios", VER));
        assertFalse(p.permite(ADMIN_LABORATORIO, "reportes", GESTIONAR));
    }

    @Test
    @DisplayName("El jefe planifica y asigna, pero no administra usuarios, roles, parámetros ni respaldos")
    void jefe() {
        assertTrue(p.permite(JEFE, "ordenes", GESTIONAR));
        assertTrue(p.permite(JEFE, "programaciones", CREAR));
        assertTrue(p.permite(JEFE, "auditoria", VER));
        for (String m : new String[]{"usuarios", "roles", "configuracion", "respaldos"}) {
            assertFalse(p.permite(JEFE, m, VER), m);
        }
    }

    @Test
    @DisplayName("El administrador del sistema accede a todo; usuarios, roles y auditoría son de solo consulta")
    void administrador() {
        for (Modulo m : CatalogoModulos.todos()) assertTrue(p.permite(ADMINISTRADOR, m.getClave(), VER), m.getClave());
        for (String m : new String[]{"usuarios", "roles", "auditoria"}) assertFalse(p.permite(ADMINISTRADOR, m, CREAR), m);
    }

    @Test
    @DisplayName("Módulos o roles desconocidos se niegan")
    void desconocidos() {
        assertFalse(p.permite(ADMINISTRADOR, "no-existe", VER));
        assertFalse(p.permite(con("Técnico"), "equipos", VER));
        assertFalse(p.permite((Usuario) null, "equipos", VER));
        assertFalse(p.permite(con(null), "equipos", VER));
        assertTrue(p.permite(con("  jefe de infraestructura ti "), "ordenes", VER));
    }

    @Test
    @DisplayName("Todo módulo con formulario tiene regla de acceso para crear")
    void modulosConAltaTienenRegla() {
        for (Modulo m : CatalogoModulos.todos()) {
            if (m.getCampos().isEmpty()) continue;
            boolean alguien = false;
            for (RolSistema r : RolSistema.values()) alguien |= p.permite(r, m.getClave(), CREAR);
            assertTrue(alguien, "Nadie puede crear en " + m.getClave());
        }
    }
}
