package pe.utp.scmplab.web;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import pe.utp.scmplab.modulo.Columna;

/** Presentación de los datos de los listados: fechas legibles, Sí/No, importes y color de las etiquetas de estado. */
public final class Formato {

    public static final String SUFIJO_TONO = "__t";
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");

    private static final Set<String> OK = Set.of("operativo", "conforme", "cerrada", "cerrado", "resuelta", "ejecutado",
            "exitoso", "activo", "sí");
    private static final Set<String> AVISO = Set.of("en mantenimiento", "observado", "observada", "asignada", "alta",
            "reprogramado", "media");
    private static final Set<String> PELIGRO = Set.of("inoperativo", "crítica", "vencido", "fallido", "inactivo");
    private static final Set<String> INFO = Set.of("creada", "registrado", "con orden de trabajo", "en reparación",
            "generada", "programado");

    private Formato() { }

    /** Texto para mostrar en una celda; los valores nulos se muestran como un guion. */
    public static String celda(Object v) {
        if (v == null) return "—";
        if (v instanceof Timestamp t) return t.toLocalDateTime().format(FECHA_HORA);
        if (v instanceof java.sql.Date d) return d.toLocalDate().format(FECHA);
        if (v instanceof Time t) return t.toLocalTime().format(HORA);
        if (v instanceof LocalDateTime t) return t.format(FECHA_HORA);
        if (v instanceof LocalDate d) return d.format(FECHA);
        if (v instanceof LocalTime t) return t.format(HORA);
        if (v instanceof Boolean b) return b ? "Sí" : "No";
        if (v instanceof BigDecimal n) return n.setScale(2, RoundingMode.HALF_UP).toPlainString();
        String s = v.toString();
        return s.isBlank() ? "—" : s;
    }

    /** Color de la etiqueta según el valor: ok, aviso, peligro, info o neutro. */
    public static String tono(String valor) {
        if (valor == null) return "neutro";
        String v = valor.trim().toLowerCase(Locale.ROOT);
        if (OK.contains(v)) return "ok";
        if (AVISO.contains(v)) return "aviso";
        if (PELIGRO.contains(v)) return "peligro";
        if (INFO.contains(v)) return "info";
        return "neutro";
    }

    /** Devuelve copias de las filas con las celdas ya formateadas y el tono de las columnas de etiqueta. */
    public static List<Map<String, Object>> filas(List<Map<String, Object>> origen, List<Columna> columnas) {
        List<Map<String, Object>> salida = new ArrayList<>(origen.size());
        for (Map<String, Object> fila : origen) {
            Map<String, Object> copia = new java.util.LinkedHashMap<>(fila);
            for (Columna col : columnas) {
                String texto = celda(fila.get(col.getKey()));
                copia.put(col.getKey(), texto);
                if (col.isEtiqueta()) copia.put(col.getKey() + SUFIJO_TONO, tono(texto));
            }
            salida.add(copia);
        }
        return salida;
    }

    /** Formatea todos los valores de una fila (para pantallas de detalle). */
    public static Map<String, Object> fila(Map<String, Object> origen) {
        Map<String, Object> copia = new java.util.LinkedHashMap<>();
        origen.forEach((k, v) -> copia.put(k, celda(v)));
        return copia;
    }
}
